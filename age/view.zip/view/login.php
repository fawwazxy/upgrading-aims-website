<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<? 
	require "../model/functions.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Niconne&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&family=Niconne&display=swap" rel="stylesheet">
	
    <? require "../global/header.php"; ?>

</head>

<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}

body{
	
	background-image: url("https://www.mprc.gov.my/sites/default/files/directories-gallery/DSC_0201.JPG");
	background-repeat: no-repeat;
	background-attachment: fixed;  
	background-size: cover;
   
}

.containerz {
    
    box-shadow: 3px 33px 43px black ;
    display: flex;
    border-radius: 10px;
	margin-left:60px;
	margin-right:60px;
	margin-top:8%;
	margin-bottom:8%;
}

.content {
    flex: 50%;
    background-color: white;
    text-align: center;
    font-family: 'Montserrat', sans-serif;
}

.imagerz {
    flex: 50%;
    background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)));
    background-size: cover;
	text-align:center;
    color: white;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	backdrop-filter: blur(5px);
	
}

.content h4 {
    padding: 30px;
    padding-top: 20px;
    font-family: 'Candara', cursive;
    font-size: 30px;
    color: #FF8C00;
	text-align:center;
}

#txt {
    margin: 10px;
    padding: 5px;
    border: none;
    background-color: #FFF0F5;
    border-radius: 10px;
    font-weight: bold;
    font-size: small;
    font-family: 'Montserrat', sans-serif;
    color: black;
}

.button1 {
    padding: 10px 40px;
    margin-top: 20px;
    border: none;
    background: linear-gradient(to right, 	#FFA500, #FF4500);
    border-radius: 20px;
    transition: 0.3s;
	color: white;
}

.button1:hover {
    transform: scale(1.2);
}

.bg-image {
  /* The image used */
  
  /* Add the blur effect */
  filter: blur(8px);
  -webkit-filter: blur(8px);
 
}



footer{
	background-color: #FF8C00;
	width: 100%;
}
</style>
<? $sys = getSys(1) -> fetch_assoc(); ?>
<body>

<div class="container">
<div class="containerz">
				
				<div class="imagerz">
				<br><br><br><br>
				<? echo '<img width="350" height="300" src="https://www.mprc.gov.my/sites/default/files/styles/medium/public/directories-logo/aims_logo.png?itok=VRmQNKpL"/ align="center">';?>
               
				</div>

<div class="content">				 
<h4 align="left">Aims Global Engineering Ship Management System &nbsp;(Version:AIMS001-01)</h4>
    
        <div class="row">
            <div class="col-md-7 col-md-offset-2">
               
                    <div class="panel-body">
                        <form role="form" action="../controller/login_exec.php" method="POST">
                            <fieldset>
                                <div class="form-group">
								<label for="">Name</label>
                                    <input class="form-control" placeholder="Name" id="txt" name="username" type="text" required=""/>
                                </div>
								
                                <div class="form-group">
								<label for="">Password</label>
                                    <input class="form-control" placeholder="Password" id="txt" name="password" type="password" required=""/>
                                </div>
                                <input type="submit" class="button1" value="Login"/>
                            </fieldset>


                        </form>

                    </div>

                
				

          </div>
            </div>

    </div>
	</div>
	</div>
	<br><br><br>
	<footer>
   <h5> <? include ('../global/footer.php'); ?></h5>
	</footer>
</body>

</html>
<?php
   	include "../model/aims_lv_medicalver_function.php";
    
	$id = ($_POST['id']);
	
	$ver_status = ($_POST['ver_status']);

	$ver_name = ($_POST['ver_name']);
	
	 $result =updateStaff($ver_status,$ver_name,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0)

	
	{
		echo ("<script LANGUAGE='JavaScript'>
						window.location.href='../view/aims_lv_medicalver_list.php';
						</script>");
		//header("location: ../view/list_faq.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>



















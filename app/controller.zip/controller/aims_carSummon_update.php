<?php
   	include "../model/aims_carReserve_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$id = $_POST['id'];
	$summon_by = $_POST['summon_by'];
	$issue_distric = $_POST['issue_distric'];
	$summons_no = $_POST['summons_no'];
	$offense = $_POST['offense'];
    $enforcement_date = $_POST['enforcement_date'];
	$offense_details = $_POST['offense_details'];
	$original_amount = $_POST['original_amount'];   
	
	//$id = ($_POST['id']);

	$result = updatecarsummon($issue_distric,$summon_by,$summons_no,$offense,$enforcement_date,$offense_details,$original_amount,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{

		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_carSummon_list.php';
            </script>");
		//header("location: ../view/aims_carSummon_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
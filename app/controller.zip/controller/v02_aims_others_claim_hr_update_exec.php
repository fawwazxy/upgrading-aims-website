<?
include "../model/v02_aims_others_claim_function.php";

$id = $_POST['id'];
$jobno = $_POST['jobno'];
$date_claim = $_POST['date_claim'];
$month_claim = $_POST['month_claim'];
$description = nl2br($_POST['description']);

$result = v02updateOthersClaim($id,$jobno,$date_claim,$month_claim,$description);

if($result!="" && $result > 0) {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Update successfully.')
            window.location.href='../view/v02_aims_others_claim_hr_update.php?id=$id';
            </script>");
    exit();
} else {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Failed to update.')
            history.back();
            </script>");
    exit();
}

?>

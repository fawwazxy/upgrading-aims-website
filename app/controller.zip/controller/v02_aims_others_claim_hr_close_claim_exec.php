<?php
require "../model/v02_aims_others_claim_function.php";

$id = $_GET['id'];
$nostaff = $_GET['nostaff'];
$result = v02closeOtherClosedClaim($id,$nostaff);

//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script>
			alert('Successfully Close Claim for selected month');
			window.history.back();
			</script>");
    exit();
} else {
    echo ("<script>
			alert('Failed to close claim!');
			window.history.back();
			</script>");
    exit();
}

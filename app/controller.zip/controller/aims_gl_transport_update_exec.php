<?php
   	include "../model/aims_gl_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$id = clean($_POST['id']);
	$company_vehicle = clean($_POST['company_vehicle']);
	$date_use = clean($_POST['date_use']);
	$mileage_in = clean($_POST['mileage_in']);
	$mileage_out = clean($_POST['mileage_out']);
	$total_mileage = clean($_POST['total_mileage']);
	$total = clean($_POST['total']);
	
	
    	
	
	//$id = ($_POST['id']);

	$result = updateTransport($company_vehicle,$date_use,$mileage_in,$mileage_out,$total_mileage,$total,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_gl_transport.php';
            </script>");
		//header("location: ../view/aims_gl_booking_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
<?php
   	include "../model/aims_lv_medical_function.php";
    
	
	$no_staff = $_POST['no_staff'];

	$medical_id = clean($_POST['medical_id']);
	
	$balance = ($_POST['balance']);
	$current_balance = ($_POST['current_balance']);
	$total_mec = ($_POST['total_mec']);

	$result =addHR($medical_id,$balance,$current_balance,$total_mec);
	//Check whether the query was successful or not
	
if($result!="" && $result > 0)

	
	{
		echo ("<script LANGUAGE='JavaScript'>
						window.location.href='../view/aims_lv_medicalver_list.php';
						</script>");
		//header("location: ../view/list_faq.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>









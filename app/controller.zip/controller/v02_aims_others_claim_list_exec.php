<?php
//print_r($_POST);
//echo '<br>';
//print_r($_FILES);
//exit();

include "../model/v02_aims_others_claim_function.php";

//Sanitize the POST values
$no_staff = $_POST['no_staff'];
$company_name = $_POST['company_name'];
$job_no = $_POST['jobno'];
$date = $_POST['date_claim'];
/*nl2br() function-> Insert line breaks where newlines (\n) occur in the string*/
$description = nl2br($_POST['description']);
$month_claim = $_POST['month_claim'];
$detail_claim = $_POST['desc'];
$rm_input = $_POST['rm_input'];
$total_claim = $_POST['total_input'];
$targetDir = "../../othersclaimphoto/";

if($_FILES['document']['size'] > 0) {
    $image_document = $_FILES['document']['tmp_name'];
    $document_name = $_FILES['document']['name'];
    $document_size = $_FILES['document']['size'];
    $targetPath = $targetDir . $document_name;
    move_uploaded_file($image_document,$targetPath);
}
else {
    $document_name = "";
    $document_size = 0;
}

/*$insert_claim = v02addOthersClaim($no_staff, $date, $description, $job_no, $month_claim, $total_claim, $document_name, $document_size );*/
$insert_claim = v02addOthersClaim($no_staff, $date, $description, $job_no, $month_claim, $total_claim, $document_name, $document_size );



/*$array = explode("\n", $_POST['description']);
$i=0;
$value = trim($array[$i]);
if (!empty($value)) {
    foreach ($array as $value) {
        $insert_claim = v02addOthersClaim($no_staff, $date, $array[$i], $job_no, $month_claim, $total_claim, $document_name, $document_size );
        $i++;
    }
}*/




foreach ($detail_claim as $index => $cost_centre_id){
    $result = v02addClaimCostCentre($cost_centre_id, $rm_input[$index], $insert_claim);
}


//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Claim successfully added.')
            window.location.href='../view/v02_aims_others_claim_list.php';
            </script>");
    exit();
} else {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Failed to add claim.')
            history.back();
            </script>");
    exit();
}

?>
<?php

echo "This is testloader page for IT maintenance purpose only";
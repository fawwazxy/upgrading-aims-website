<?php
   	include "../model/aims_gl_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	
	$id = clean($_POST['id']);
	$room_no = clean($_POST['room_no']);
	$capacity = clean($_POST['capacity']);
	$bed_type = clean($_POST['bed_type']);
	$status = clean($_POST['status']);
	

	$result = updateRoom($room_no,$capacity,$bed_type,$status,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_gl_room.php';
            </script>");
		//header("location: ../view/aims_billing_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
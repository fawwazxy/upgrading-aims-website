<?php
	
	include "../model/functions.php";

	//Start session
    session_start();
	
	//Sanitize the POST values
	$username = clean($_POST['username']);
	$password = clean($_POST['password']);
	
	//Call function
	$login = login($username,$password);
	
	//Check whether the query was successful or not
	if ($login -> num_rows == 1) {
		$row = $login->fetch_assoc();
		//start jana tarikh bekerja
		if($row['role_id']=="SUPERADMIN" || $row['role_id']=="ADMIN" ){

		}else{
			if(checkTahunAvailbility(date('Y'),$row['no_staff'])>0){
			}else{
			$date = date('Y').'-01-01';
			
			$end_date = date('Y').'-12-31';
			$sys_id='1';
		    
		     janaHujungMinggu($sys_id,$row['no_staff']);

			while (strtotime($date) <= strtotime($end_date)) {
				$hari=date("l", strtotime($date));
				$hari_minggu = getStatusHujungMinggu($hari,$row['no_staff'])->fetch_assoc();
				if($hari_minggu['status']=='1'){
					$status='0';
				}else{
					$status='1';
				}
						$result = janaTarikh($sys_id,$date,$status,$row['no_staff']);
						$date = date ("Y-m-d", strtotime("+1 day", strtotime($date)));
			}
		}
	} 
		//end jana tarikh bekerja
		
		session_regenerate_id();
		$_SESSION['SESS_ID'] = $row['id'];
		$_SESSION['SYS_ID'] = $row['sys_id'];
		$_SESSION['SESS_NAME'] = $row['name'];
		$_SESSION['SESS_COM'] = $row['company_id'];
		$_SESSION['SESS_STATUS'] = $row['status'];
		$_SESSION['SESS_ROLE'] = $row['role_id'];
		$_SESSION['SESS_NO_STAFF'] = $row['no_staff'];
		$_SESSION['SESS_NOKP'] = $row['noic'];
		$_SESSION['SESS_CAWANGAN'] = $row['cawangan_kod'];
		$_SESSION['SESS_DEPARTMENT'] = $row['department_id'];
		$_SESSION['SESS_DEPARTMENT_SUB'] = $row['department_sub'];
		session_write_close();
		
		if ($row['role_id'] != '') {
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/dashboard.php';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		} else {
			$fail = 'Sorry, site under maintenance.';
			echo "<script> alert(\"$fail\"); location.href = '../view/login.php';</script>";
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/login.php';
            </script>");
			//header("location: ../view/login.php");
			exit();
		}
		
		
	} else {
		//Login failed
		$fail = 'Log Masuk Gagal.\nNama atau Kata Laluan salah.';
		echo "<script> alert(\"$fail\"); location.href = '../view/login.php';</script>";
		exit();
	}
	
	//$conn->close();
?>
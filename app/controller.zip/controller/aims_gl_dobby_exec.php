<?php
   	include "../model/aims_gl_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	
	$dobby_date = clean($_POST['dobby_date']);
	$amount = clean($_POST['amount']);
	$created_by = clean($_POST['created_by']);
	

	$result = addDobby($dobby_date,$amount,$created_by);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_gl_dobby.php';
            </script>");
		//header("location: ../view/aims_billing_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
<?php
   	include "../model/aims_car_admin.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	
	$id = clean($_POST['id']);
	$app_status = clean($_POST['app_status']);
	$reason = clean($_POST['reason']);
	$name_admin = clean($_POST['name_admin']);
	$descrip = clean($_POST['descrip']);
	$department = clean($_POST['department']);
	$created_by = clean($_POST['created_by']);
	$status = clean($_POST['status']);

	$result =addCarAdmin($app_status,$reason,$name_admin,$descrip,$department,$created_by,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0 && $status=="admin") 
	
	{
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_car_adUse_list.php?app_status=$app_status';
            </script>");
		
		exit();
	}
	else if($result!="" && $result > 0 && $status=="company") 
	
	{
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_car_companyapp.php?app_status=$app_status';
            </script>");
		
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
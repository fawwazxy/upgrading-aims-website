<?php
require "../model/v02_aims_others_claim_function.php";
$id = $_POST['id']; //company_id
$no_staff = $_POST['nostaff'];

$result = v02getDropdownCostCentreByCompany($id,$no_staff);
?>
    <option value="">-- Select Company First --</option>

<? while($row = $result->fetch_assoc()){
    ?>
    <option value="<? echo $row['id'] ?>"><? echo $row['description'] ?></option>
<? } ?>
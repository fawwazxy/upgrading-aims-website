<?php
	
	include "../model/aims_carReserve_function.php";

	//Start session
    session_start();
	
	//Sanitize the POST values
	$username = clean($_POST['username']);
	$password = clean($_POST['password']);
	
	//Call function
	$login = login($username,$password)->fetch_assoc();

		if ($login['username'] == 'AGHSB') {
			echo ("<script LANGUAGE='JavaScript'>
		    window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}

		else if ($login['username'] == 'AGESB') {
			echo ("<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else if ($login['username'] == 'AGMHSB') {
			echo ("<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else if ($login['username'] == 'AGIRSB') {
			echo ("<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else if ($login['username'] == 'AGMASB') {
			echo ("<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else if ($login['username'] == 'AVSB') {
			echo ("<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany.php?department_id=$username';
            </script>");
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else if ($login['username'] == 'ADMIN') {
			echo "<script LANGUAGE='JavaScript'>
			window.location.href='../view/../view/aims_carinspection_list_bycompany_admin.php';
            </script>";
			//header("location: ../view/dashboard.php");
			exit();
		}
		
		else {
		$fail = 'Log Masuk Gagal.\nNama atau Kata Laluan salah.';
		echo "<script> alert(\"$fail\"); location.href = '../view/aims_car_login.php';</script>";
		exit();
		}
		
		
	 
	
	//$conn->close();
?>
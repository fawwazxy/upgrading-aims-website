<?php
   	include "../model/aims_car_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$id =$_POST['id'];
	$car_model =$_POST['car_model'];
	$car_plate_no = $_POST['car_plate_no'];
	$car_type = $_POST['car_type'];
	$car_owner =$_POST['car_owner'];
	$car_pic =$_POST['car_pic'];
	$car_pic2 =$_POST['car_pic2'];
	$car_location = $_POST['car_location'];
	$car_status =$_POST['car_status'];
	$car_category =$_POST['car_category'];
	$engine_no =$_POST['engine_no'];
	$chassis_no =$_POST['chassis_no'];
	$cost_receipt =$_POST['cost_receipt'];
	$date_receipt =$_POST['date_receipt'];
	$suppliers =$_POST['suppliers'];
	$hire_account_no =$_POST['hire_account_no'];
	$name_account =$_POST['name_account'];
	$color =$_POST['color'];
	$updated_by =$_POST['updated_by'];
	if($_FILES['document']['size'] > 0) {

		$image_document = $_FILES['document']['tmp_name'];
		$documentAllowType = array('jpg','png','jpeg','gif','pdf');
		$imgContent_doc = addslashes(file_get_contents($image_document));
    	$document_name = $_FILES['document']['name'];
		$fileType = end((explode(".",$document_name)));
	}
	else {
		$imgContent_doc = "";
		$document_name = "";
		$fileType = "";
	}
	

	$result = updatecar($car_model,$car_plate_no,$car_type,$car_owner,$car_pic,$car_pic2,$car_location,$car_status,$car_category,$engine_no,$chassis_no,$cost_receipt,$date_receipt,$suppliers,$hire_account_no,$name_account,$color,$updated_by,$imgContent_doc,$document_name,$fileType,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_car_list.php';
            </script>");
		//header("location: ../view/aims_car_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
<?
	include "../model/lkp_function.php";

 $action = $_GET['act'];

if ($action == "department_list_add"){
	//$id=($_GET['id_project']);
	
	 $code_department =$_POST['code_department'];
	 $description =$_POST['description'];
	 $leave_approval =$_POST['leave_approval'];
	// $company_id =$_POST['company_id'];

	$result = addDepartment($code_department, $description, $leave_approval);

	//Check whether the query was successful or not
	if($result) {
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/department_list.php?status=1&flagScreen=tab_1';
            </script>");
		//header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		exit();
	}else {
		echo "<script> alert('Proses tidak berjaya.'); location.href = '../view/department_list.php?status=1&flagScreen=tab_1';</script>";
			exit();
	}


}else if($action == "department_list_status"){
		$department_id= ($_GET['id']);
		$status= ($_GET['status']);
	
    $result = updateStatusDepartment($status,$department_id);
      
	//Check whether the query was successful or not
	if($result) {
		if($status==1){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/department_list.php?status=0&flagScreen=tab_1';
            </script>");
		 //header("location: ../view/department_list.php?status=0&flagScreen=tab_2");
		}else if($status==0){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/department_list.php?status=1&flagScreen=tab_1';
            </script>");
		 //header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		 }
		exit();
		
	}else {
		die("Query failed");
	}
	

}else if ($action == "lokasi_list_add"){
	//$id=($_GET['id_project']);
	
	 $cawangan_kod =$_POST['cawangan_kod'];
	 $nama =$_POST['nama'];
	 
	// $company_id =$_POST['company_id'];

	$result = addLokasi($cawangan_kod, $nama);

	//Check whether the query was successful or not
	if($result) {
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/lokasi_list.php?status=1&flagScreen=tab_2';
            </script>");
		//header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		exit();
	}else {
		echo "<script> alert('Proses tidak berjaya.'); location.href = '../view/lokasi_list.php?status=1&flagScreen=tab_2';</script>";
			exit();
	}


}else if($action == "lokasi_list_status"){
		$lokasi_id= ($_GET['id']);
		$status= ($_GET['status']);
	
    $result = updateStatusLokasi($status,$lokasi_id);
      
	//Check whether the query was successful or not
	if($result) {
		if($status==1){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/lokasi_list.php?status=0&flagScreen=tab_2';
            </script>");
		 //header("location: ../view/department_list.php?status=0&flagScreen=tab_2");
		}else if($status==0){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/lokasi_list.php?status=1&flagScreen=tab_2';
            </script>");
		 //header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		 }
		exit();
		
	}else {
		die("Query failed");
	}
}else if ($action == "sub_department_list_add"){
	//$id=($_GET['id_project']);
	
	 $code_department =$_POST['code_department'];
	 $description =$_POST['description'];
	 $sub_code_department =$_POST['sub_code_department'];
	// $company_id =$_POST['company_id'];

	$result = addSubDepartment($code_department, $description, $sub_code_department);

	//Check whether the query was successful or not
	if($result) {
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/sub_department_list.php?status=1&flagScreen=tab_3';
            </script>");
		//header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		exit();
	}else {
		echo "<script> alert('Proses tidak berjaya.'); location.href = '../view/sub_department_list.php?status=1&flagScreen=tab_3';</script>";
			exit();
	}


}else if($action == "sub_department_list_status"){
		$department_id= ($_GET['id']);
		$status= ($_GET['status']);
	
    $result = updateStatusSubDepartment($status,$department_id);
      
	//Check whether the query was successful or not
	if($result) {
		if($status==1){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/sub_department_list.php?status=1&flagScreen=tab_3';
            </script>");
		 //header("location: ../view/sub_department_list.php?status=0&flagScreen=tab_2");
		}else if($status==0){
			echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/sub_department_list.php?status=0&flagScreen=tab_3';
            </script>");
		 //header("location: ../view/department_list.php?status=1&flagScreen=tab_1");
		 }
		exit();
		
	}else {
		die("Query failed");
	}
	

}

?>
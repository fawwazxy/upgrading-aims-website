<?php
   	include "../model/aims_carReserve_function.php";
    
	
	$id = ($_POST['id']);
	$reserve_id = clean($_POST['reserve_id']);
	$status = clean($_POST['status']);
	$mileage_fuel = clean($_POST['mileage_fuel']);
	$receipt_fuel = clean($_POST['receipt_fuel']);
	$receipt_date = clean($_POST['receipt_date']);
	$targetDir = "../../fuel_photo/";
	if($_FILES['document']['size'] > 0) {
		
		$image_document = $_FILES['document']['tmp_name'];
	    $documentname = $_FILES['document']['name'];
	    $document_type = end((explode(".",$documentname)));
	    $document_name_only = array_shift(explode(".",$documentname));
	    date_default_timezone_set("Asia/Kuala_Lumpur");
	    $randomnum=rand(0,100000);
	    $rename= $document_name_only.date('Ymd').$randomnum;
	    $document_name=$rename.'.'.$document_type;
	    
	    $targetPath = $targetDir . $document_name;
	  	move_uploaded_file($image_document,$targetPath);
	}
	else {
		$document_name = "";
	}
	
	if($_FILES['file']['size'] > 0) {
		
		$image_file = $_FILES['file']['tmp_name'];
	    $filename = $_FILES['file']['name'];
	    $file_type = end((explode(".",$filename)));
	    $file_name_only = array_shift(explode(".",$filename));
	    date_default_timezone_set("Asia/Kuala_Lumpur");
	    $randomnums=rand(0,100000);
	    $renames= $file_name_only.date('Ymd').$randomnums;
	    $file_name=$renames.'.'.$file_type;
	    
	    $targetPaths = $targetDir . $file_name;
	  	move_uploaded_file($image_file,$targetPaths);
	}
	else {
		$file_name = "";
	}
	
	if($id > 0 ){
		$sql="SELECT document_name, file_name FROM aims_car_fuel WHERE id='$id'";
	    $getFileName = db()->query($sql)->fetch_assoc();
		if(!empty($getFileName['document_name'])){
			unlink($targetDir.$getFileName['document_name']);
		}
		if(!empty($getFileName['file_name'])){
			unlink($targetDir.$getFileName['file_name']);
		}
		
		$result = updateCarFuel($mileage_fuel,$receipt_fuel,$document_name,$document_type,$file_name,$file_type,$id, $receipt_date);
	}
	else {
		$result = addCarFuel($reserve_id,$status,$mileage_fuel,$receipt_fuel,$document_name,$document_type,$file_name,$file_type, $receipt_date);	
	}
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	{

		echo ("<script LANGUAGE='JavaScript'>
						window.location.href = '../view/aims_car_fuelclaim_form.php?id=".$reserve_id."';
						</script>");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
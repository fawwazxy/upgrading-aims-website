<?
include "../model/v02_aims_others_claim_function.php";

$id = $_GET['id'];

$result = v02DeleteOthersClaimRemarks($id);

//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Remarks successfully deleted.')
            history.back();
            </script>");
    exit();
} else {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Failed to delete remarks.')
            history.back();
            </script>");
    exit();
}
?>

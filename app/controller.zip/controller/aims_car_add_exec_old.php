<?php
   	include "../model/aims_car_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$car_model = clean($_POST['car_model']);
	$car_plate_no = clean($_POST['car_plate_no']);
	$car_type = clean($_POST['car_type']);
    $car_owner = clean($_POST['car_owner']);
	$car_pic = clean($_POST['car_pic']);
	$car_pic2 = clean($_POST['car_pic2']);
	$car_location = clean($_POST['car_location']);
	$car_category = clean($_POST['car_category']);
	$engine_no = clean($_POST['engine_no']);
	$chassis_no = clean($_POST['chassis_no']);
	$cost_receipt = clean($_POST['cost_receipt']);
	$date_receipt = clean($_POST['date_receipt']);
	$suppliers = clean($_POST['suppliers']);
	$hire_account_no = clean($_POST['hire_account_no']);
	$name_account = clean($_POST['name_account']);
	$color = clean($_POST['color']);
	if($_FILES['document']['size'] > 0) {

		$image_document = $_FILES['document']['tmp_name'];
		$documentAllowType = array('jpg','png','jpeg','gif','pdf');
		$imgContent_doc = addslashes(file_get_contents($image_document));
    	$document_name = $_FILES['document']['name'];
		$fileType = end((explode(".",$document_name)));
	}
	else {
		$imgContent_doc = "";
		$document_name = "";
		$fileType = "";
	}
	
	//$id = ($_POST['id']);

	$result = addcar($car_model,$car_plate_no,$car_type,$car_owner,$car_pic,$car_pic2,$car_location,$car_status,$car_category,$engine_no,$chassis_no,$cost_receipt,$date_receipt,$suppliers,$hire_account_no,$name_account,$color, $imgContent_doc, $document_name, $fileType);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_car_list.php';
            </script>");
		//header("location: ../view/aims_car_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
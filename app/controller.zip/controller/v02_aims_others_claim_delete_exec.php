<?php

include "../model/v02_aims_others_claim_function.php";

$id = $_GET['id'];

$result =  v02DeleteClaim($id);

$result2 = v02deleteTypeClaimByClaimId($id);

//Check whether the query was successful or not
if($result) {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Claim successfully delete.')
            window.location.href='../view/v02_aims_others_claim_list.php';
            </script>");
    exit();
} else {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Failed to delete claim.')
            history.back();
            </script>");
    exit();
}

?>

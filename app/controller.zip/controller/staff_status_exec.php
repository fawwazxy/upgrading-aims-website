<?php

include "../model/staff_function.php";

    $id = clean($_GET['id']);
	$no_staff= clean($_GET['no_staff']);
	
	
	$result= UpdateStatusStaff($no_staff);
	//$result=UpdateStatus($no_staff);
	
	if($result) {
		echo ("<script LANGUAGE='JavaScript'>
				            window.location.href='../view/staff_info.php?id=$id&no_staff=$no_staff';
				            </script>");
		//header("location: ../view/staff_info.php?id=".$id."&no_staff=".$no_staff);
		exit();
	}else {
		die("Query failed");
	}
	
	?>
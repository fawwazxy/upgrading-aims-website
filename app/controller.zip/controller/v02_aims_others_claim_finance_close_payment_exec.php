<?php
require "../model/v02_aims_others_claim_function.php";

$id = $_GET['id'];
$nostaff = $_GET['nostaff'];
$result = v02closeOtherClosedPayment($id,$nostaff);

//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script>
			alert('Successfully Close Payment for selected claim');
			window.history.back();
			</script>");
    exit();
} else {
    echo ("<script>
			alert('Failed to close payment!');
			window.history.back();
			</script>");
    exit();
}

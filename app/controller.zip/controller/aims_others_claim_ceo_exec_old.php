<?php
   	include "../model/aims_others_claim_function.php";

	$id = ($_POST['id']);
	$month=($_POST['month']);
	$tahun=($_POST['tahun']);
	$approve_status = ($_POST['approve_status']);
	$approve_by =($_POST['approve_by']);
	$company =($_POST['company']);
	
	 $result = updateStaff3($id,$month,$approve_by,$approve_status,$company,$tahun);

	//Check whether the query was successful or not
	if($result!="" && $result > 0)
	{
		echo ("<script LANGUAGE='JavaScript'>
						window.location.href='../view/aims_others_claim_ceo_list.php?approve_status=$approve_status';
						</script>");
		//header("location: ../view/list_faq.php");
		exit();
	}
	else 
	 {
		die("Query failed");
	 }
	
?>










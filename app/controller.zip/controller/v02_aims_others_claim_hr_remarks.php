<?
include "../model/v02_aims_others_claim_function.php";

$id = $_POST['id'];
$remarks = $_POST['addRemarks'];

$result = v02addOthersClaimRemarks($id, $remarks);

//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Remarks successfully added.')
            history.back();
            </script>");
    exit();
} else {
    echo ("<script LANGUAGE='JavaScript'>
            alert('Failed to add remarks.')
            history.back();
            </script>");
    exit();
}
?>

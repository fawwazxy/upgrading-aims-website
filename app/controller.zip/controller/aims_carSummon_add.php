<?php
   	include "../model/aims_carReserve_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$reserve_id = clean($_POST['reserve_id']);
	$issue_distric = clean($_POST['issue_distric']);
	$summons_no = clean($_POST['summons_no']);
	$offense = clean($_POST['offense']);
    $enforcement_date = clean($_POST['enforcement_date']);
	$offense_details = $_POST['offense_details'];
	$original_amount = ($_POST['original_amount']);   
	$name = clean($_POST['name']);
	$car_plate_no = clean($_POST['car_plate_no']);
	$company_name = clean($_POST['company_name']);
	$destination = clean($_POST['destination']);
	
	//$id = ($_POST['id']);

	if($id== 0){
		$result = addcarsummonWithoutReserveId($summon_by,$issue_distric,$summons_no,$offense,$enforcement_date,$offense_details,$original_amount,$name, $car_plate_no, $company_name,$destination);
	}
	else{

		$result = addcarsummon($reserve_id,$summon_by, $issue_distric,$summons_no,$offense,$enforcement_date,$offense_details,$original_amount);
	}

	
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{

		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_carSummon_list.php';
            </script>");
		//header("location: ../view/aims_carSummon_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
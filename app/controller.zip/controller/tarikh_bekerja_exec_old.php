<?php

include "../model/tarikh_bekerja_functions.php";
	
	$action=clean($_GET['action']);
	if($action == "jana_tarikh"){
		
		$date = date('Y').'-01-01';
		
		$end_date = date('Y').'-12-31';
		$sys_id='1';
	   
		while (strtotime($date) <= strtotime($end_date)) {
			echo $hari=date("l", strtotime($date));
			$hari_minggu = getStatusHujungMinggu($hari)->fetch_assoc();
			if($hari_minggu['status']=='1'){
				$status='0';
			}else{
				$status='1';
			}
					$result = janaTarikh($sys_id,$date,$status);
					$date = date ("Y-m-d", strtotime("+1 day", strtotime($date)));
		}
		if($result) {
			echo ("<script LANGUAGE='JavaScript'>
				            window.location.href='../view/penentuan_tarikh_bekerja.php';
				            </script>");
			//header("location: ../view/penentuan_tarikh_bekerja.php");
			exit();
		}else {
			die("Query failed");
		}
	}else if($action == "editStatus"){
		$tarikh_ids=$_POST['tarikh_ids'];
		if(empty($tarikh_ids)) {
			$result = tarikhBekerjaInactive(date('Y'));
		}else {
			
			tarikhBekerjaInactive(date('Y'));

			foreach($tarikh_ids as $tarikh_id){
				
				$result = tarikhBekerjaActive($tarikh_id);
			}


		}
		echo ("<script LANGUAGE='JavaScript'>
				            window.location.href='../view/penentuan_tarikh_bekerja.php';
				            </script>");
		//header("location: ../view/penentuan_tarikh_bekerja.php");
		exit();
		
	}else if($action == "editStatusHujungMinggu"){
		$hari_ids=$_POST['hari_ids'];
		$endDate = date(Y).'-12-31';
		if(empty($hari_ids)) {
			$result = tarikhHujungMingguInactive();
		}else {
			
			tarikhHujungMingguInactive(date('Y'));
			updateStatusHariBekerjaActive($endDate);

			foreach($hari_ids as $hari_id){
				$hari=getHariById($hari_id);
				updateStatusHariBekerjaInactive($hari,$endDate);
				$result = tarikhHujungMingguActive($hari_id);
			}


		}
		echo ("<script LANGUAGE='JavaScript'>
				            window.location.href='../view/penentuan_tarikh_bekerja.php';
				            </script>");
		//header("location: ../view/penentuan_hujung_minggu.php");
		exit();
		
	}
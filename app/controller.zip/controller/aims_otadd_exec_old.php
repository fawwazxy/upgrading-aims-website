<?php
include "../model/aims_ot_function.php";

//sanitize the POST values
//$title = clean($_POST['title']);
$staff_name = clean($_POST['staff_name']);
$icno = clean($_POST['icno']);
$company_id = clean($_POST['company_id']);
$position = clean($_POST['position']);
$month_claim = clean($_POST['month_claim']);
$date_ot = clean($_POST['date_ot']);
$day_ot = clean($_POST['day_ot']);
$start_ot = clean($_POST['start_ot']);
$end_ot = clean($_POST['end_ot']);
$working_hours = clean($_POST['working_hours']);
$type_claim = clean($_POST['type_claim']);
$description_ot = clean($_POST['description_ot']);
$no_staff = clean($_POST['no_staff']);
$staff_record_id = clean($_POST['staff_record_id']);

$targetDir = "../../overtimephoto/";
	if($_FILES['document']['size'] > 0) {
		
		$document_size = $_FILES['document']['size'];
		$image_document = $_FILES['document']['tmp_name'];
	    $document_name = $_FILES['document']['name'];
		$document_type = end((explode(".",$document_name)));
	    $targetPath = $targetDir . $document_name;
	    
	    if($document_type == 'JPG' || $document_type == 'JPEG' || $document_type == 'PNG' || $document_type == 'gif'){
            $compressedImage = compressImage($image_document, $targetPath, 60); 
	    }
        else {
	  	    move_uploaded_file($image_document,$targetPath);
        }
	}
	else {
		$document_name = "";
	}

$result = addOt($staff_name,$icno,$company_id,$position,$month_claim,$date_ot,$day_ot,$start_ot,$end_ot,$working_hours,$type_claim,
$description_ot,$no_staff,$staff_record_id,$document_name,$document_type,$document_size);


function compressImage($source, $destination, $quality) { 
    // Get image info 
    $imgInfo = getimagesize($source); 
    $mime = $imgInfo['mime']; 
     
    // Create a new image from file 
    switch($mime){ 
        case 'image/jpeg': 
            $image = imagecreatefromjpeg($source); 
           imagejpeg($image, $destination, $quality);
            break; 
        case 'image/png': 
            $image = imagecreatefrompng($source); 
            imagepng($image, $destination, $quality);
            break; 
        case 'image/gif': 
            $image = imagecreatefromgif($source); 
            imagegif($image, $destination, $quality);
            break; 
        default: 
            $image = imagecreatefromjpeg($source); 
           imagejpeg($image, $destination, $quality);
    } 
     
     
    // Return compressed image 
    return $destination; 
} 

//check wheter the query was succesful or not
if($result!="" && $result > 0)
{
    
    echo ("<script LANGUAGE='JavaScript'>
	
	window.location.href='../view/aims_ot_list.php';
	</script>");
	exit();
    
/*	echo ("<script LANGUAGE='JavaScript'>
	if (confirm('\\nOVERTIME SUCCESFULLY SUBMITTED!\\n\\nAdd more overtime?')) {
  // Save it!
      window.history.back();
    } else {
      // Do nothing!
      window.location.href='../view/aims_ot_list.php';
      
    }
	</script>");
	exit(); */
}
else
{
	die("Query failed");
}

            
             
          
?>

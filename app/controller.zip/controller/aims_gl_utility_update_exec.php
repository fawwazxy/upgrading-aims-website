<?php
   	include "../model/aims_gl_function.php";
    
	
	//Sanitize the POST values
	
	//$title = clean($_POST['title']);
	$id = clean($_POST['id']);
	$utility_desc_id = clean($_POST['utility_desc_id']);
	$no_20 = clean($_POST['no_20']);
	$no_21 = clean($_POST['no_21']);
	$total = clean($_POST['total']);
	$month = clean($_POST['month']);
	$year = clean($_POST['year']);
	
	
    	
	
	//$id = ($_POST['id']);

	$result = updateUtility($utility_desc_id, $no_20, $no_21, $total, $month, $year,$id);
	
	//Check whether the query was successful or not
	if($result!="" && $result > 0) 
	
	{
		
		echo ("<script LANGUAGE='JavaScript'>
            window.location.href='../view/aims_gl_utility.php';
            </script>");
		//header("location: ../view/aims_gl_booking_list.php");
		exit();
	}
	else 
	{
		die("Query failed");
	}
	
?>
<?php
   	include "../model/aims_others_claim_hod_function.php";
    
	
	$id = ($_POST['id']);
	$month=($_POST['month']);
	$hod_review_status = ($_POST['hod_review_status']);
	$hod_review_by = ($_POST['hod_review_by']);
	
	 $result =updateStaff($id,$month,$hod_review_by,$hod_review_status);

	//Check whether the query was successful or not
	if($result!="" && $result > 0)
	{
		echo ("<script LANGUAGE='JavaScript'>
						window.location.href='../view/aims_others_claim_hod_list.php?hod_review_status=$hod_review_status';
						</script>");
		//header("location: ../view/list_faq.php");
		exit();
	}
	else 
	 {
		die("Query failed");
	 }
	
?>










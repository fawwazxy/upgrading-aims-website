<?php

include "../model/staff_function.php";
	
	$action=clean($_POST['action']);
	if($action == "login_edit"){                       
		$no_staff = $_POST['no_staff'];          
		$old_laluan = $_POST['old_laluan'];          
		$username = $_POST['username'];          
		$password = $_POST['password'];          
		$cfrm_password = $_POST['cfrm_password'];    

		$staff = getPekerja($no_staff)->fetch_assoc(); 

		//start validate
		if($old_laluan != $staff['accs_pwd']){
			//alert wrong old password
			echo "<script> alert('Kata Laluan lama tidak sama!!'); location.href = '../view/login_edit.php';</script>";
		}else if($password != $cfrm_password){
			//alert wrong confirmation
			echo "<script> alert('Kata Laluan yang baharu tidak sah!!'); location.href = '../view/login_edit.php';</script>";
		}else{
			updateKataLaluan($no_staff,$old_laluan,$username,$password);
			echo ("<script LANGUAGE='JavaScript'>
				            window.location.href='../view/login_edit.php';
				            </script>");
			//header("location: ../view/login_edit.php");
			exit();
		}     

		

		//echo "Sistem mengalami masalah. Sila laporkan";
		
	}
	
?>
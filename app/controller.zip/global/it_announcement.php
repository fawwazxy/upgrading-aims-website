<div class="col-lg-12">
    <blockquote class="migration-message bg-gradient-danger">
        <span class="blink-me" style="font-weight: bolder">
            On <b>Thursday, 29th September 2022</b> at <b>8:00pm until 11.00pm</b>, I-Office will be closed for MAINTENANCE purpose. <br>
            All access and functions will be blocked during this period. Please make any necessary preparations before the maintenance starts.
        </span><br>
        <span class="blink-me" style="font-size: 12px">
            Pada <b>Khamis, 29 September 2022</b> pada <b>8:00 malam hingga 11.00 malam</b>, I-Office akan ditutup untuk tujuan PENYELENGGARAAN. <br>
            Semua akses dan fungsi akan disekat dalam tempoh tersebut. Sila buat sebarang persediaan yang perlu sebelum penyelenggaraan bermula.
        </span>
    </blockquote>
</div>

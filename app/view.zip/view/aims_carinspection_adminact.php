<?php

	include ('../controller/auth.php');

	require "../model/aims_carReserve_function.php";
       
$id = $_GET['id'];
$month = $_GET['month'];
$raw_data1 = getcarinspectionById($id)->fetch_assoc();
 ?> 

                     
                <form method="post" action="../controller/aims_carinspection_adminact_exec.php?" >     
                         <div class="form-group" align="left">
                              
                             
                            <label><font color="red">** Maklumat Wajib Diisi.</font></label>
                            <br>
							<input id="id" name="id" type="hidden" value="<?php echo $id?>"/>
							<input id="month" name="month" type="hidden" value="<?php echo $month?>"/>
							<input id="admin_actby" name="admin_actby" type="hidden" value="<?php echo $_SESSION['SESS_NAME'] ?>"/>
							
							
                                
                                <div class="form-group"  align="left">
								<label>STATUS ACTION:</label></br>
								<input type="radio" name="admin_action" <?php if($raw_data1['admin_action']=="PENDING") {echo "checked";}?> value="PENDING"> PENDING
								<input type="radio" name="admin_action" <?php if($raw_data1['admin_action']=="CHECK") {echo "checked";}?> value="CHECK"> CHECK
                                </div>

                                <div class="form-group"  align="left">
                                  <label>COSTING</label>
                                  <input class="form-control" placeholder="" name="costing" value="<?php echo $raw_data1['costing'] ?>" style="text-transform:uppercase" onkeyup="convertToUppercase(this)">
                                </div>

                                <div class="form-group"  align="left">
                                  <label>DESCRIPTION<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder="" name="description" required autocomplete="" value="<?php echo $raw_data1['description'] ?>" style="text-transform:uppercase" onkeyup="convertToUppercase(this)">
                                </div>	



                             <div class="modal-footer">
                                   <button type="submit" class="btn btn-primary">Save</button>
                                   <button type="reset" class="btn btn-info">Reset</button>
                             </div>
         
         </form>
        <script>
				function convertToUppercase(el) {
					if(!el || !el.value) return;
					el.value = el.value.toUpperCase();
				}
			</script>
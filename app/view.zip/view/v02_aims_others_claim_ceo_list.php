<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
require "../model/lookup.php";

$no_staff = $_SESSION['SESS_NO_STAFF'];
$id = $_SESSION['SESS_ID'];
$department = $_SESSION['SESS_DEPARTMENT'];
$department_sub = $_SESSION['SESS_DEPARTMENT_SUB'];
$department_code=$_GET['department_code'];
if(!isset($department_code)){
    $department_code = 'SB';
}
$sys = getSys(1)-> fetch_assoc();
$verified_name = $_SESSION['SESS_NAME'];
$verification = ($_GET['verification'])?: 'PENDING';

$user_status = v02getIC($id)->fetch_assoc();
if ($user_status['noic'] == '751206035485'){
    $user = 'CEO';
} elseif ($user_status['noic'] == '660512115105'){
    $user = 'CHAIRMAN';
} else {
    /*blank*/
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <? require "../global/header.php"; ?>
    <style>
        .claim-status{
            padding:3px;
            border-radius: 5px;
            font-weight:bold;
            color: #ffffff;
        }

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab a {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 16px;
            text-decoration: none;
            color: #000000;
            border-radius: 5%;
        }

        /* Change background color of buttons on hover */
        .tab a:hover {
            background-color: #ddd;
            text-decoration: none;
        }

        /* Create an active/current tablink class */
        .tab a.active {
            background-color: #FFA500;
        }

        /* Style the tab content */
        .tabContent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
</head>
<body>

<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <? include ('../global/menu_top.php'); ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
        </div>
    </nav>

    <div id="page-wrapper">
        <!--<?include '../global/menu_keselamatan.php'?>-->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> <? echo $user ?> APPROVAL
                    <a href="aims_others_claim_ceo_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>Switch to Version 01
                    </a>
                </h1>
            </div>
        </div>

        <div class="tab">
            <a href="v02_aims_others_claim_ceo_list.php?department_code=<? echo $department_code;?>&verification=PENDING"
               class="tabLinks <? if($verification == "PENDING") echo 'active'?>">
                NEW </a>
            <a href="v02_aims_others_claim_ceo_list.php?department_code=<? echo $department_code;?>&verification=APPROVED"
               class="tabLinks <? if($verification == "APPROVED") echo 'active'?>">
                APPROVED </a>
            <a href="v02_aims_others_claim_ceo_list.php?department_code=<? echo $department_code;?>&verification=DISAPPROVED"
               class="tabLinks <? if($verification == "DISAPPROVED") echo 'active'?>">
                DISAPPROVED </a>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">

                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <input name="id" type="hidden" class="input-short" value="<? echo $id;?>" />
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th style="text-align:center;" width="5%">No.</th>
                                <th style="text-align:center;" width="20%">Staff Info</th>
                                <th style="text-align:center;" width="20%">Month Claim</th>
                                <th style="text-align:center;" width="20%">HOD Status</th>
                                <th style="text-align:center;" width="20%">HR Status</th>
                                <th style="text-align:center;" width="20%">Finance Status</th>
                                <th style="text-align:center;" width="20%">CEO/CHAIRMAN Status</th>
                                <th style="text-align:center;" width="10%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?
                            //List every staff and month claim in a single row e.g. 011212-11-6312 -- August 2022;
                            $claim_by_month = v02getMonthClaimListCEO($department_code, $no_staff, $verification, $month, $year);
                            $i = 1;
                            while($month_claim = $claim_by_month->fetch_assoc()){

                                if ($verification == "PENDING") {
                                    $status_color = 'GREY';
                                } else if ($verification == "APPROVED") {
                                    $status_color = 'GREEN';
                                }else{
                                    $status_color = 'RED';
                                }

                                $ceo_cc = v02HRgetClaimListCEO($month_claim['no_staff'], $month_claim['month_claim'], $verification)

                            ?>
                            <tr>
                                <td><? echo $i++?></td>
                                <td>
                                    <b>Name:</b> <?echo $month_claim['name'];?><br>
                                    <b>IC No:</b> <?echo $month_claim['noic'];?><br>
                                    <b>Position:</b> <?echo $month_claim['role_id'];?><br>
                                    <b>Department:</b> <?echo $month_claim['department_sub'];?><br>
                                    <b>Company:</b> <?echo $month_claim['department_id'];?>
                                </td>
                                <td class="text-center"><? echo $month_claim['month_claim']; ?></td>
                                <!--HOD Status-->
                                <td class="text-center">
                                    <p class="claim-status" style="background-color: green">VERIFIED</p>
                                    <? echo v02getStaffName($month_claim['verify_by'])?>
                                    <? echo '<br>'. $month_claim['verify_at']?>
                                </td>
                                <!--HR Status-->
                                <td class="text-center">
                                    <p class="claim-status" style="background-color: green">REVIEWED</p>
                                    <? echo v02getStaffName($month_claim['review_by'])?>
                                    <? echo '<br>'. $month_claim['review_at']?>
                                </td>
                                <!--Finance Status-->
                                <td class="text-center">
                                    <p class="claim-status" style="background-color: green">CHECKED</p>
                                    <? echo v02getStaffName($month_claim['finance_by'])?>
                                    <? echo '<br>'. $month_claim['finance_at']?>
                                </td>
                                <!--CEO/Chairman Status-->
                                <td class="text-center">
                                    <p class="claim-status" style="background-color: <? echo $status_color; ?>">
                                        <? echo $verification.' ('.$ceo_cc.')'; ?>
                                    </p>
                                </td>
                                <td class="text-center">
                                    <a href="v02_aims_others_claim_ceo_approval.php?nostaff=<? echo $month_claim['no_staff']?>&month_claim=<? echo $month_claim['month_claim']?>&verification=<? echo $verification?>"
                                       class="btn btn-sm btn-secondary" title="CEO/Chairman Action"><i class="fa fa-regular fa-gear"></i></a>
                                </td>
                            </tr>
                            </tbody>
                            <? } ?>
                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<? include ('../global/footer.php'); ?>
<script>
    // Delete row on delete button click

    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
</script>
</body>
</html>




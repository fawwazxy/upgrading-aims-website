<?php

include ('../controller/auth.php');

require "../model/analisa_kehadiran_functions.php";
require "../model/lookup.php";

$name = $_SESSION['SESS_NAME'];
$nokp = $_SESSION['SESS_NOKP'];
$no_staff = $_SESSION['SESS_NO_STAFF'];
$staff_details = getStaffDetailsByNokp($nokp)->fetch_assoc();
$sys = getSys(1)->fetch_assoc();
?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">

            <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Analisa Kehadiran Peribadi</h1>
            <div class="row">
            <div class="col-lg-12">
                <label>Nama &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>&nbsp;<?echo $name;?><br>
                <label>No. Kad Pengenalan &nbsp;&nbsp;:</label>&nbsp;<?echo $nokp;?><br>
                <label>No. Staf &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>&nbsp;<?echo $no_staff;?><br>
                <label>Jawatan &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>&nbsp;<?echo $staff_details['role'];?><br>
                <label>Bahagian &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>&nbsp;<?echo '<b>'.$staff_details['code_department'].'</b>'.'&nbsp;-&nbsp'.$staff_details['description'];?><br>
                <label>Lokasi &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>&nbsp;<?echo '<b>'.$staff_details['cawangan_kod'].'</b>'.'&nbsp;-&nbsp'.$staff_details['nama'];?>
            </div>
            </div>
             

             <div class="row">
                <div class="col-lg-12">
                    <br><div class="panel panel-red">
                        
                        <div class="panel-heading" align="center">
                        <label class="control-label" for="date">Analisa Kehadiran Peribadi</label>
                        </div>
                        <!-- /.panel-heading -->
                            <table width="100%" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Jumlah Hari Bekerja</center></th>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Jumlah Kehadiran</center></th>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Awal</center></th>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Tepat</center></th>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Lewat</center></th>
                                        <th bgcolor="#D6DBDF" width="17%"><center>Peratusan Kehadiran</center></th>
                                    </tr>
                                </thead>
                                <?
                                	$jumlah_hari_bekerja = getAnalisaJumlahHariBekerja($nokp,$staff_details['no_staff']);
									$jumlah_kehadiran = getAnalisaJumlahKehadiran($nokp);
									$kehadiran_awal = getAnalisaKehadiranAwal($nokp);
									$kehadiran_tepat = getAnalisaKehadiranTepat($nokp);
									$kehadiran_lewat = getAnalisaKehadiranLewat($nokp);

									if($jumlah_hari_bekerja != 0 ) {
										$peratusan_kehadiran = $jumlah_kehadiran/$jumlah_hari_bekerja * 100;
									}
									else {
										$peratusan_kehadiran = 0.00;
									}
                                ?>
                                <tbody>
                                    <tr>
                                        <td align="center" rowspan="3" bgcolor="#FDFEFE">
                                        	<h2><strong><font color="black"><?echo $jumlah_hari_bekerja;?></font></strong></h2>
                                        </td>

                                        <td align="center" rowspan="3" bgcolor="#FDFEFE" onclick="getAnalisaKehadiranAllDetails()">
                                        	<h2><strong><font color="blue"><?echo $jumlah_kehadiran;?></font></strong></h2>
                                        </td>
                                       
                                        <td align="center" rowspan="3"  bgcolor="#FDFEFE" onclick="getAnalisaKehadiranDetails('AWAL')">
                                        	<h2><strong><font color="green"><?echo $kehadiran_awal;?></font></strong></h2>
                                        </td>

                                        <td align="center" rowspan="3"  bgcolor="#FDFEFE" onclick="getAnalisaKehadiranDetails('TEPAT')">
                                        	<h2><strong><font color="purple"><?echo $kehadiran_tepat;?></font></strong></h2>
                                        </td>
                                       
                                        <td align="center" rowspan="3"  bgcolor="#FDFEFE" onclick="getAnalisaKehadiranDetails('LEWAT')">
                                            <h2><strong><font color="red"><?echo $kehadiran_lewat;?></font></strong></h2>
                                        </td>

                                        <td align="center" rowspan="3" bgcolor="#FDFEFE">
                                    		<h2><strong><font color="brown"><?echo round($peratusan_kehadiran,2);?>%</font></strong></h2>
                                        </td>
                                    </tr> 

                                </tbody>
                            </table>
                    </div>
                    <?if(isset($nokp))
                        {
                    ?>
                    <div id="kehadiran_details_all">
                    <div class="panel panel-default">
                    <div class="panel-heading">
                       <label class="control-label" for="date">Maklumat Kehadiran Peribadi <?if($status_kehadiran=='AWAL'){echo '<strong><font color="green">'.'AWAL'.'</font></strong>';}else if($status_kehadiran=='TEPAT'){echo '<strong><font color="purple">'.'TEPAT'.'</font></strong>';}else if($status_kehadiran == 'LEWAT'){echo '<strong><font color="red">'.'LEWAT'.'</font></strong>';} else{echo '<strong><font color="blue">'.'KESELURUHAN'.'</font></strong>';}?></label>
                    </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th width="7%">Bil</th>
                                        <th width="10%">Hari</th>
                                        <th width="15%">Tarikh & Masa</th>
                                        <th width="15%">Platform</th>
                                        <th width="15%">Lokasi</th>
                                        <th width="15%">Status</th>
                                        <th width="15%">Sebab Kelewatan</th>
										<th width="10%">Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?
                                        if($status_kehadiran == '') {
                                            $details = getAnalisaKehadiranAllDetails($nokp);
                                        }
                                        else {
                                            $details = getAnalisaKehadiranDetails($nokp,$status_kehadiran);
                                        }
                                        $i=1;
                                        while($kehadiran_details = $details->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td><?echo $i++;?></td>
                                        <td><?echo $kehadiran_details['hari_masuk'];?></td>
                                        <td>
                                            <label class="control-label">Masuk :</label>&nbsp;
                                            <?echo $kehadiran_details['masa_masuk'];?>
                                            <br><label class="control-label">Keluar :</label>&nbsp;
                                            <?echo $kehadiran_details['masa_keluar'];?>
                                        </td>
                                        <td>
                                            <label class="control-label">Masuk :</label>&nbsp;
                                            <?echo $kehadiran_details['device_masuk'];?>
                                            <br><label class="control-label">Keluar :</label>&nbsp;
                                            <?echo $kehadiran_details['device_keluar'];?>
                                                
                                        </td>
                                        <!-- <td>
                                            <label class="control-label">Masuk :</label>&nbsp;
                                            <br><?echo getLokasiKehadiran($kehadiran_details['lokasi_masuk']);?>
                                            <br><label class="control-label">Keluar :</label>&nbsp;
                                            <br><?echo getLokasiKehadiran($kehadiran_details['lokasi_keluar']);?>
                                                
                                        </td> -->
                                        <td>
                                            <label class="control-label">Masuk :</label>&nbsp;
                                            <?echo $kehadiran_details['remark_masuk'];?>
                                            <br><label class="control-label">Keluar :</label>&nbsp;
                                            <?echo $kehadiran_details['remark_keluar'];?>
                                                
                                        </td>
                                        <td>
                                            <?echo '<b>'.'<font color="blue">'.$kehadiran_details['bil_jam_bekerja'].'</font></b>';?>
                                            <br>
                                            <?
                                                if($kehadiran_details['status_kehadiran'] == 'AWAL') {
                                                    echo '<b>'.'<font color = "green">'.$kehadiran_details['status_kehadiran'].'</font>'.'</b>';
                                                }
                                                else if($kehadiran_details['status_kehadiran'] == 'TEPAT') {
                                                    echo '<b>'.'<font color = "purple">'.$kehadiran_details['status_kehadiran'].'</font>'.'</b>'; 
                                                }
                                                else {
                                                    echo '<b>'.'<font color = "red">'.$kehadiran_details['status_kehadiran'].'</font>'.'</b>';
                                                }
                                            ?>
                                                
                                        </td>
                                        <td><?echo $kehadiran_details['sebab_kelewatan'];?></td>
										<?php  
										if($kehadiran_details['status_kehadiran'] == 'LEWAT') {
                                                    echo "<td><a href='#myModal1' class='btn btn-info btn-small' data-toggle='modal' data-id=".$kehadiran_details['idd'].">Sebab Kelewatan</a></td>";
                                                }
										else {}
										 ?>
                                    </tr>
                                    <?}?>
                                 
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div> <?}?>
                    <div id="kehadiran_details"></div>

                    </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>

        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>
	
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Sebab Kelewatan</h4>
        </div>
        <div class="modal-body" id="demo">
        <script type="text/javascript">
          $('#myModal1').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'GET',
              url:'analisa_kehadiran_lewat_update.php',
              data:'id='+rowid,
              success:function(html){
                $('#demo').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>


    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                 responsive: true
            });
        });

        function getAnalisaKehadiranDetails(status_kehadiran){
        	//alert(status_kehadiran);
	    	$.ajax({
	                type: "POST",
                    url: "analisa_kehadiran_details.php",
	                data: {nokp:"<?echo $nokp;?>",status_kehadiran:status_kehadiran},
	                success: function (data) {
                    $('#kehadiran_details').html(data);
                    $('#kehadiran_details_all').hide();
	                // you will get response from your php page (what you echo or print)   
	              
	            }

		    });
        }

        function getAnalisaKehadiranAllDetails(){
            //alert(status_kehadiran);
            $.ajax({
                    type: "POST",
                    url: "analisa_kehadiran_details.php",
                    data: {nokp:"<?echo $nokp;?>"},
                    success: function (data) {
                    $('#kehadiran_details').html(data);
                    $('#kehadiran_details_all').hide();
                    // you will get response from your php page (what you echo or print)   
                  
                }

            });
        }

    </script>

</body>

</html>
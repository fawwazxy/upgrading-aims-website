<?php

include ('../controller/auth.php');

require "../model/aims_lv_medicalapp_function.php";
require "../model/lookup.php";

?>

<?
    date_default_timezone_set("Asia/Kuala_Lumpur");
	$no_staff = $_SESSION['SESS_NO_STAFF'];
	$staff_record_id = $_GET['staff_record_id'];
    $sys = getSys(1)->fetch_assoc();
 ?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>
	
<script language="JavaScript" type="text/javascript">
function Kemaskini(){
    return confirm('Anda pasti untuk kemaskini maklumat permohonan cuti?');
}

</script>
<script language="JavaScript" type="text/javascript">
function Confirm(){
    return confirm('Anda pasti untuk hantar permohonan cuti?');
}

</script>
</head>



<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <!--<?include '../global/menu_keselamatan.php'?>-->
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Medical List</h1>
                </div>
                
            </div>
			
			 <div class="panel-heading">

				<? 
                    $staff = getStaffInformation($no_staff) -> fetch_assoc();
				?>
				<table width="100%">
                                <tr>
                                    <th width="14%"></th>
                                    <th width="2%"></th>
                                    <th></th>
                                </tr>
                                <input name="no_staff" type="hidden" class="input-short" value="<? echo $no_staff;?>" />      
                                <input name="id" type="hidden" class="input-short" value="<? echo $id;?>" /> 
                                <tr>
                                    <td><label>NAME</label></td>
                                    <td><label>:</label></td>
                                    <td><?php echo $staff['staff_name']?></td>
                                </tr>

                                <tr>
                                    <td><label>IC NUMBER</label></td>
                                    <td><label>:</label></td>
                                    <td><?php echo $staff['noic']?></td>
                                </tr>

                                <tr>
                                    <td><label>POSITION</label></td>
                                    <td><label>:</label></td>
                                    <td><?php echo $staff['role_id']?></td>
                                </tr>

                                <tr>
                                    <td><label>DEPARTMENT</label></td>
                                    <td><label>:</label></td>
                                    <td><?php echo $staff['department_sub'] ?></td>
                                </tr>
                                
                                <tr>
                                    <td><label>COMPANY</label></td>
                                    <td><label>:</label></td>
                                    <td><?php echo $staff['company_name']?></td>
                                </tr>
</table>
   </div>         
			                  
            <div class="row">
                <div class="col-lg-12">
<br><br><br><br>
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>Medical List</label>&nbsp;&nbsp;&nbsp;
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						 <input name="id" type="hidden" class="input-short" value="<? echo $id;?>" />
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
										<th style="text-align:center;" width="5%">No.</th>
                                       <th style="text-align:center;" width="10%">Staff Info</th>
										<th style="text-align:center;" width="5%">Medical Date</th>
										<th style="text-align:center;" width="20%">Description</th>
										<th style="text-align:center;" width="10%">Total Claim(RM)</th>
										<th style="text-align:center;" width="20%">Attachment</th>
										
										<th style="text-align:center;" width="10%"> Approved Date</th>
										
										<th style="text-align:center;" width="20%">Status</th>
										<th style="text-align:center;" width="40%">Action</th>
										
                                    </tr>
                                </thead>
                                <tbody>
                                <?
                                    $staff = listceo();
                                    $i=1;
                                    while($staffinfo = $staff->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td><?echo $i++;?></td>
										
                                       <td><?echo $staffinfo['name'];?>  <br>
										<?echo $staffinfo['noic'];?>  <br>
										<?echo $staffinfo['role_id'];?>  <br>
										<?echo $staffinfo['department_id'];?>  <br>
										<?echo $staffinfo['company_name'];?></td>
										
										<td><?echo $staffinfo['mec_date'];?> </td>
										<td><?echo $staffinfo['description'];?> </td>
										<td><?echo $staffinfo['total'];?> </td>
										
										<td>
										
                                         <?if($staffinfo['document_type'] == 'jpg' || $staffinfo['document_type'] == 'jpeg' || $staffinfo['document_type'] == 'png' || $staffinfo['document_type'] == 'gif') {
                                                echo '<img width="200" height="100" src="data:image/jpeg;base64,'.base64_encode( $staffinfo['document'] ).'"/><br>';}
                                         else if($staffinfo['document_type'] == 'pdf') {
                                                echo '<object width="200" height="100" data="data:application/pdf;base64,'.base64_encode( $staffinfo['document'] ).'"/><br>'.'" type="application/pdf"></object>';}
                                            ?>

                                        </td>
										
										<td><?echo $staffinfo['app_date'];?> </td>
										
										
										
										<td>
										<?'<b>'.$staffinfo['app_status'].'</b>';
										if($staffinfo['app_status']==0){
										    echo"<span style='background-color:Grey;padding:5px;border-radius:5px;font-weight:bold;color:white;'>PENDING</span>";}
										else if($staffinfo['app_status']==1){
											echo"<span style='background-color:GREEN;padding:5px;border-radius: 5px; font-weight:bold;color:white;'>APPROVED</span>";}
										else{
										    echo"<span style='background-color:RED;padding:5px;border-radius: 5px; font-weight:bold;color:white;'>DISAPPROVED</span>"
										;}'</b>'?>
										<br><br>
										<?echo $staffinfo['app_name'];?>
										
                                        </td>
										<td>
										<a href="#myModal2" class="btn btn-info" data-toggle="modal" data-id="<? echo $staffinfo['id'];?>">Show Attachment</a><br><br>
										<a href="#myModal1" class="btn btn-primary" data-toggle="modal" data-id="<? echo $staffinfo['id'];?>">APPROVED</a>
										</td>
                                    </tr>
                                <?}?> 
                                 
                                </tbody>
                            </table>
                        </div>

                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>

        <!-- /#page-wrapper -->
		

    </div>
	
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Update</h4>
        </div>
        <div class="modal-body" id="demo">
        <script type="text/javascript">
          $('#myModal1').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'POST',
              url:'aims_lv_medicalapp_update.php',
              data:{id:rowid},
              success:function(html){
                $('#demo').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
   <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <!-- <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div> -->
        <div class="modal-body" id="demo1">
        <script type="text/javascript">
          $('#myModal2').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'POST',
              url:'aims_lv_medicalpic.php',
              data:{id:rowid},
              success:function(html){
                $('#demo1').html(html);
              }
            });
          });
        </script>
        </div>   
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
    <!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
        // Delete row on delete button click
        
		$(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    
    </script>

</body>

</html>




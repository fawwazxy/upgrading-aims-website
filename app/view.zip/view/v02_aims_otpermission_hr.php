<?php
include ('../controller/auth.php');
require "../model/v02_aims_ot_function.php";
require "../model/lookup.php";

$no_staff = $_SESSION['SESS_NO_STAFF'];
$company_id = $_SESSION['SESS_DEPARTMENT'];
$department_id = ($_GET['department_id']) ?: 'AGHSB';
if ($_SESSION['SESS_DEPARTMENT_SUB'] != 'HR' ) {
    echo "<script>
            alert('This section can only be accessed by person in charge for OVERTIME PERMISSION approval')
            window.history.back();
            </script>";
    exit();
}

$month= (!empty($_GET['month']))  ?$_GET['month'] : date('m');
$year=(!empty($_GET['year'])) ? $_GET['year'] : date('Y');

$company_list = [
  "AGHSB" => "AGHSB",
  "AGESB" => "AGESB",
  "AGIRSB" => "AGIRSB",
  "AGMHESB" => "AGMHESB",
  "AGMSB" => "AGMSB",
  "AVSB" => "AVSB",
  "TKSB" => "TKSB",
  "MASB" => "MSET-AIMS",
];

//$staff = getOtStaffInfo($no_staff) -> fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <? require "../global/header.php"; ?>
    <style>
        .ot-status{
            padding: 4px 8px;
            border-radius: 5px;
            font-weight: bold;
            color: #000000;
            background-color: #e7e7e7;
            border: 1px dotted black;
            white-space: nowrap;
        }
    </style>
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0;" >
        <? include ('../global/menu_top.php'); ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
        </div>
    </nav>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OVERTIME PERMISSION <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> HR
                    <a href="aims_otpermission_hr.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>Switch to Version 01
                    </a>
                    <!--<a href="v02_aims_otpermission_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">-->
                    <!--    <i class="fa fa-arrow-left" style="margin-right: 8px"></i>-->
                    <!--    Back to list-->
                    <!--</a>-->
                </h1>
            </div>
        </div>

        <div id='cssmenu'>
            <ul>
                <? foreach ($company_list as $code => $name){?>
                    <li class="<? echo ($code == $department_id) ? 'active' :''; ?>">
                        <a href="v02_aims_otpermission_hr.php?department_id=<? echo $code ?>&year=<?echo $year;?>&month=<?echo $month;?>"><? echo $name ?></a>
                    </li>
                <? } ?>
            </ul>
        </div> <br><br>
        <div class="col-lg-4">
            <select required class="form-control" name="year" id="year">
                <option value="0">All</option>
                <? echo v02getDropDownPermissionYear($year);?>
            </select>
        </div>
        <div class="col-lg-4">
            <select required class="form-control" name="month" id="month">
                <? echo v02getDropDownMonth($month);?>
            </select>
        </div>


        <br><br>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <label class="control-label" for="date">Overtime Permission List</label>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table style="width: 100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th style="width: 6%" class="text-center">No.</th>
                                <th style="width: 20%">Name</th>
                                <th style="width: 10%" class="text-center">Date</th>
                                <th style="width: 20%">Description</th>
                                <th style="width: 20%">Approval</th>
                                <th style="width: 10%">Remark</th>
                                <th style="width: 8%">Claim?</th>
                                <th style="width: 6%" class="text-center">
                                    <i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>
                                </th>
                            </tr>
                            </thead>
                            <tbody>

                            <?
                            $ot_permission = v02getOtPermissionHr($department_id,$year,$month);
                            $i=1;
                            while($otp = $ot_permission->fetch_assoc()) {
                                $timestamp_color = ($otp['approval_status'] == 1) ? 'GREEN':'RED';
                                $claim_status = ($otp['claim_status'] == 1) ?
                                    '<i class="fa fa-check-circle text-success"></i>' : '<i class="fa fa-times-circle text-danger"></i>';
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $i++.'.'; ?></td>
                                    <td>
                                        <?php
                                        echo '<p>'.getStaffName($otp['no_staff_applicant']).'<br><b>'.$otp['no_staff_applicant'].'</b></p>';
                                        echo '<span class="ot-status">' . $otp['created_at'] . '</span>';
                                        ?>
                                    </td>
                                    <td class="text-center"><?php echo date("Y-m-d", strtotime($otp['created_at'])); ?></td>
                                    <td><?php echo $otp['description']; ?></td>
                                    <td class="text-center"><?php
                                        if (!empty($otp['approval_at'])) {
                                            $staff_app_name = getStaffName($otp['no_staff_approval']);
                                            if ($otp['no_staff_approval'] == 'auto'){
                                                $staff_app_name = 'AUTO-APPROVAL';
                                            }
                                            echo '<p>'.$staff_app_name.'</p>';
                                            echo '<span class="ot-status" style="color: #FFFFFF; background-color: '.$timestamp_color.'">' . $otp['approval_at'] . '</span>';
                                        }else{
                                            echo '<p class="text-muted" style="font-style: italic; font-weight: bold">PENDING</p>';
                                        }
                                        ?>
                                    </td>
                                    <td class="text-center"><?php echo ($otp['remark']) ?:
                                            '<i class="text-muted" style="font-size: x-small">- No remark -</i>'; ?>
                                    </td>
                                    <td class="text-center"><? echo $claim_status ?></td>
                                    <td class="text-center">
                                        <a href="../controller/v02_aims_otpdelete_exec.php?id=<? echo $otp['id']; ?>" onclick="return confirm('Are you sure you want to delete?');">
                                            <i class="material-icons" style="color: red;" data-toggle="tooltip" title="Delete">&#xE872;</i>
                                        </a>
                                    </td>
                                </tr>
                            <? } ?>


                            </tbody>

                        </table>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>

        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>



    <!-- Edit Modal HTML -->
    <div class="modal fade" id="updateOTP" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">EDIT OVERTIME PERMISSION</h4>
                </div>
                <div class="modal-body" id="demo1">
                    <script type="text/javascript">
                        $('#updateOTP').on('show.bs.modal', function (e) {
                            var rowid = $(e.relatedTarget).data('id');
                            // $('#demo').html(rowid);
                            $.ajax({
                                type:'POST',
                                url:'aims_otpermission_update.php',
                                data:{id:rowid},
                                success:function(html){
                                    $('#demo1').html(html);
                                }
                            });
                        });
                    </script>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>



    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true,
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }]
            });
            $("#year,#month").change(function(){
                var selected_year=$("#year").val();
                var selected_month=$("#month").val();
                sendType(selected_year,selected_month);
            });

        });
        function sendType(year,month){
            if(month===undefined){
                window.location.href="v02_aims_otpermission_hr.php?department_id=<?echo $department_id;?>&year="+year;
            }else{
                window.location.href="v02_aims_otpermission_hr.php?department_id=<?echo $department_id;?>&year="+year+"&month="+month;
            }


        }
    </script>

</body>

</html>
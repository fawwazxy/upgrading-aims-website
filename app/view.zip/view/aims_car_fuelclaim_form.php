<?php
include ('../controller/auth.php');
require "../model/aims_carReserve_function.php";
require "../model/lookup.php";

$id = $_GET['id'];
$status = 'FUEL';
$fuel = getFuelcarById($id,$status)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

<script language="javascript" type="text/javascript">
<!--
function popitup(url) {
	/*newwindow=window.open(url,'name','height=842,width=595');*/
	newwindow=window.open(url,'name','height=595,width=890');
	if (window.focus) {newwindow.focus()}
	return false;
}

// -->
</script>

<style>
/* Layout: */

.col-main {
  flex: 1;  
}  

.col-complementary {
  flex: 1;  
}

/* Responsive: */

@media only screen and (min-width: 640px) {
  .layout {
    display: flex;
  }
}

/* etc */



.container {
  max-width: 60em;
  margin-right: auto;
  margin-left: auto;
}

.col {
  padding: 1em;
  margin: 0 2px 2px 0;
  background: #b3e888;
}

h3 {
  display: flex;
  flex-direction: row;
}
h3:before, h3:after{
  content: "";
  flex: 1 1;
  border-bottom: 3px solid;
  margin: auto;
}
h3:before {
  margin-right: 5px
}
h3:after {
  margin-left: 5px
}
</style>


</head>



<body style="background-color:white;">

<div style="text-align:center; padding-top:10px;" width="100%"><input type="button" class="btn btn-danger" value="Close" onclick="self.close()"></div>

		<div class="container">
		
		<? $docname = $fuel['document_name'];
		   $filename = $fuel['file_name'];
		   $docpath = '../../fuel_photo/'.$fuel['document_name'];
		   $filepath = '../../fuel_photo/'.$fuel['file_name'];
		
		?>
        <form method="post" action="../controller/aims_car_fuel_exec.php" enctype="multipart/form-data">     

		<label><font color="red">** Required Information.</font></label>
		<br>
		
		  <input type="hidden" name="reserve_id" value="<?php echo $id; ?>">
		  <input type="hidden" name="id" value="<?php echo $fuel['id']; ?>">
		  <input type="hidden" name="status" value="FUEL">
	
		    <h3>MILEAGE & FUEL RECEIPT</h3>
			<br><br>
		<div class="layout">
			
			<div class="col col-main">
			  <label>MILEAGE (KM)<font color="red">**</font>&nbsp;</label>
			  <input class="form-control" placeholder=" " name="mileage_fuel" value="<? echo $fuel['mileage_fuel'];?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
			    <? if(in_array($fuel['document_type'], ['jpg','jpeg', 'png', 'gif'])) {?>
                        <center><img class="img-responsive" width="200" height="100" src="<?echo $docpath;?>" border="0"/></center>   
			    <?} else if($fuel['document_type'] == 'pdf') {?>
                        <center><iframe width="200" height="100" src="<?php echo $docpath; ?>" class="embed-responsive-item"></iframe></center>
				<?}?>
    			<br><input type="hidden" name="MAX_FILE_SIZE" value="2000000">
    			<br><input type="file" onchange="preview(event)" accept=".jpg,.jpeg,.png,.gif,.pdf" name="document" id="document">
    			<img id="output" src="#" alt="pic" style="width: 192px;height: auto;display: none"/>
			</div>
			
			<div class="col col-complementary">
			  <label>RECEIPT (RM)<font color="red">**</font>&nbsp;</label>
			  <input class="form-control" placeholder=" " name="receipt_fuel" value="<? echo $fuel['receipt_fuel'];?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
			  <label style="margin-top: 4px">Receipt Date</label>
			  <input type="date" class="form-control" id="receipt_date" name="receipt_date" placeholder="Receipt Date" value="<? echo ($fuel['receipt_date'])?: '';?>">
			    <? if(in_array($fuel['file_type'], ['jpg','jpeg', 'png', 'gif'])) {?>
                        <center><img class="img-responsive" width="200" height="100" src="<?echo $filepath;?>" border="0"/></center>   
			    <? }  else if($fuel['file_type'] == 'pdf') {?>
                        <center><iframe width="200" height="100" src="<?php echo $filepath; ?>" class="embed-responsive-item"></iframe></center>
			    <?}?>
				<br><input type="hidden" name="MAX_FILE_SIZE" value="2000000">
				<br><input type="file" onchange="previews(event)" accept=".jpg,.jpeg,.png,.gif,.pdf" name="file" id="file">
				<img id="output_1" src="#" alt="pic" style="width: 192px;height: auto;display: none"/>
			</div>
		</div>	
			
            
			<br><br>
			<div class="form-group row" align="center">
			<div class="col-xs-12">
			   <button type="submit" class="btn btn-primary">Save</button>
			   <a href="../controller/aims_carfuel_delete_exec.php?id=<? echo $fuel['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete?');">Delete</a>
			</div>
			</div>
		</form>
	</div>
<script>
function preview(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
	image.style.display = "block";
}

function previews(event) {
	var images = document.getElementById('output_1');
	images.src = URL.createObjectURL(event.target.files[0]);
	images.style.display = "block";
}
</script>
</body>

</html>

<?php

include ('../controller/auth.php');

require "../model/aims_gl_function.php";
require "../model/lookup.php";

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

    <? require "../global/header.php"; ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Client List</h1>
                </div>
            </div>

            <div class="form-group" align="right">
            </div>
            
             
             <div class="row">
                <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel panel-body">
					<form method="post" action="../controller/aims_gl_client_exec.php">
					<input id="id" name="id" type="hidden" value="<?php echo $_SESSION['SESS_NAME'] ?>"/>

				<div class="form-group row" align="left">
                                <div class="col-xs-12">
                                  <label>Name<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder=" " name="client_name" id="client_name" required onkeyup="convertToUppercase(this)">
                              </div>
                            </div>
                                
                            <div class="form-group row" align="left">
                                <div class="col-xs-4">
                                  <label>IC/Passport Number<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder=" "  name="client_ic" id="client_ic" required>
                              </div>

                                <div class="col-xs-4">
                                  <label>Phone Number<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder=" "  name="client_phone_no" id="client_phone_no" required>
                            </div>

                            <div class="col-xs-4">
                                  <label>Car Registration</label>
                                  <input class="form-control" placeholder=" " name="client_car" id="client_car" onkeyup="convertToUppercase(this)">
                              </div>
                        </div>

                        <div class="form-group row" align="left">
                                <div class="col-xs-4">
                                  <label>Company<font color="red">**</font>&nbsp;</label>
                                  <select  required class="form-control" name="client_company_id" id="client_company_id">
                                    <option value="">-- Choose Company Client --</option>
                                    <? echo getDropDownCompanyClient("");?>
                                    </select>
                            </div>

                                <div class="col-xs-8">
                                  <label>Address<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder=" "  name="client_address" id="client_address" required onkeyup="convertToUppercase(this)">
                              </div>
                            </div>

                            <div class="form-group row" align="left">
                                <div class="col-xs-4">
                                  <label>State</label>
                                  <select class="form-control" name="client_state" id="client_state">
                                    <option value="">-- Choose State --</option>
                                    <? echo getDropDownState("");?>
                                    </select>
                            </div>

                            <div class="col-xs-4">
                                  <label>City</label>
                                  <input class="form-control" placeholder=" "  name="client_city" id="client_city" onkeyup="convertToUppercase(this)">
                              </div>

                                <div class="col-xs-4">
                                    <label>Postcode</label>
                                  <input class="form-control" placeholder=" "  name="client_postcode" id="client_postcode">
                              </div>
                          </div>

                              
				
				<div align="center">
					<button type="submit" class="btn btn-success">Save</button>
					<button type="reset" class="btn btn-warning">Reset</button>
				</div>
			</form>
			</div>
								
							</div>
							<!-- /.col-lg-12 -->
						</div>
						<!-- /.row -->
						<!-- /.container-fluid -->
					</div>

					<!-- /#page-wrapper -->

				</div>
				<!-- /#wrapper -->
				<? include ('../global/footer.php'); ?>

				<!-- Page-Level Demo Scripts - Tables - Use for reference -->
				<script>

					$(document).ready(function() {
						$('#dataTables-example').DataTable({
							responsive: true
						});
					});      
					
					function convertToUppercase(el) {
                    if(!el || !el.value) return;
                    el.value = el.value.toUpperCase();
                }
				
				</script>

</body>

</html>
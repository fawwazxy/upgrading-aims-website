<?php


$approvement = $_GET['approvement'];
if (!isset($approvement) && $approvement == '') {
    $approvement = 'IN PROGRESS';
    }
$support = $_GET['support'];
if (!isset($support) && $support == '') {
    $support = 'IN PROGRESS';
    }
    
$approve = $_GET['approve'];
if (!isset($approve) && $approve == '') {
    $approve = 'PENDING';
    }
$verified = $_GET['verified'];
if (!isset($verified) && $verified == '') {
    $verified = 'PENDING';
    }
    
$approved = $_GET['proc_status'];
if (!isset($approved) && $approved == '') {
    $approved = '0';
    }

$approved1 = $_GET['app_pro_status'];
if (!isset($approved1) && $approved1 == '') {
    $approved1 = '0';
    }

$approved2 = $_GET['app_status'];
if (!isset($approved2) && $approved2 == '') {
    $approved2 = '0';
    }

$approve2 = $_GET['approved_status'];
if (!isset($approve2) && $approve2 == '') {
    $approve2 = '0';
    }    

$thn=$_GET['tahun'];
if(!isset($thn)){
    $thn = date(Y);
}
$role_id = $_SESSION['SESS_ROLE'];
$department_sub = $_SESSION['SESS_DEPARTMENT_SUB'];
$name = $_SESSION['SESS_NAME'];
$leave_approval = $_GET['leave_approval'];
$no_staff=$_SESSION['SESS_NO_STAFF'];
$nokp=$_SESSION['SESS_NOKP']
?>

<style>
    .column{
        width: auto;
        border: 5px solid powderblue;
        padding: 15px;
        margin: 15px;
        text-align: center;
        justify-content: center;
        height: =uto;
    }.option {
        background: #eee;
        display: block;
        padding: 5px 10px 5px;
        color: #000;
        -moz-border-radius: 6px;
        -webkit-border-radius: 6px;
        -khtml-border-radius: 6px;
        border-radius: 6px;
        cursor: pointer;
    }.tableCenter{
        position: inherit;
    }
    </style>
    
<!--                      NOTOFICATION CUTI                         -->
    <a href='senarai_kelulusan_cuti_hod.php'>
    <?
                                    if($approvement == 'IN PROGRESS' && $role_id == 'HOD' && $department_sub == 'OPERATION-AGMSB') {
                                        $pemohon= gettotalbaharucutihod2($_SESSION['SESS_NAME']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
                					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for LEAVE.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
									<? //HOD COMMERCIAL
									if($approvement == 'IN PROGRESS' && $role_id == 'HOD' && $department_sub == 'COMMERCIAL') {
                                        $pemohon= gettotalbaharucutihod4($_SESSION['SESS_NAME']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
                					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for LEAVE.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
									 <?
                                    if($approvement == 'IN PROGRESS' && $role_id == 'HOD' && in_array($department_sub, ['HR', 'CORPADMIN'])) {
                                        $pemohon= gettotalbaharucutihod1($_SESSION['SESS_NAME'],$_SESSION['SESS_DEPARTMENT_SUB']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
                					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for LEAVE.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
									<?
                                    if($approvement == 'IN PROGRESS' && $department_sub == 'TECHOPERATION' && $role_id == 'HOD') {
                                        $pemohon= gettotalbaharucutihod3($_SESSION['SESS_NAME']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
                					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for LEAVE.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
                    
            				         <?
                                    if($approvement == 'IN PROGRESS' && $role_id == 'HOD' && !in_array($department_sub, ['FINACC', 'OPERATION-AGMHESB', 'HR', 'OPERATION-AGMSB', 'TECHOPERATION', 'COMMERCIAL'])) {
                                        $pemohon= gettotalbaharucuti($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NO_STAFF']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for LEAVE.
					<button type="button" class="close" data-close="notification">
					<span>&times; </span>
                    </button>
                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
                                    <?
                                    //if($approvement == 'IN PROGRESS' && $no_staff == $no_staff && !in_array($department_sub, ['TECHOPERATION','IT'])) {
                                        //$pemohon= gettotalbaharucuti2($_SESSION['SESS_NO_STAFF'],$_SESSION['SESS_NAME']);
                                        
                                        //while($row_pemohon = $pemohon->fetch_assoc()){?>
                                            <?
                                            //if ($row_pemohon['kira'] > 0) {
                                            ?>
                                            
                                            <!--<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">-->
                                                <!--<strong>ATTENTION</strong> You have <b><?php //echo $row_pemohon['kira']; ?></b> approvement for LEAVE.
                                                <button type="button" class="close" data-close="notification">-->
                                            <!--        <span>&times;</span>-->
                                            <!--    </button>-->
                                            <!--</div> -->
                                            <?//}?>
                                        <?//}?>
                                    <?//}?>
	</a>								
                    <!-- /end approve noti -->
                    
                    <!-- /support noti -->
                            <a href='senarai_kelulusan_cuti.php' style="color: #000039">                
									<? if ($support == 'IN PROGRESS' && !in_array($department_sub, ['FINACC','OPERATION-AGMHESB', 'OPERATION-AGMSB', 'MANAGEMENT', 'MOORING-GANG','PILOT-BOAT','OPERATION-AVSB','OPERATIONFAC-AVSB'])
									&& !in_array($no_staff, ['940331025617', '911011115100', 'INDEEP0329']) && !in_array($role_id, ['INTERN', 'MANAGER']) ){
										$pemohon= gettotalbaharucuti1($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
									
										while($r_pemohon = $pemohon->fetch_assoc()){
        									 if ($r_pemohon['totals'] > 0) {
        									?>
        									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
            									<button type="button" class="close" data-close="notification">
            									    <span>&times;</span>
            									</button>
        									</div>
        									<?}
    									}
									}?>
									
									<!-- SYAFIQ HISYAMUDDIN support utk semua staff dlm OPERATION-AVSB & OPERATIONFAC-AVSB-->
									<? if ($support == 'IN PROGRESS' && $no_staff == 'INDEEP0329'){
										$pemohon= gettotalbaharucuti11();
									
										while($r_pemohon = $pemohon->fetch_assoc()){
        									 if ($r_pemohon['totals'] > 0) {
        									?>
        									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
            									<button type="button" class="close" data-close="notification">
            									    <span>&times;</span>
            									</button>
        									</div>
        									<?}
    									}
									}?>
									
									<!--hod hsse-->
									<? if ($support == 'IN PROGRESS' && $role_id == 'HOD' && $department_sub == 'HSSE'){
										$pemohon= gettotalbaharucuti1($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
									
										while($r_pemohon = $pemohon->fetch_assoc()){
        									 if ($r_pemohon['totals'] > 0) {
        									?>
        									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
            									<button type="button" class="close" data-close="notification">
            									<span>&times;</span>
            									</button>
        									</div>
        									<?}
    									}
									}?>
									
									<!--exec n supervisor support each other-->
									<? if ($support == 'IN PROGRESS' && ($role_id == 'EXECUTIVEAVSB' || $role_id == 'SUPERVISORAVSB')){
										$pemohon= gettotalbaharucuti3($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
									
										while($r_pemohon = $pemohon->fetch_assoc()){
									?>			
									 <?
									 if ($r_pemohon['totals'] > 0) {
									?>
									
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>

									<? 
								// 	if ($support == 'IN PROGRESS' && $role_id == 'EXECUTIVETKSB' || $role_id == 'SUPERVISORAVSB'){
								// 		$pemohon= gettotalbaharucuti4($_SESSION['SESS_NAME']);
									
								// 		while($r_pemohon = $pemohon->fetch_assoc()){
									
								// 	 if ($r_pemohon['totals'] > 0) {
									?>
									
									<!--<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">-->
									<!--<strong>ATTENTION</strong> You have <b>
									<?
								// 	php echo $r_pemohon['totals']; 
									?>
									</b> support for LEAVE.-->
									<!--<button type="button" class="close" data-close="notification">-->
									<!--<span>&times;</span>-->
									<!--</button>-->
									<!--</div>-->
									<?
								// 	}
								// 	}
								// 	}
									?>									
                                    
                                    <!--hod finacc n agmhe support staff-->
									<? if ($support == 'IN PROGRESS' && ($role_id == 'HOD' && $department_sub =='FINACC' || $department_sub == 'OPERATION-AGMHESB')){
											$pemohon= gettotalbaharucuti1($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--finacc n agmhe support hod-->
									<? if ($support == 'IN PROGRESS' && $role_id !=='INTERN' && $department_sub =='FINACC' || $department_sub == 'OPERATION-AGMHESB' ){
											$pemohon= gettotalbaharucutifiop($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--hr agma-->
									<? if ($support == 'IN PROGRESS' && $department_sub =='HR-AGMA'){
											$pemohon= gettotalbaharucuti5($_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--kak emy-->
									<? if ($support == 'IN PROGRESS' && $role_id =='HOD' && $department_sub =='HR' ){
											$pemohon= gettotalbaharucuti6($_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--capt-->
									<? if ($support == 'IN PROGRESS' && $_SESSION['SESS_NAME'] == 'MOHD TARMIZI BIN MEJAM'){
											$pemohon= gettotalbaharucuti7($_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--kak lana-->
									<? if ($support == 'IN PROGRESS' && $role_id == 'MANAGING-DIRECTOR' ){
											$pemohon= gettotalbaharucuti8();
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--syafiq-->
									<? if ($support == 'IN PROGRESS' && $role_id == 'EXECUTIVE-DIRECTOR'){
											$pemohon= gettotalbaharucuti9();
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									<!--ayie-->
									<? if ($support == 'IN PROGRESS' && $no_staff == '940331025617'){
											$pemohon= gettotalbaharucuti10();
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
									
									
									
									<!-- support kak ida -->
									<? if ($support == 'IN PROGRESS' && $no_staff == '911011115100'){
											$pemohon= gettotalbaharucutiHRAVSB($_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> support for LEAVE.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
	</a>
                                    <!-- approvement cuti special hr -->
    <a href="senarai_kelulusancuti_special_hr.php">
									<? if ($department_sub =='HR'){
											$pemohon= gettotalbaharucutiSpecial($_SESSION['SESS_NAME']);
													
											while($r_pemohon = $pemohon->fetch_assoc()){
									?>
									<?
									 if ($r_pemohon['totals'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #D7DBDD; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $r_pemohon['totals']; ?></b> approvement for LEAVE SPECIAL.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>
									<?}?>
	</a>

<!--                      NOTOFICATION INOUT                         -->									
					<!-- /inout noti approve -->
	<a href="aims_list_approveinout.php">				
					<?
                                    if($approve == 'PENDING' && $role_id == 'HOD' && $department_sub == 'OPERATION-AGMSB') {
                                        $pemohon= gettotalbaharucutihod2inout($_SESSION['SESS_NAME']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
                					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for INOUT.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
									 <?
                                    if($approve == 'PENDING' && $role_id == 'HOD' && ($department_sub == 'HR')) {
                                        $pemohon= gettotalbaharucutihod1inout($_SESSION['SESS_NAME'],$_SESSION['SESS_DEPARTMENT_SUB']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for INOUT.
					<button type="button" class="close" data-close="notification">
					<span>&times;</span>
                    </button>
                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
                    
            				         <?
                                    if($approve == 'PENDING' && $role_id == 'HOD' && $department_sub !== 'FINACC' && $department_sub !== 'OPERATION-AGMHESB' && $department_sub !== 'HR' && $department_sub !== 'OPERATION-AGMSB') {
                                        $pemohon= gettotalbaharucutiinout($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NO_STAFF']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>				
					
					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for INOUT.
					<button type="button" class="close" data-close="notification">
					<span>&times;</span>
                    </button>
                    </div>
					
						
									<?}?>	
									<?}?>
									<?}?>
									
                                    <?
                                    if($approve == 'PENDING' && $no_staff == $no_staff) {
                                        $pemohon= gettotalbaharucuti2inout($_SESSION['SESS_NO_STAFF'],$_SESSION['SESS_NAME']);
									
									while($row_pemohon = $pemohon->fetch_assoc()){?>
									
									<?
									if ($row_pemohon['total'] > 0) {
									?>
					
					<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
					<strong>ATTENTION</strong> You have <b><?php echo $row_pemohon['total']; ?></b> approvement for INOUT.
					<button type="button" class="close" data-close="notification">
					<span>&times;</span>
                    </button>
                    </div>
					
						
										
									<?}?>
									<?}?>
									<?}?>									
                    <!-- /end approve noti inout -->
    </a>                
   
    
                    <!-- /verified noti -->
                    <a href="aims_list_verified_approve.php" style="color: #000039">
                                   <?
                                    $notiI= getaims_verified_approvelisitbaharu($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($notiInout = $notiI->fetch_assoc()){
									?>
									<?
									 if ($notiInout['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $notiInout['total']; ?></b> verification for IN OUT.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>

    </a>
                    
                      
					<!-- end noti verified inout -->	
					
<!--                      NOTOFICATION TRAVEL                         -->
    <!-- Noti Verify TAF -->
    <a href="aims_travel_requestlist.php" style="color: #000039">
                                   <?
                                    $notiT= getNotiPemohonTravelBaharu($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($notiTravel = $notiT->fetch_assoc()){
									?>
									<?
									 if ($notiTravel['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $notiTravel['total']; ?></b> verification for TRAVEL FORM.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>

    </a>
    <!-- Noti Verify By CEO TAF -->
    <a href="aims_travel_verificationCeo.php" style="color: #000039">
                                   <?
                                    $notiTCeo= getNotiPemohonTravelBaharuCeo($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($notiTravel = $notiTCeo->fetch_assoc()){
									?>
									<?
									 if ($notiTravel['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $notiTravel['total']; ?></b> verification for TRAVEL FORM.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>

    </a>
    <!-- Noti Approvement By CEO/EC TAF -->
	<a href="aims_travel_listCeo.php">
                                   <?
                                    $notiTAppCeo= getTravelNotiBaharuCeo($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($notiTravel = $notiTAppCeo->fetch_assoc()){
									?>
									<?
									 if ($notiTravel['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $notiTravel['total']; ?></b> approvement for TRAVEL FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

    </a>
    
<!--                      NOTOFICATION OVERTIME                         -->
    <!-- Noti Approvement By HOD OTP -->
	<a href="aims_otpermission_approve.php">
                                   <?
                                    $notiotp= notiOtPermission($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NO_STAFF']);
									while($otp = $notiotp->fetch_assoc()){
									?>
									<?
									 if ($otp['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $otp['total']; ?></b> approvement for OVERTIME PERMISSION FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

    </a>
    
    <!-- Noti Verify OT -->
    <a href="aims_ot_hod_list.php" style="color: #000039">
                                   <?
                                    $notiOt= notiOtForHod($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NO_STAFF']);
													
											while($ot = $notiOt->fetch_assoc()){
									?>
									<?
									 if ($ot['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
									<strong>ATTENTION</strong> You have <b><?php echo $ot['total']; ?></b> verification for OVERTIME FORM.
									<button type="button" class="close" data-close="notification">
									<span>&times;</span>
									</button>
									</div>
									<?}?>
									<?}?>

    </a>
    
    <a href="aims_ot_ceo_list.php">
                                   <?
                                    $notiOtApp= notiOtForCeo($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NO_STAFF']);
													
											while($otApp = $notiOtApp->fetch_assoc()){
									?>
									<?
									 if ($otApp['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $otApp['total']; ?></b> approvement for OVERTIME FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

    </a>
  
    <!-- procurement approve ssr n ssa-->						
		<a href="aims_ssa_proc_app.php">							
			<? if($approved == '0'  && $department_sub =='PROCUREMENT' ) {
            $ssa= approveprossa();
									
			while($row_ssa = $ssa->fetch_assoc()){?>
									
			<?
			if ($row_ssa['jumlah'] > 0) {
			?>				
					
            <div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            <strong>ATTENTION</strong> You have <b><?php echo $row_ssa['jumlah']; ?></b> approvement for <b>SSA</b>.
            <button type="button" class="close" data-close="notification">
            <span>&times;</span>
            </button>
            </div>
					
						
			<?}?>	
			<?}?>
			<?}?>
			
    </a>
    
    <a href="aims_ssrapp_pro_list.php">
			
			<? if($approved1 == '0' && $department_sub =='PROCUREMENT' ) {
            $ssr= approveprossr();
									
			while($row_ssr = $ssr->fetch_assoc()){?>
									
			<?
			if ($row_ssr['jumlah'] > 0) {
			?>				
					
            <div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            <strong>ATTENTION</strong> You have <b><?php echo $row_ssr['jumlah']; ?></b> approvement for <b>SSR</b>.
            <button type="button" class="close" data-close="notification">
            <span>&times;</span>
            </button>
            </div>
					
						
			<?}?>	
			<?}?>
			<?}?>
    </a>
    
    <!--approve ssa n ssr-->
    
    <!--En Khairul approve-->
    <a href="aims_ssa_app.php">
			<?
			if($approved2 == '0' &&  $_SESSION['SESS_NO_STAFF'] == '740915115003') {
            $ssa= approvessa();
									
			while($row_ssa = $ssa->fetch_assoc()){?>
									
			<?
			if ($row_ssa['jumlah'] > 0) {
			?>				
					
            <div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            <strong>ATTENTION</strong> You have <b><?php echo $row_ssa['jumlah']; ?></b> approvement for <b>SSA</b>.
            <button type="button" class="close" data-close="notification">
            <span>&times;</span>
            </button>
            </div>
					
						
			<?}?>	
			<?}?>
			<?}?>
			
		</a>	
		<a href="aims_ssrapproved_list.php">
			<?
			if($approve2 == '0' &&  $_SESSION['SESS_NO_STAFF'] == '740915115003') {
            $ssr= approvessr();
									
			while($row_ssr = $ssr->fetch_assoc()){?>
									
			<?
			if ($row_ssr['jumlah'] > 0) {
			?>				
					
            <div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
            <strong>ATTENTION</strong> You have <b><?php echo $row_ssr['jumlah']; ?></b> approvement for <b>SSR</b>.
            <button type="button" class="close" data-close="notification">
            <span>&times;</span>
            </button>
            </div>
					
						
			<?}?>	
			<?}?>
			<?}?>
			</a>
			
	    <!--Claim Verify-->
     <a href="aims_others_claim_hod_list.php" style="color: #000039">
                                   <?
                                    $notiVerifyClaim= notiClaimforVerify($_SESSION['SESS_NO_STAFF'],$_SESSION['SESS_DEPARTMENT_SUB']);
													
											while($claimverify = $notiVerifyClaim->fetch_assoc()){
									?>
									<?
									 if ($claimverify['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #CB4335; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $claimverify['total']; ?></b> Verification for CLAIM FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

    </a>
    

    
    <!--Claim Review-->
     <a href="aims_others_claim_hr_list.php">
                                  
                                   <?
                                    if ($department_sub =='HR'){
                                    $notiRevClaim= notiClaimforReview();
													
											while($claimRev = $notiRevClaim->fetch_assoc()){
									?>
									<?
									 if ($claimRev['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #D7DBDD; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $claimRev['total']; ?></b> Reviewed for CLAIM FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>
									<?}?>
									

    </a>
    
        <!--Claim Approve-->
     <a href="aims_others_claim_ceo_list.php">
                                    <?
                                    if ($no_staff =='751206035485'){
                                    $notiRevClaim= notiClaimforApprove($_SESSION['SESS_NO_STAFF']);
													
											while($claimRev = $notiRevClaim->fetch_assoc()){
									?>
									<?
									 if ($claimRev['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $claimRev['total']; ?></b> Approvement for CLAIM FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>
									<?}
									
									else if ($no_staff =='660512115105'){
                                    $notiRevClaim= notiClaimforApprove($_SESSION['SESS_NO_STAFF']);
													
											while($claimRev = $notiRevClaim->fetch_assoc()){
									?>
									<?
									 if ($claimRev['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $claimRev['total']; ?></b> Approvement for CLAIM FORM.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>
									<?}?>

    </a>
    
            
            <!--Transport PIC Approvement-->
    	    <a href="aims_car_companyapp.php" style="color: #000039">
                                   <?
                                    $notiAppTransport= getcarRequestpic($_SESSION['SESS_NAME']);
													
											while($apptransport = $notiAppTransport->fetch_assoc()){
									?>
									<?
									 if ($apptransport['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $apptransport['total']; ?></b> Approvement for TRANSPORT REQUEST.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

            </a>
            
            <!--Transport ADMIN Approvement-->
    	    <a href="aims_car_adUse_list.php" style="color: #000039">
                                   <?
                                    $notiAppTransport= getcarRequestAdmin($_SESSION['SESS_NAME']);
													
											while($apptransport = $notiAppTransport->fetch_assoc()){
									?>
									<?
									 if ($apptransport['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #FF8C00; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $apptransport['total']; ?></b> Approvement for TRANSPORT REQUEST.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

            </a>
            
            <!--Transport HOD Approvement-->
    	    <a href="aims_car_hod_list.php" style="color: #000039">
                                   <?
                                    $notiAppTransport= getcarRequestHodBaharu($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
													
											while($apptransport = $notiAppTransport->fetch_assoc()){
									?>
									<?
									 if ($apptransport['total'] > 0) {
									?>
									<div class="notification notification-warning notification-closable" role="alert" style="background-color: #F1C40F; border-width: 0.0625rem; border-radius: .25rem;padding:1rem">
                					<strong>ATTENTION</strong> You have <b><?php echo $apptransport['total']; ?></b> Approvement for TRANSPORT REQUEST.
                					<button type="button" class="close" data-close="notification">
                					<span>&times;</span>
                                    </button>
                                    </div>
									<?}?>
									<?}?>

            </a>
    
		
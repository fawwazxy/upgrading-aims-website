<?php

include ('../controller/auth.php');

require "../model/aims_gl_function.php";


$id = $_GET['id'];
$data = getItemHkById($id)->fetch_assoc(); 
?> 


<form method="post" action="../controller/aims_gl_hk_item_update_exec.php" >     
	<input id="id" name="id" type="hidden" value="<? echo $id?>"/>



	<label><font color="red">** Maklumat Wajib Diisi.</font></label>
	<br>


	<div class="form-group"  align="left">
		<label>ITEM<font color="red">**</font>&nbsp;</label>
		<input class="form-control" onkeyup="convertToUppercase(this)" name="item" id="item" value="<? echo $data['item'];?>" >
	</div>

	<div class="form-group"  align="left">
		<label>CODE<font color="red">**</font>&nbsp;</label>
		<input class="form-control" onkeyup="convertToUppercase(this)" name="code" id="code" value="<? echo $data['code'];?>" >
	</div>

	<div class="modal-footer">
		<button type="submit" class="btn btn-primary">Save</button>

	</div>

</form>

<script>

    function convertToUppercase(el) {
        if(!el || !el.value) return;
        el.value = el.value.toUpperCase();
    }
    
    
</script>

<?php

include ('../controller/auth.php');


require "../model/aims_carReserve_function.php";
require "../model/lookup.php";


$id = $_POST['id'];
$car_info = getcarRequestById($id)->fetch_assoc();
?>


<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>DRIVER NAME</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['drivername'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>PURPOSE</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['purpose'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>DESTINATION</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['destination'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>COMPANY</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['description'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>TYPE OF CAR</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['car_type'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>NO. PASSENGERS</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['no_passengers'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>PLATE NO</label>
    </div>
    <div class="col-xs-8">
       <?echo '<b>'.$car_info['car_plate_no'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>DEPARTURE DATE</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['dep_date'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>DEPARTURE TIME</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['dep_time'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>DEPARTURE MILEAGE</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['dep_milage'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>RETURN DATE</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['return_date'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>RETURN TIME</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['return_time'].'</b>';?>
    </div>
</div>

<div class="form-group row" align="left">
    <div class="col-xs-4">
        <label>RETURN MILEAGE</label>
    </div>
<div class="col-xs-8">
       <?echo '<b>'.$car_info['return_milage'].'</b>';?>
    </div>
</div>


<script>
    function convertToUppercase(el) {
        if(!el || !el.value) return;
        el.value = el.value.toUpperCase();
    }
</script>

<?php

include ('../controller/auth.php');

require "../model/aims_carReserve_function.php";
require "../model/lookup.php";

$id = $_GET['id'];
$car_info = getcarsummonById($id)->fetch_assoc();

?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Summon Edit</h1>
                </div>
            </div>

            <div class="form-group" align="right">
            </div>
            
             
             <div class="row">
                <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel panel-body">
					<form method="post" action="../controller/aims_carSummon_update.php">
					 <input type="hidden" name="id" value="<?php echo $car_info['id']; ?>">
				     <input type="hidden" name="summon_by" value="<?php echo $_SESSION['SESS_NAME']; ?>">
				
				<label class="control-label">SUMMON DETAILS<font color="red">&nbsp;</font></label>
				<hr>
				
				

				<div class="form-group row" align="left">
					<div class="col-xs-6">
						<label class="control-label">Applicant Name<font color="red">&nbsp;*</font></label>
                        <input class="form-control" id="name" name="name" type="text" value="<? echo $car_info['name'] ?>" readonly />
					</div>

					<div class="col-xs-6">
						<label class="control-label"> Company <font color="red">&nbsp;*</font></label>
                        <input class="form-control" id="company_name" name="company_name" type="text" value="<? echo $car_info['company_name'] ?>" readonly />
						</select >
					</div>	
					
				</div>
				
			
				
				
				
				<div class="form-group row" align="left">
				
					<div class="col-xs-6">
					 <label class="control-label">Plate Number<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="car_plate_no" name="car_plate_no" type="text" value="<?php echo $car_info['car_plate_no']; ?>" required value="<?php echo $car_info['car_plate_no']; ?>" style="text-transform:uppercase" readonly />
					</div>	
					
					<div class="col-xs-6">
						<label class="control-label">Issue district<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="issue_distric" name="issue_distric" type="text" required value="<?php echo $car_info['issue_distric']; ?>" style="text-transform:uppercase" onkeyup="convertToUppercase(this)"/>
					</div>
					
				</div>
				
				<div class="form-group row" align="left">
					<div class="col-xs-6">
						<label class="control-label">Summon No<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="summons_no" name="summons_no" type="text" required value="<?php echo $car_info['summons_no']; ?>" style="text-transform:uppercase" onkeyup="convertToUppercase(this)"/>
					</div>

					<div class="col-xs-6">
                        <label class="control-label">offense(date/time)<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="offense" name="offense" type="datetime-local" value="<?php echo date('Y-m-d\TH:i:s', $car_info['offense']); ?>" style="text-transform:uppercase" />
					</div>					
					
				</div>				

				<div class="form-group row" align="left">

					<div class="col-xs-4">
                        <label class="control-label">Enforcement Date<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="enforcement_date" name="enforcement_date" type="date" required value="<?php echo $car_info['enforcement_date']; ?>" style="text-transform:uppercase" />
					</div>
					
					<div class="col-xs-4">
					 <label class="control-label">Offense Details<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="offense_details" name="offense_details" type="text" value="<?php echo $car_info['offense_details']; ?>" style="text-transform:uppercase" onkeyup="convertToUppercase(this)"/>
					</div>

					<div class="col-xs-4">
					 <label class="control-label">Original Amount (RM)<font color="red">&nbsp;*</font></label>
						<input class="form-control" id="original_amount" name="original_amount" type="text" value="<?php echo $car_info['original_amount']; ?>" style="text-transform:uppercase"/>
					</div>
					
				</div>
				
			
				<div align="center">
					<button type="submit" class="btn btn-success">Edit</button>
					<button type="reset" class="btn btn-warning">Reset</button>
					<button type="reset" onclick="goBack()" class="btn btn-primary">Back</button>
				</div>
				</div>	
			</form>
			</div>
			<script>
				function convertToUppercase(el) {
					if(!el || !el.value) return;
					el.value = el.value.toUpperCase();
				}
			</script>
								
							</div>
							<!-- /.col-lg-12 -->
						</div>
						<!-- /.row -->
						<!-- /.container-fluid -->
					</div>

					<!-- /#page-wrapper -->

				</div>
				<!-- /#wrapper -->
				<? include ('../global/footer.php'); ?>

				<!-- Page-Level Demo Scripts - Tables - Use for reference -->
				<script>
					$(document).ready(function() {
						$('#dataTables-example').DataTable({
							responsive: true
						});
					});
					</script>
					
					<script>
				function goBack() {
				  window.history.back();
				}
				</script>

</body>

</html>
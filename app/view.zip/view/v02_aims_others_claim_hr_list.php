<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
require "../model/lookup.php";

$no_staff = $_SESSION['SESS_NO_STAFF'];
$id = $_SESSION['SESS_ID'];
$department = $_SESSION['SESS_DEPARTMENT'];
$department_sub = $_SESSION['SESS_DEPARTMENT_SUB'];
$sys = getSys(1)-> fetch_assoc();
$verification = ($_GET['verification'])?: 'PENDING';
/*$payment_status = ($_GET['payment_status'])?:'OPEN';*/
$claim_status = ($_GET['claim_status'])?:'OPEN';
$month=$_GET['month'] ?: 0;
$year= $_GET['year'] ?: date('Y');
$department_code = ($_GET['department_code'])?: 'SB';
$review_status = $_GET['review'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <? require "../global/header.php"; ?>
    <style>
        .claim-status{
            padding:3px;
            border-radius: 5px;
            font-weight:bold;
            color: #ffffff;
        }

        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab a {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 16px;
            text-decoration: none;
            color: #000000;
            border-radius: 5%;
        }

        /* Change background color of buttons on hover */
        .tab a:hover {
            background-color: #ddd;
            text-decoration: none;
        }

        /* Create an active/current tablink class */
        .tab a.active {
            background-color: #FFA500;
        }

        /* Style the tab content */
        .tabContent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
</head>
<body>

<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <? include ('../global/menu_top.php'); ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
        </div>
    </nav>

    <div id="page-wrapper">
        <!--<?include '../global/menu_keselamatan.php'?>-->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> HR REVIEW
                    <a href="aims_others_claim_hr_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>Switch to Version 01
                    </a>
                </h1>
            </div>
        </div>

        <div class="row" style="margin-bottom: 16px">
            <form method="GET" action="">
                <!--<div class="col-lg-1">
                    <label for="department_code" style="margin: 6px 0 0 8px">Search : </label>
                </div>-->
                <div class="col-lg-2" style="margin-bottom: 8px">
                    <select required class="form-control" name="month" id="month">
                        <? echo v02getDropDownMonth($month);?>
                    </select>
                </div>
                <div class="col-lg-2" style="margin-bottom: 8px">
                    <select required class="form-control" name="year" id="year">
                        <? echo v02getDropDownYear($year);?>
                    </SELECT>
                </div>
                <div class="col-lg-4">
                    <select required class="form-control" name="department_code" id="department_code" style="">
                        <option value="SB" <? if ($department_code == 'SB') echo 'selected';?>>-- SELECT COMPANY --</option>
                        <? echo getdropdown("department","code_department","description",$department_code);?>
                    </select>
                </div>
                <div class="col-lg-3" style="margin-bottom: 8px">
                    <button type="submit" class="btn btn-info">Search</button>
                    <a href="v02_aims_others_claim_hr_list.php?department_code=SB&verification=PENDING&payment_status=OPEN" class="btn btn-default" style="background-color: #b0b0b0">Reset</a>
                </div>
            </form>
        </div>

        <div class="tab">
            <a href="v02_aims_others_claim_hr_list.php?department_code=<? echo $department_code;?>&verification=PENDING&claim_status=OPEN"
               class="tabLinks <? if($verification == "PENDING" && $claim_status == "OPEN") echo 'active'?>">
                NEW </a>
            <a href="v02_aims_others_claim_hr_list.php?department_code=<? echo $department_code;?>&verification=REVIEWED&claim_status=OPEN"
               class="tabLinks <? if($verification == "REVIEWED" && $claim_status == "OPEN") echo 'active'?>">
                REVIEWED</a>
            <a href="v02_aims_others_claim_hr_list.php?department_code=<? echo $department_code;?>&verification=DISAPPROVED&claim_status=OPEN"
               class="tabLinks <? if($verification == "DISAPPROVED" && $claim_status == "OPEN") echo 'active'?>">
                DISAPPROVED </a>
           <a href="v02_aims_others_claim_hr_list.php?department_code=<? echo $department_code;?>&verification=REVIEWED&claim_status=CLOSED"
               class="tabLinks <? if($verification == "REVIEWED" && $claim_status == "CLOSED") echo 'active'?>">
                CLOSED</a>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <input name="id" type="hidden" class="input-short" value="<? echo $id;?>" />
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th style="text-align:center;" width="5%">No.</th>
                                <th style="text-align:center;" width="25%">Staff Info</th>
                                <th style="text-align:center;" width="20%">Month Claim</th>
                                <th class="text-center" style="width: 13%">HOD Status</th>
                                <th style="width: 13%" class="text-center">HR Status</th>
                                <th style="text-align:center;" width="10%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?
                            //List every staff and month claim in a single row e.g. 011212-11-6312 -- August 2022;
                            $claim_by_month = v02getMonthClaimListHR($department_code, $no_staff, $verification,$claim_status,$month, $year);
                            $i = 1;
                            while($month_claim = $claim_by_month->fetch_assoc()){
                                //get total number of claim verified by HOD
                                /*$claim_count = v02HRgetClaimListByStaff($month_claim['no_staff'], $month_claim['month_claim'],$verification, $payment_status);*/
                                //get total number of claim submitted by staff
                                $count_total = v02getCountTotalByStaff($month_claim['no_staff'],$month_claim['month_claim']);
                                $hr_cc = v02HRgetClaimListHR($month_claim['no_staff'], $month_claim['month_claim'], $verification, $claim_status);

                                /*$count_total = v02getCountTotalByStaff($month_claim['no_staff'],$month_claim['month_claim']);*/
                                if ($verification == "PENDING") {
                                    $status_color = 'GREY';
                                } else if ($verification == "REVIEWED") {
                                    $status_color = 'GREEN';
                                }else{
                                    $status_color = 'RED';
                                }
                                ?>
                                <tr>
                                    <td><? echo $i++?></td>
                                    <td>
                                        <b>Name:</b> <?echo $month_claim['name'];?><br>
                                        <b>IC No:</b> <?echo $month_claim['noic'];?><br>
                                        <b>Position:</b> <?echo $month_claim['role_id'];?><br>
                                        <b>Department:</b> <?echo $month_claim['department_sub'];?><br>
                                        <b>Company:</b> <?echo $month_claim['department_id'];?>
                                    </td>
                                    <td class="text-center"><? echo $month_claim['month_claim']; ?></td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: GREEN">
                                            VERIFIED
                                        </p>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: <? echo $status_color; ?>">
                                            <? echo $verification.' ('.$hr_cc.')'; ?>
                                        </p>
                                    </td>
                                    <td class="text-center">
                                        <a href="v02_aims_others_claim_hr_approval.php?nostaff=<? echo $month_claim['no_staff']?>&department_code=<? echo $department_code;?>&month_claim=<? echo $month_claim['month_claim']?>&verification=<? echo $verification?>&claim_status=<? echo $claim_status ?>"
                                            class="btn btn-sm btn-secondary" title="HR Action"><i class="fa fa-regular fa-gear"></i></a>
                                    </td>
                                </tr>
                                <?
                            } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<? include ('../global/footer.php'); ?>
<script>
    // Delete row on delete button click

    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
</script>
</body>
</html>




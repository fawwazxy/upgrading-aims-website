<?php

	include ('../controller/auth.php');

	require "../model/aims_carReserve_function.php";

?>
<?        
$id = $_GET['id'];
$raw_data = getcarRequestById($id)->fetch_assoc();
 ?> 

                     
                      <form method="post" action="../controller/aims_carstatusHod_update.php?id=<? echo $id ?>" >     
							
                              
							  
                             
							  <label><font color="red">** Maklumat Wajib Diisi.</font></label>
                            <br>
							<input type="hidden" name="id" value="<?php echo $raw_data['id']; ?>">
							
							
                                <div class="form-group"  align="left">
                                  <label>Name Applicant&nbsp;</label>
                                  <br><?php echo $raw_data['name'];?><br>
								
                                </div>							
                                
								<div class="form-group"  align="left">
								<label class="control-label">HOD/SBU</label>
								<br><?php echo $_SESSION['SESS_NAME']; ?>
								<input type="hidden" name="approve_by" value="<?php echo $_SESSION['SESS_NAME']; ?>"/>
								</div>
								
                                <div class="form-group"  align="left">
								<label>Status:</label></br>
								<input type="radio" name="sbu_hod_app" <?php if($raw_data['sbu_hod_app']=="PENDING") {echo "checked";}?> value="PENDING"> PENDING
								<input type="radio" name="sbu_hod_app" <?php if($raw_data['sbu_hod_app']=="APPROVE") {echo "checked";}?> value="APPROVE"> APPROVE
								<input type="radio" name="sbu_hod_app" <?php if($raw_data['sbu_hod_app']=="DISAPPROVE") {echo "checked";}?> value="DISAPPROVE"> DISAPPROVE
                                </div>						



                             <div class="modal-footer">
                                   <button type="submit" class="btn btn-primary">Simpan</button>
                                  
                             </div>
         
         </form>
                      
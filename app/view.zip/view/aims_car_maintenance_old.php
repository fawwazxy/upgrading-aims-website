<?php

include ('../controller/auth.php');

require "../model/aims_car_function.php";
require "../model/lookup.php";

$car_model=$_GET['car_model'];
if(!isset($car_model)){
$car_model = NONE;
}
$year=$_GET['year'];
$names = getcarByinspecbyName($_SESSION['SESS_NAME'])->fetch_assoc();
?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #f2f2f2;
  font-family: 'Poppins';
}
h1{
  text-transform: uppercase;
  letter-spacing: 3px;
  color: rgba(0,0,0, 0.45);
}
    .content__table{
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 200px;
      border-radius: 5px 5px 0 0;
      box-shadow: 0 0 20px rgba(0,0,0, 0.15);

    }
    .content__table thead tr{
      background-color: #f1c40f;
      color: rgba(0,0,0, 0.45);
      text-align: left;
      font-weight: bold;
      text-transform: capitalize;
    }

    .content__table th,
    .content__table td {
      padding: 12px 15px;
    }
    .content__table tbody tr{
      /*border-bottom: 1px solid #aaa;*/
      color: #444;
      text-align: center;
    }
    .content__table tbody tr:nth-of-type(even){
      background-color: rgba(241,196,15,0.30);
    }
    .content__table tbody tr:last-of-type{
      border-bottom: 2px solid #f1c40f;
    }
    .content__table tbody tr.active__row{
      font-weight: bold;
      color: #f1c40f;
    }
.content__table tbody tr td:hover{
  background-color: #f1c40f;
  color: #444;
  font-weight: bold;
  cursor: pointer;
}

.footer{
font-weight: 600;
color: #444;}
.footer a{
  color: #444;
}
.footer a:hover{
  background-color: rgba(241,196,15,0.3);
}



.btn-group button {
  background-color: #c0c0c0; /* Green background */
  border: 1px solid green; /* Green border */
  color: white; /* White text */
  padding: 5px 5px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color:#708090;
}

.modal-header{
  background-color:#f1c40f;
}


</style>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 5px;
  font-size:12px;
  
}

</style>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
		
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Vehicle Maintenance</h1>
                </div>
            </div>
			
			<div class="row">
			<div class="col-lg-4">
				 
							<select  required class="form-control" name="car_model" id="car_model">
									<option value="">-- Choose Vehicle--</option>
									<? echo getDropDown("aims_car_info","car_model","car_model",$car_model);?>
							</select>
					
	          </div>
			  <div class="col-lg-4">
				 
							<select  required class="form-control" name="year" id="year" value="<?echo $year?>">
									<option value="">-- Choose Year--</option>
									<? echo getDropDownYear($year);?>
							</select>
					
	          </div>
	          <div class="col-lg-4" style="text-align:right">
			  <button onclick="window.location.href='aims_maintenance_report.php?car_model=<? echo $car_model ?>&year=<? echo $year ?>'" aria-hidden="true">Print</button>
			  </div>
			  </div>
			
			<?
			$car_model = $_GET['car_model'];		
             $model = getcarByModel($car_model)->fetch_assoc();
            ?>
		
            <div class="form-group" align="right">
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table>
						  <tr>
							<td colspan="2" style="text-align:center" width="50%"><b>ASSET OF COMPANY</b>
							<br> <b> COMPANY NAME : </b><? echo $model['description'];?></td>
						  </tr>
						  <tr>
							<td colspan="2" style="text-align:center" width="50%"><b>DETAILS OF ASSET</b></td>
						  </tr>
						  <tr>
							<td width="50%"><b>Category : </b> <? echo $model['car_category'];?></td>
							<td><b>Cost and Date Of Receipt : </b> <? echo $model['cost_receipt'];?> (<? echo $model['date_receipt'];?>)</td>
						  </tr>
						  <tr>
							<td width="50%"><b>Type : </b> <? echo $model['car_type'];?></td>
							<td><b>Registration No : </b> <? echo $model['car_plate_no'];?></td>
						  </tr>
						  <tr>
							<td width="50%"><b>Brand or Model : </b> <? echo $model['car_model'];?></td>
							<td width="50%"><b>Suppliers : </b> <? echo $model['suppliers'];?></td>
						  </tr>
						  <tr>
							<td width="50%"><b>Type & Engine No : </b> <? echo $model['engine_no'];?></td>
							<td width="50%"><b>Hire Purchases Account No : </b> <? echo $model['hire_account_no'];?> (<? echo $model['name_account'];?>)</td>
						  </tr>
						  <tr>
							<td width="50%"><b>Chassis No : </b> <? echo $model['chassis_no'];?></td>
							<td width="50%"><b>The Original Colour : </b> <? echo $model['color'];?></td>
						  </tr>
						</table>
                    </div>
					
					<div class="panel-body">
                        <table>
						  <tr>
							<td colspan="8" style="text-align:center" width="50%"><b>PARTICULARS OF ASSETS MAINTENANCE</b></td>
						  </tr>
						  <tr>
							<td colspan="4"><b>TYPE, BRAND AND MODEL : <? echo $model['car_model'];?></b></td>
							<td colspan="4"><b>REGISTRATION NO : </b> <? echo $model['car_plate_no'];?></td>
						  </tr>
						  <tr>
							<td>KILMETRE READING (KM)</td>
							<td>ODOMETRE READING (KM)</td>
							<td>DATE</td>
							<td>SERVICE DETAIL</td>
							<td>PLACE OF SERVICE/REPAIRS</td>
							<td>ISSUE IDENTIFIED DURING INSPECTION</td>
							<td>DURATION PERIOD</td>
							<td>ACTION</td>
						  </tr>
						   <?
                                    $car1 = getcarByinspec($car_model,$year);
                                    $i=1;
                                    while($listinspec = $car1->fetch_assoc()) {
                            ?>
						  <tr>
							<td><? echo $listinspec['km_read']; ?></td>
							<td><? echo $listinspec['odom_read'];?></td>
							<td><? echo $listinspec['date'];?></td>
							<td><b> Job description</b><br>
							<? echo $listinspec['job_desc'];?>
							<br><b> Item description</b><br>
							<? echo $listinspec['item_desc'];?>
							</td>
							<td><? echo $listinspec['place_service'];?><br>
							<b>Invoice No : </b><? echo $listinspec['invoice_no'];?><br>
							<b>Cost : </b> RM<? echo $listinspec['costing'];?></td>
							<td><? echo $listinspec['exterior_car'];?><br>
							<? echo $listinspec['comment1'];?><br> 
							<? echo $listinspec['interior_car'];?><br>
							<? echo $listinspec['comment'];?></td>
							<td><? echo $listinspec['duration'];?></td>
							<td style="text-align:center"><?php echo "<a href='#myModal1' data-toggle='modal' data-id=".$listinspec['id']." data-status=".$listinspec['status']." data-car=".$listinspec['car_id']." data-main=".$listinspec['main_id']." ><i class='fa fa-edit'></i></a>"; ?></td>
						  
									<?}?>
							</tr>
						</table>
                    </div>
               
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>
<!-- 
        <!-- /#page-wrapper -->

    </div></div>
    <!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>
							 

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Update</h4>
        </div>
        <div class="modal-body" id="demo">
        <script type="text/javascript">
          $('#myModal1').on('show.bs.modal', function (e) {
			var id = $(e.relatedTarget).data('id');
			var car_id = $(e.relatedTarget).data('car');
			var status = $(e.relatedTarget).data('status');
			var main_id = $(e.relatedTarget).data('main');
            // $('#demo').html(rowid);
            $.ajax({
              type:'POST',
              url:'aims_car_maintenance_update.php',
			  data:{id:id,car_id:car_id,status:status,main_id:main_id},
              success:function(html){
                $('#demo').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
</div>
</div>


    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });
			$("#car_model").change(function(){
		 var selected_cawangan=$(this).val();
		 sendType(selected_cawangan);
		 });
		 
		 $("#year").change(function(){
					if($("#car_model").val()=='' ){
						alert('SELECT CAR MODEL!')
						$("#year").val('');
					}else{
						var selected_year=$(this).val();
						var selected_car_model = $("#car_model").val();
						reloadYear(selected_year,selected_car_model);

					}
				});
		 
        });

        function sendType(type)
	 {
		window.location.href="aims_car_maintenance.php?car_model="+type;
		
	}
	
	function reloadYear(selected_year,selected_car_model){
	            //console.log(obj);
	            location.href = "aims_car_maintenance.php?car_model="+selected_car_model+"&year="+selected_year;
	        }
    
    </script>

</body>

</html>
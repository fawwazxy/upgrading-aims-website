<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<? 
	require "../model/functions.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>
<? $sys = getSys(1) -> fetch_assoc(); ?>
<body>
<h1 align="center">
<? echo '<img width="300" height="200" src="data:image/png;base64,'.base64_encode( $sys['logo'] ).'"/>'; ?>
</h1>
<h4 align="center"><? echo $sys['sys_tagline']; ?>&nbsp;(Versi:<? echo $sys['shortcode']; ?> - <? echo $sys['version']; ?>)</h4>
    <div class="container">
        <div class="row">
            <? include "../global/it_announcement.php"; ?>
        </div>
        
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Sila Log Masuk</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="../controller/login_exec.php" method="POST">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Nama" name="username" type="text" required="" autofocus/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Kata Laluan" name="password" type="password" required=""/>
                                </div>
                                <input type="submit" class="btn btn-lg btn-primary btn-block" value="Log Masuk"/>
                            </fieldset>


                        </form>



                    </div>

                </div>
                
            </div>

        </div>
    </div><br><br><br>
   <h5> <? include ('../global/footer.php'); ?></h5>

</body>

</html>
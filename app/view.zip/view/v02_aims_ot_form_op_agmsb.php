<?php
include ('../controller/auth.php');
require "../model/v02_aims_ot_function.php";

$no_staff = $_GET['no_staff'];

$ot_day_closed = ($_SESSION['SESS_DEPARTMENT_SUB'] == 'MOORING-GANG') ? 20 : 18;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>
</head>
<body>
<div id="wrapper">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <!-- /.navbar-header -->
        <? include ('../global/menu_top.php'); ?>

        <!-- /.navbar-top-links -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
            <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
    </nav>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OVERTIME CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> NEW
                    <a href="aims_ot_form.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>
                        Switch to Version 01
                    </a>
                    <a href="v02_aims_ot_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                        Back to list
                    </a>
                </h1>
            </div>
        </div>
            
        <div class="row">
            <? include "v02_aims_ot_migration_message.php"; ?>
        </div>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">

                    <!-- /.panel-heading -->
                    <div class="panel-heading">
                        <label>REMINDER: PLEASE FILL UP CLAIM BEFORE <? echo $ot_day_closed ?>th DAY OF EVERY MONTH. <? echo date('l', strtotime("2022-03-13")); ?><br>
                            FOR OVERTIME DATE <span style="color: red">OVER <? echo $ot_day_closed ?>th, PLEASE CHOOSE NEXT MONTH AS THE MONTH CLAIM.</span></label>
                    </div>
                    <div class="panel-body">
                        <div class="col-sm-12">
                            <form method="post" action="../controller/v02_aims_otadd_op_agma_exec.php" enctype="multipart/form-data">
                                <input type="hidden" id="no_staff" name="no_staff" value="<?php echo $_SESSION['SESS_NO_STAFF'] ?>" />
                                <div class="form-group row">

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="no_staff_applicant">FROM </label><br>
                                            <input readonly type="text" class="form-control" placeholder="" id="" name="" value="<?php echo $_SESSION['SESS_NAME'] ?>" />
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label for="code_department">DEPARTMENT</label><br>
                                            <input readonly type="text" required class="form-control" placeholder="" id="code_department" name="" value="<?php echo $_SESSION['SESS_DEPARTMENT_SUB'] ?>" />
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Claim For The Month Ended: <span style="color: red">**</span></label><br>
                                            <select required class="form-control" name="month_claim" id="month_claim">
                                                <? $suggested_month_claim = date('d') <= $ot_day_closed ? date("Y-m"): date("Y-m", strtotime("first day of next month", time()));
                                                echo v02getDropDownMonthClaim($suggested_month_claim, 0);?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Types of Claim:</label><br>
                                            <input type="text" required class="form-control" placeholder="" id="type_claim" name="" disabled value="OT CLAIM" onkeyup="convertToUppercase(this)">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="otp_date">DATE &nbsp;<span class="text-danger">**</span></label><br>
                                            <input type="date" class="form-control" placeholder="" id="date_ot" name="date_ot" value="<? echo date('Y-m-d')?>" style="min-width:95%"/>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="day">Day: </label><br>
                                            <input type="text" required class="form-control" id="day" value="<? echo date('l') ?>" disabled/>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="start_ot">Start: <span style="color: red">**</span></label><br>
                                            <input type="time" required="" class="form-control" placeholder="" onchange="diff()" id="start_ot" name="start_ot" value="17:00" style="min-width:95%" />
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="end_ot">End: <span style="color: red">**</span></label><br>
                                            <input type="time" required class="form-control" placeholder="" onchange="diff()" id="end_ot" name="end_ot" value="22:00" style="min-width:95%" />
                                            <span id="timeWarning" style="font-size: 12px;color: red"></span>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="working_hours">Working Period: (Hours)</label><br>
                                            <input type="text" required readonly class="form-control" placeholder="" id="working_hours" name="working_hours" value="05H 00M" onkeyup="convertToUppercase(this)">
                                            <input type="hidden" id="total_hours" name="total_hours" value="5.0" />
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label for="rate_mode">MODE &nbsp;<span class="text-danger">**</span></label><br>
                                            <select required class="form-control" name="rate_mode" id="rate_mode">
                                                <option value="">-- Overtime Mode --</option>
                                                <option value="1.5">NORMAL WORKING DAY</option>
                                                <option value="2.0">OFF-DAY / WEEKEND</option>
                                                <option value="3.0">PUBLIC HOLIDAY</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="description">Work Description: <span style="color: red">**</span>&nbsp;</label><br>
                                            <textarea id="description" name="description" rows="5" cols="70"  required="" class="form-control" placeholder=""
                                                      onkeyup="convertToUppercase(this)"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-8">
                                        <div class="form-group">
                                            <label>Attachment <span style="color: red"><i>(Only pdf/jpeg/jpg/png/gif format file are allowed)</i></span></label>
                                            <input type="hidden" name="MAX_FILE_SIZE">
                                            <input type="file" accept=".jpg,.jpeg,.png,.gif,.pdf" name="document" id="document">
                                        </div>
                                    </div>
                                </div>

                                <label>REMINDER: PLEASE FILL UP CLAIM BEFORE <? echo $ot_day_closed ?>th DAY OF EVERY MONTH.
                                    FOR DATE <span style="color: red">OVER <? echo $ot_day_closed ?>th, PLEASE CHOOSE NEXT MONTH AS THE MONTH CLAIM.</span></label>
                                <div class="modal-footer">
                                    <div class="text-center">
                                        <button type="submit" id="submitBtn" class="btn btn-primary">Submit</button>
                                    </div>
                                </div><br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<? include ('../global/footer.php'); ?>
<script>
    function convertToUppercase(el) {
        if(!el || !el.value) return;
        el.value = el.value.toUpperCase();
    }
    
    function convertDateForIos(date) {
        var arr = date.split(/[- :]/);
        date = new Date(arr[0], arr[1]-1, arr[2], arr[3], arr[4], arr[5]);
        return date;
    }

    function diff() {
        var timein = $('#start_ot').val(),
            timeout = $('#end_ot').val(),
            timeStart = "1970-1-1 " + timein+":00",
            timeEnd = "1970-1-1 " + timeout+":00";

        if(timeout<=timein){
            timeEnd =  "1970-1-2 " + timeout + ":00";
        }

        let diffInMinutes = (convertDateForIos(timeEnd) - convertDateForIos(timeStart)) / 1000 / 60;
        let diffInHours = diffInMinutes/60;
        let hours = Math.floor(diffInHours);
        let minutes = Math.floor(diffInMinutes%60);

        minutes = minutes.toString().length<2?'0'+minutes:minutes;
        hours = hours.toString().length<2?'0'+hours:hours;

        $('#working_hours').val(hours + 'H ' + minutes + 'M');
        $('#total_hours').val(diffInHours.toFixed(2));
    }

    $('#start_ot, #end_ot').change(function (){
        let timein = $('#start_ot').val(),
            timeout = $('#end_ot').val(),
            dateOt = $('#date_ot').val();

        let tomorrow = new Date(dateOt);
        tomorrow.setDate(tomorrow.getDate() + 1);

        let nextDay = String(tomorrow.getDate()).padStart(2,'0')+'/'+String(tomorrow.getMonth()+1).padStart(2,'0')+'/'+tomorrow.getFullYear();
        if(timeout<=timein){
            $('#timeWarning').html('END TIME > START TIME;<br> End time date has been set to '+nextDay);
        }else{
            $('#timeWarning').html('');
        }
    });

    $('#date_ot').change(function (){
        let dayArray = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        let date = $(this).val();
        let newDate = new Date(date);
        let dayIndex = newDate.getDay();

        $('#day').val(dayArray[dayIndex]);
    });
</script>
</body>
</html>


<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
require "../model/lookup.php";

$nostaff = $_SESSION['SESS_NO_STAFF'];
//$id = $_SESSION['SESS_ID'];
$department = $_SESSION['SESS_DEPARTMENT'];
$department_sub = $_SESSION['SESS_DEPARTMENT_SUB'];
$sys = getSys(1)-> fetch_assoc();
$verified_name = $_SESSION['SESS_NAME'];

$verification = ($_GET['verification'])?: 'PENDING';
$department_code = ($_GET['department_code'])?: 'SB';
$no_staff = $_GET['nostaff'];
$month_claim = $_GET['month_claim'];
$claim_status = ($_GET['claim_status'])?:'OPEN';

$staff = v02getStaffDetails($no_staff)->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <? require "../global/header.php"; ?>
    <style>
        .rm-badge{
            padding:3px;
            border-radius: 5px;
            font-weight:bold;
            color: #ffffff;
            background-color: green;
        }

        .claim-status{
            color:WHITE;
            padding:5px;
            border-radius: 5px;
            font-weight:bold;
        }
    </style>
</head>
<body>

<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <? include ('../global/menu_top.php'); ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
        </div>
    </nav>

    <div id="page-wrapper">
        <!--<?include '../global/menu_keselamatan.php'?>-->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> HR VERIFICATION
                    <a href="aims_others_claim_hr_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>Switch to Version 01
                    </a>
                    <a href="v02_aims_others_claim_hr_list.php?department_code=<? echo $department_code?>&verification=<? echo $verification?>&claim_status=<? echo $claim_status?>" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                        Back to list
                    </a>
                </h1>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel-heading">
                    <table style="width: 100%">
                        <tr>
                            <th style="width: 15%">STAFF NAME</th>
                            <td style="width: 35%">: <? echo $staff['name']?></td>
                            <th style="width: 20%">CLAIM FOR THE MONTH ENDED</th>
                            <td style="width: 30%">: <? echo $month_claim?></td>
                        </tr>
                        <tr>
                            <th>IC</th>
                            <td>: <? echo $staff['noic'] ?></td>
                            <th>ROLE</th>
                            <td>: <? echo $staff['role_id']?></td>
                        </tr>
                        <tr>
                            <th>DEPARTMENT</th>
                            <td>: <? echo $staff['department_sub']?></td>
                            <th>COMPANY CLAIM</th>
                            <td>: <? echo $staff['department_id']?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <form name="" method="post" action="../controller/v02_aims_others_claim_review.php">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th style="width: 2%">No.</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Detail Description</th>
                                <th class="text-center">Total Claim</th>
                                <th class="text-center">HOD Status</th>
                                <th class="text-center">HR Status</th>
                                <th class="text-center">Finance Status</th>
                                <th class="text-center">CEO/CHAIRMAN Status</th>
                                <th class="text-center" style="width: 16%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?
                            $i=1;
                            $total_cost=0.00;
                            $claim_list = v02getDetailStaffHR($no_staff,$month_claim,$verification,$claim_status);
                            while($claim = $claim_list->fetch_assoc()) {

                                //HOD status -> PENDING / VERIFIED / UNVERIFIED
                                if (empty($claim['verify_by']) && empty($claim['verify_at'])){
                                    $hod_text_color = 'GREY';
                                    $hod_text_status = 'PENDING';
                                }else{
                                    if ($claim['verify_status'] == '1' && $claim['verify_by'] == 'AUTO VERIFIED'){
                                        $hod_text_color = 'GREEN';
                                        $hod_text_status = 'NO SUPPORT NEEDS';
                                    } elseif ($claim['verify_status'] == '1' ){
                                        $hod_text_color = 'GREEN';
                                        $hod_text_status = 'VERIFIED';
                                    }else{
                                        $hod_text_color = 'RED';
                                        $hod_text_status = 'UNVERIFIED';
                                    }
                                }

                                //HR status
                                if (empty($claim['review_by']) && empty($claim['review_at'])){
                                    $hr_text_color = 'GREY';
                                    $hr_text_status = 'PENDING';
                                }else{
                                    if ($claim['review_status'] == '1'){
                                        $hr_text_color = 'GREEN';
                                        $hr_text_status = 'REVIEWED';
                                    }else{
                                        $hr_text_color = 'RED';
                                        $hr_text_status = 'DISAPPROVED';
                                    }
                                }

                                //CEO status
                                if (empty($claim['approve_by']) && empty($claim['approve_at'])){
                                    $ceo_text_color = 'GREY';
                                    $ceo_text_status = 'PENDING';
                                }else{
                                    if ($claim['approve_status'] == '1'){
                                        $ceo_text_color = 'GREEN';
                                        $ceo_text_status = 'APPROVED';
                                    }else{
                                        $ceo_text_color = 'RED';
                                        $ceo_text_status = 'DISAPPROVED';
                                    }
                                }

                                // Finance Status -> CHECK / UNCHECKED
                                if($claim['finance_status']== '1') {
                                    $finance_text_color = 'GREEN';
                                    $finance_text_status = 'CHECKED';
                                } else {
                                    $finance_text_color = 'GREY';
                                    $finance_text_status = 'UNCHECKED';
                                }

                                // Payment Status -> PAID / UNPAID
                                if (empty($claim['payment_status']) && empty($claim['payment_at'])){
                                    $payment_text_color = 'RED';
                                    $payment_text_status = 'UNPAID';
                                }else{
                                    if ($claim['payment_status'] == 'CLOSED'){
                                        $payment_text_color = 'GREEN';
                                        $payment_text_status = 'PAID';
                                    }else{
                                        $payment_text_color = 'RED';
                                        $payment_text_status = 'UNPAID';
                                    }
                                }
                                ?>
                                <tr>
                                    <td>
                                        <?
                                        if ($claim_status == 'CLOSED'){
                                            ?>
                                            <label style="margin: 0;"><?php echo $i++.'.'; ?></label>
                                            <?
                                        } else {
                                            ?>
                                            <input name="checkbox[]" type="checkbox" class="checkbox" id="checkbox[]" value="<?php echo $claim['id']; ?>" style="margin: 0;" />&nbsp;
                                            <label for="checkbox[]" style="margin: 0;"><?php echo $i++.'.'; ?></label>
                                            <?
                                        }
                                        ?>
                                        <!--<input name="checkbox[]" type="checkbox" class="checkbox" id="checkbox[]" value="<?php /*echo $claim['id']; */?>" style="margin: 0;" />&nbsp;
                                        <label for="checkbox[]" style="margin: 0;"><?php /*echo $i++.'.'; */?></label>-->
                                    </td>
                                    <td class="text-center">
                                        <?/* echo '<p title="'.date('d/m/Y',strtotime($claim['date_purchase'])).'">'.date('Y-m-d',strtotime($claim['date_purchase'])).'</p>';
                                        echo '<p class="claim-status" style="background-color: black">'.date('l',strtotime($claim['date_purchase'])).'</p>'; */?>
                                        <span style="color: transparent;"><? echo $claim['date_purchase'] ?></span>
                                        <?
                                        echo '<p class="claim-status" style="background-color: black">'.date('d/m/Y',strtotime($claim['date_purchase'])).'<br>'.date('l',strtotime($claim['date_purchase'])).'</p>';
                                        ?>


                                    </td>
                                    <td>
                                        <? echo (empty($claim['description'])) ? '<i class="text-muted" style="font-size: 12px">No Description</i>' : $claim['description']?>
                                        <? echo (empty($claim['remarks'])) ? '' :
                                            '<p class="claim-status" style="font-weight: bold;margin-top: 10px; color: black;background-color: lightgrey">REMARKS : <br>- '.$claim['remarks'].'</p>'
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <? echo 'RM '.$claim['total_claim']?>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: <?php echo $hod_text_color?>;"><?php echo $hod_text_status; ?></p>
                                        <?
                                        echo ($claim['verify_by'] == 'AUTO VERIFIED')? '' :
                                            v02getStaffName($claim['verify_by']).'<br>'.$claim['verify_at'];
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: <?php echo $hr_text_color?>"><?php echo $hr_text_status; ?></p>
                                        <?
                                        echo ($claim['review_status'] == '1' || $claim['review_status'] == '0')?
                                            v02getStaffName($claim['review_by']).'<br>'.$claim['review_at'] : '';
                                        ?>
                                        <br><br>
                                        <p><b>CLAIM STATUS :</b></p>
                                        <? echo ($claim['review_status'] == '1' && $claim['claim_status'] == 'CLOSED') ?
                                            '<p class="claim-status" style="background-color: green">CLOSED</p>'.$claim['claim_at'] :
                                            '<p class="claim-status" style="background-color: red;">OPEN</p>';
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <!--<p class="claim-status" style="background-color: <?php /*echo $finance_text_color*/?>"><?php /*echo $finance_text_status;*/?></p>-->
                                        <?
                                        echo ($claim['finance_status']== '1') ?
                                            '<p class="claim-status" style="background-color: '.$finance_text_color.'">'.$finance_text_status.'</p>'.v02getStaffName($claim['finance_by']).'<br>'.$claim['finance_at']
                                            :'<p class="claim-status" style="background-color: '.$finance_text_color.'">'.$finance_text_status.'</p>';
                                        ?>
                                        <br><br>
                                        <p><b>PAYMENT STATUS :</b></p>
                                        <?
                                        echo ($claim['finance_status'] == '1' && $claim['payment_status'] == 'CLOSED') ?
                                            '<p class="claim-status" style="background-color: '.$payment_text_color.'"> '.$payment_text_status.'</p>'.$claim['payment_at']
                                            :'<p class="claim-status" style="background-color: '.$payment_text_color. ';">UNPAID</p>';
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: <?php echo $ceo_text_color?>"><?php echo $ceo_text_status;?></p>
                                        <?
                                        echo ($claim['approve_status'] == '1' || $claim['approve_status'] == '0')?
                                            v02getStaffName($claim['approve_by']).'<br>'.$claim['approve_at'] : '';
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <a href="#viewDetail" id="clicktoViewDetail" class="btn btn-success" data-toggle="modal" data-id="<? echo $claim['id'];?>"
                                               title="View Claim" style="border: 1px solid black; margin-left: 2px"><i class="fa fa-info-circle" style="font-size: 24px"></i></a>

                                            <a href="v02_aims_others_claim_hr_update.php?id=<? echo $claim['id']; ?>" class="btn btn-info"
                                               title="Update Claim" style="border: 1px solid black"><i class="fa fa-edit" style="font-size: 24px"></i></a>

                                            <a href="../controller/v02_aims_others_claim_hr_delete_exec.php?id=<? echo $claim['id']?>" class="btn btn-danger"
                                               title="Delete Claim" style="border: 1px solid black" onclick="return confirm('Confirm delete claim form?')"><i class="fa fa-remove" style="font-size: 24px"></i></a>

                                            <? if ($claim['document_name'] != '') {?>
                                                <a href="#myModal2" data-toggle="modal" data-id="<? echo $claim['id'];?>" class="btn btn-warning"
                                                   title="View Attachment" style="border: 1px solid black"><i class="fa fa-file-picture-o" style="font-size: 24px;"></i></a>
                                            <? } ?>
                                        </div>

                                        <br>

                                        <?
                                        if (empty($claim['remarks'])){
                                            ?>
                                            <!--Display modal add remarks-->
                                            <a href="#viewAddRemarks" style="font-weight: bold; margin-bottom: 8px; margin-top: 5px"
                                               id="clicktoAddRemarks" class="btn btn-block btn-primary" data-toggle="modal" data-id="<? echo $claim['id'];?>"
                                               title="Add Remarks">ADD REMARKS</a>
                                            <?
                                        } else {
                                            ?>
                                            <a href="../controller/v02_aims_others_claim_hr_delete_remarks_exec.php?id=<? echo $claim['id'];?>"
                                               style="font-weight: bold; margin-bottom: 8px; margin-top: 5px" title="Delete Remarks" class="btn btn-block btn-danger" onclick="return confirm('Confirm Delete Remarks?')">
                                                DELETE REMARKS</a>
                                            <?
                                        }
                                        ?>

                                        <!--Button Print Report-->
                                        <?
                                        if ($claim_status == 'CLOSED'){
                                            ?>
                                            <a style="font-weight: bold; margin-bottom: 8px; margin-top: 5px" class="btn btn-block btn-warning" title="Print This Claim"
                                               onclick="return popitup('v02_aims_others_claim_report.php?id=<? echo $claim['id'];?>')">PRINT</a>
                                            <?
                                        }
                                        ?>

                                        <!--Button Closed / Open -> Used after HR finished sent document to finance -->
                                        <?
                                            if ($claim['verify_status'] == '1' && $claim['review_status'] == '1' && $claim['claim_status'] == 'OPEN'){
                                                ?>
                                                <a href="../controller/v02_aims_others_claim_hr_close_claim_exec.php?id=<? echo $claim['id'];?>&nostaff=<? echo $nostaff;?>" style="font-weight: bold; margin-bottom: 8px"
                                                   class="btn btn-block btn-success <? echo ($claim['claim_status'] == 'OPEN') ? '' : 'disabled'?>"
                                                   onclick="return confirm('Confirm Close the Claim Status?')" title="Close Claim Status">
                                                    CLOSED</a>
                                        <?
                                            } elseif ($claim['verify_status'] == '1' && $claim['review_status'] == '1' && $claim['claim_status'] == 'CLOSED') {
                                                ?>
                                                <a href="../controller/v02_aims_others_claim_hr_open_claim_exec.php?id=<? echo $claim['id'];?>" style="font-weight: bold; margin-bottom: 8px"
                                                   class="btn btn-block btn-success <? echo ($claim['claim_status'] == 'CLOSED') ? '' : 'disabled'?>"
                                                   onclick="return confirm('Confirm to change the Claim Status?')" title="Open Claim Status">
                                                    OPEN</a>
                                                <?
                                            } else {
                                                ?>
                                                <!--Not display <a>-->
                                                <?
                                            }
                                        ?>
                                    </td>
                                </tr>
                                <? $total_cost+=$claim['total_claim'];
                            } ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td style="background-color:white;" colspan="3">
                                    <b>VERIFIED BY : <? echo $verified_name ?></b>
                                </td>

                                <td class="text-center" style="background-color:white;">
                                    <b>Total : <? echo '<br> RM '.number_format($total_cost, 2) ?></b>
                                </td>
                                <td style="background-color:white;" class="text-right" colspan="5">
                                    <?
                                    if ($claim_status == 'CLOSED'){

                                    } else {
                                        ?>
                                        <input type="checkbox" id="select_all"/>&nbsp;
                                        <label for="select_all" style="font-size: medium;margin-right: 8px"> Select All</label>
                                        <input type="submit" name="verification_status" class="btn btn-success" id="activate" value="REVIEWED" <? if ($verification=='REVIEWED') echo 'disabled' ?>/>
                                        <input type="submit" name="verification_status" class="btn btn-danger" id="activate" value="DISAPPROVED" <? if ($verification=='DISAPPROVED') echo 'disabled' ?>/>
                                        <input type="hidden" name="nostaff" value="<? echo $nostaff?>">
                                        <?
                                    }
                                    ?>
                                    <!--<input type="checkbox" id="select_all"/>&nbsp;
                                    <label for="select_all" style="font-size: medium;margin-right: 8px"> Select All</label>
                                    <input type="submit" name="verification_status" class="btn btn-success" id="activate" value="REVIEWED" <?/* if ($verification=='YES') echo 'disabled' */?>/>
                                    <input type="submit" name="verification_status" class="btn btn-danger" id="activate" value="DISAPPROVED" <?/* if ($verification=='NO') echo 'disabled' */?>/>
                                    <input type="hidden" name="nostaff" value="<?/* echo $nostaff*/?>">-->
                                </td>
                            </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <!-- /.panel-body -->
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->

<!-- Modal View Detail -->
<div class="modal fade" id="viewDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width: 90%;margin-top: 50px;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="exampleModalLongTitle" style="font-size: 120%">View Details</span>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body" id="modal-view">
                <!--Modal Script-->
                <script>
                    /*Modal View Details*/
                    $('#viewDetail').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');
                        $.ajax({
                            type:'POST',
                            url:'v02_aims_other_claim_list_modal.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#modal-view').html(html);
                            }
                        });
                    });
                </script>
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Remarks -->
<div class="modal fade" id="viewAddRemarks" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle2" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width: 90%;margin-top: 50px;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="exampleModalLongTitle2" style="font-size: 120%">ADD REMARKS</span>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body" id="modal-addRemarks">
                <!--Modal Script-->
                <script>
                    /*Modal View Details*/
                    $('#viewAddRemarks').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');
                        $.ajax({
                            type:'POST',
                            url:'v02_aims_other_claim_remarks_modal.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#modal-addRemarks').html(html);
                            }
                        });
                    });
                </script>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" id="demo2" style="text-align: center">
                <script type="text/javascript">
                    $('#myModal2').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');

                        $.ajax({
                            type:'POST',
                            url:'v02_aims_others_claim_attachment.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#demo2').html(html);
                            }
                        });
                    });
                </script>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" style="background-color: #7d7d7d; color: #FFFFFF" class="btn btn-block btn-default btn-rounded btn-md ml-4"
                        data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<? include ('../global/footer.php'); ?>
<script>
    // Delete row on delete button click

    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            columnDefs: [
                { targets: -1, orderable: false }
            ]
        });
    });

    function un_check(){
        for (var i = 0; i < document.frmactive.elements.length; i++) {
            var e = document.frmactive.elements[i];
            if ((e.name != 'allbox') && (e.type == 'checkbox')) {
                e.checked = document.frmactive.allbox.checked;
            }
        }
    }

    $(document).ready(function(){
        $('#select_all').on('click',function(){
            if(this.checked){
                $('.checkbox').each(function(){
                    this.checked = true;
                });
            }else{
                $('.checkbox').each(function(){
                    this.checked = false;
                });
            }
        });

        $('.checkbox').on('click',function(){
            if($('.checkbox:checked').length == $('.checkbox').length){
                $('#select_all').prop('checked',true);
            }else{
                $('#select_all').prop('checked',false);
            }
        });
    });

</script>
</body>
</html>




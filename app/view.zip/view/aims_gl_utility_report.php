<?php

include ('../controller/auth.php');

require "../model/aims_gl_function.php";
require "../model/lookup.php";


$month=$_GET['month'];
if(!isset($month)){
  $month=$date_year;
}
$sys = getSys(1)->fetch_assoc();
?>

<!DOCTYPE html>
<title>iOffice::Sistem Pengurusan Pejabat Bersepadu</title>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <? require "../global/header.php"; ?>
  <style>

    body {      
      font-family: Times New Roman;
      font-size: 15px;
      color: black;
      background-color: white;
      margin-left: 20px;
      margin-right: 20px;
  }



  table.reservation{
      width: 100%;
  }

  table.one{
      width:100%;

  }
  table.sign{
      width:100%;

  }

  .reservation input,select {
      width: 60%;
      border-top-style: hidden;
      border-right-style: hidden;
      border-left-style: hidden;
      border-bottom-style: hidden;
      background-color: none;
  }

  .sign input {
      border-top-style: hidden;
      border-right-style: hidden;
      border-left-style: hidden;
      border-bottom-style: groove;
      background-color: none;
  }

  .box{
      width: 100%;
  }

  h3{
      color: black;
      font-size: 28px;
  }

  .reservation{
      font-size: 16px;
  }

  @media print {
      #btn-Preview-Image {
        display: none;
    }
    #month{
        display: none;
    }
    #label{
        display: none;
    }
}
</style>



</head>

<body>
  <br>

  <div class="box">

    <div class="row" align="center">
      <h4><center><b>REPORT UTILITY GLOBAL LOUNGE</b></center></h4>
      <div class="month">
        <b><p align="center"> <?
        if ($month == 'JANUARY') {
            echo "JANUARY";
        }
        else if ($month == 'FEBRUARY') {
            echo "FEBRUARY";
        }
        else if ($month == 'MARCH') {
            echo "MARCH";
        }
        else if ($month == 'APRIL') {
            echo "APRIL";
        }
        else if ($month == 'MAY') {
            echo "MAY";
        }
        else if ($month == 'JUNE') {
            echo "JUNE";
        }
        else if ($month == 'JULY') {
            echo "JULY";
        }
        else if ($month == 'AUGUST') {
            echo "AUGUST";
        }
        else if ($month == 'SEPTEMBER') {
            echo "SEPTEMBER";
        }
        else if ($month == 'OCTOBER') {
            echo "OCTOBER";
        }
        else if ($month == 'NOVEMBER') {
            echo "NOVEMBER";
        }
        else if ($month == 'DECEMBER') {
            echo "DECEMBER";
        }
        else {
            echo "-";
        }?> <?php echo date("Y"); ?></p></b>
    </div>
</div>

<div class="reservation">
    <table border="0">
        <tr>
            <td><label id="label" class="control-label">MONTH:</label></td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td><select  required class="form-control" name="month" id="month" value="<?echo $month?>">
              <option value="">-- Choose Month --</option>
              <? echo getDropDownMonthUtility($month) ;?>
          </select>
      </td>
  </tr>
</table>
</div>

<table class="one" border="1">
  <tr><br>
    <th style="text-align:center;">NO</th>
    <th style="text-align:center;">DESCRIPTION</th>
    <th style="text-align:center;">BLOCK B NO 20</th>
    <th style="text-align:center;">BLOCK B NO 21</th>
    <th style="text-align:center;">TOTAL (RM)</th>
</tr>

<?
$i=1;
$rr = getUtilityByMonth($month);
while($list_rr = $rr->fetch_assoc()) {
    ?>

    <tr>
      <td class="text-center"><? echo $i; ?></td>
      <td><? echo $list_rr['utility_desc_id']; ?></td>
      <td class="text-center"><? echo $list_rr['no_20'] ;?></td>
      <td class="text-center"><? echo $list_rr['no_21'] ;?></td>
      <td class="text-center"><? echo $list_rr['total'] ;?></td>
  </tr>

  <? $all += (float)$list_rr['total'];?>

  <?php $i++; } ?>
  <tr>
    <th colspan="4"></th>
    <th class="text-center"><?echo 'RM ' .number_format($all, 2)?></th>
</tr>

</table>


<br>
<br>
<br>

<div style="text-align:center;">
    <br><input id="btn-Preview-Image" type="button" onclick="window.print()" value="Cetak"/>
    <br><br>
</div>
</div> <!-- box -->

<!-- Modal -->

<script>
 $(document).ready(function() {
  $('#dataTables-example').DataTable({
    responsive: true
});

});

 $(document).ready(function() {
  $("#month").change(function(){

    var selected_month=$(this).val();
    reloadMonth(selected_month);
});

});

 function reloadMonth(month){
                //console.log(cawangan);
                location.href = "aims_gl_utility_report.php?month="+month;
            }

        </script>


    </body>

    </html>
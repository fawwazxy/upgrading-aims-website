<?php

include ('../controller/auth.php');
require "../model/aims_carReserve_function.php";
require "../model/lookup.php";


$id = $_POST['id'];
?>

<style>
.thead-dark{
	background-color:black;
	color:white;
}
</style>

<table class="table">
  <thead class="thead-dark">
    <tr>
	  <th  width="5%" scope="col">No</th>
      <th scope="col">Name</th>
      <th scope="col">Designation</th>
      <th scope="col">Department</th>
    </tr>
  </thead>
  <tbody>
   
  <?
         $car= getcarpassengerById2($id);
		 $i=1;
         while($car_info = $car->fetch_assoc() ) {
                                ?>
	  <tr>	
		<td><? echo $i++;?></td>
      <td><? echo $car_info['name_passenger'];?></td>
      <td><? echo $car_info['jawatan'];?></td>
      <td><? echo $car_info['description'];?></td>
    </tr>
		 <?}?>
  </tbody>
</table>


<script>
    function convertToUppercase(el) {
        if(!el || !el.value) return;
        el.value = el.value.toUpperCase();
    }
</script>

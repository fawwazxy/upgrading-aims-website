<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
//$no_staff = $_GET['no_staff'];

$id = $_GET['id'];
$suggested_month_claim = strtoupper(date('Y-m'));
$res = v02getDetailClaim($_GET['id'])->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

    <style>
        .claim-text{
            background-color:WHITE;
            padding:8px;
            border-radius: 5px;
            font-weight:bold;
        }
    </style>

</head>

<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

        <!-- /.navbar-header -->
        <? include ('../global/menu_top.php'); ?>

        <!-- /.navbar-top-links -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
            <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
    </nav>
    <? $staff = getStaffForm($no_staff) -> fetch_assoc(); ?>

        <!--Hidden Input-->
        <input type="hidden" required="" id="no_staff" name="no_staff" value="<?php echo $no_staff?>" />
<!--        <input type="hidden" name="id" value="--><?php //echo $_GET['id'];?><!--">-->
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> UPDATE
                        <a href="aims_others_claim_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                            <i class="fa fa-rotate-left" style="margin-right: 4px"></i>
                            Switch to Version 01
                        </a>
                        <a href="v02_aims_others_claim_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                            <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                            Back to list
                        </a>
                </div>
            </div>
            <div class="row" >
                <div class="col-lg-12">
                    <div class="panel panel-default"><!-- /.panel-heading --><br>
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <form method="post" action="../controller/v02_aims_others_claim_update_exec.php">
                                    <div class="form-group row" align="left">
                                        <div class="col-md-12"><p class="claim-text" style="background-color: orange">UPDATE FORM DETAILS</p></div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Job No <span class="small">(optional)</span>:</label><br>
                                                <input class="form-control" type="text" name="jobno" id="jobno" placeholder="<? echo (empty($res['job_no'])) ? 'No Job Number' : $res['job_no']?>" value="<? echo $res['job_no'] ?>">
                                                <input type="hidden" name="id" id="id" value="<? echo $id;?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Date: <font color="red">**</font>&nbsp;</label><br>
                                                <input type="date" class="form-control" placeholder="" id="date_claim" name="date_claim" value="<? echo $res['date_purchase'] ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div id="head2">
                                                    <label>Claim For The Month Ended: <font color="red">**</font>&nbsp</label><br>
                                                    <select class="form-control" id='month_claim' name="month_claim" onchange="show_month()" value="" required>
                                                        <? echo v02getDropDownMonthClaimSelected($suggested_month_claim,$res['month_claim']) ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Details Description&nbsp;:</label>
                                                <textarea name="description" id="description" class="form-control" rows="5"><? echo strip_tags($res['description']) ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div align="right">
                                            <button href="" type="submit" class="btn btn-primary" id="btnSubmit" onclick="return confirm('Confirm update form detail?')">Submit</button>
                                        </div>
                                        <br>
                                    </div>
                                    <div class="modal-footer"></div>
                                </form>

                                <div class="form-group row">
                                    <div class="col-md-12"><p class="claim-text" style="background-color: orange">UPDATE COST CENTRE</p></div>
                                    <div class="col-md-12">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th colspan="4">Company : <? echo v02CompanyName($res['id'])?>
                                            </tr>
                                            <tr style="background-color: lightgrey">
                                                <th class="text-center">Cost Centre</th>
                                                <th class="text-center">Type Claim</th>
                                                <th class="text-right">Total</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <? $type_claim = v02getTypeClaimByClaimId($id);
                                            while ($type = $type_claim->fetch_assoc()){
                                                $desc = getTypeClaimDescription($type['company_cc_id'])->fetch_assoc();
                                                ?>

                                                <tr class="text-center">
                                                    <td><? echo $desc['cost_centre'];?></td>
                                                    <td><? echo $desc['description'];?></td>
                                                    <td class="text-right">RM <?php echo $type['total']?></td>
                                                    <td>
                                                        <!--                                                        <a href="../view/v02_update_aims_others_claim.php?id=--><?// echo $res['id']; ?><!--" class="" title="Update Detail">-->
                                                        <!--                                                            <i class="fa fa-edit"></i></a>-->
                                                        <a href="#viewModal"
                                                           id="clicktoView" class="" data-toggle="modal" data-id="<? echo $type['id'];?>" data-get="<? echo $id?>"
                                                           title=""><i class="fa fa-edit"></i></a>

                                                        <a href="../controller/v02_aims_others_claim_cost_centre_delete_exec.php?id=<? echo $type['id'] ?>&getid=<? echo $id;?>" class="text-danger"
                                                           title="Delete Selected Cost Centre"><i class="fa fa-remove"></i></a>
                                                    </td>
                                                </tr>

                                            <? } ?>
                                            </tbody>
                                            <tfoot align="right">
                                            <tr>
                                                <td colspan="3">RM <? echo $res['total_claim'];?></td>
                                                <td></td>
                                            </tr>
                                            </tfoot>

                                        </table>
                                    </div>
                                </div>

                                <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" style="max-width: 50%;margin-top: 50px;" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <span class="modal-title" id="exampleModalLongTitle" style="font-size: 120%">UPDATE COST CENTRE</span>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body" id="modal-body">

                                                <!--Modal Script-->
                                                <script>
                                                    /*Modal View Details*/
                                                    $('#viewModal').on('show.bs.modal', function (e) {
                                                        var rowid = $(e.relatedTarget).data('id');
                                                        var getid = $(e.relatedTarget).data('get');
                                                        console.log(rowid);
                                                        console.log(getid);
                                                        $.ajax({
                                                            type:'POST',
                                                            url:'v02_aims_other_claim_list_cc_modal.php',
                                                            data:{id:rowid,get_id:getid},
                                                            success:function(html){
                                                                $('#modal-body').html(html);
                                                            }
                                                        });
                                                    });
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>
</div><!-- /#page-wrapper -->
</div><!-- /#wrapper -->
<? include ('../global/footer.php'); ?>
<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script type="text/javascript">
    function convertToUppercase(el) {
        if(!el || !el.value) return;
        el.value = el.value.toUpperCase();
    }
</script>
</body>
</html>
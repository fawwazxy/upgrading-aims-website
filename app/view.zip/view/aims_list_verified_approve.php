<?php

	include ('../controller/auth.php');

	require "../model/aims_inout_function.php";

	$id = $_GET['id'];
	$passwordinfo = getaims_verified_approvebyId($id)->fetch_assoc();
?>
<?

	$no_staff = $_SESSION['SESS_NO_STAFF'];
	$department = $_SESSION['SESS_DEPARTMENT'];
	$sys = getSys(1)-> fetch_assoc();
	$verified_name = $_SESSION['SESS_NAME'];
	$verified = $_GET['verified'];
	if (!isset($verified) && $verified == '') {
        $verified = 'PENDING';
    }
?>

 
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>


<script language="JavaScript" type="text/javascript">

</script>
<script type="text/javascript">
<!--
function un_check(){
for (var i = 0; i < document.frmactive.elements.length; i++) {
var e = document.frmactive.elements[i];
if ((e.name != 'allbox') && (e.type == 'checkbox')) {
e.checked = document.frmactive.allbox.checked;
}}}
//-->
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});
</script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
			<? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

			<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
							<center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
						</li-->

						<? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
		<? 
					?>
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"> IN OUT VERIFICATION </h1>
			</div>
        </div>
                 <div class="row">
				<div class="panel-heading" align="right">
				
				<?
					$staff = getStaffInformation($no_staff) -> fetch_assoc();
				?>
				
			<div class="panel-heading" align="right">
					
            </div>
 
        </div>
                <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <label>Verified</label>&nbsp;&nbsp;&nbsp;
							<a href="aims_list_verified_approve.php?verified=PENDING">New</a> &nbsp;|&nbsp;
                            <a href="aims_list_verified_approve.php?verified=APPROVE">Approved</a> &nbsp;|&nbsp;
                            <a href="aims_list_verified_approve.php?verified=DISAPPROVE">Disapproved</a> &nbsp;|&nbsp;
                            
                        </div>
                        <!-- /.panel-heading -->
                       <div class="panel-body">
                           
                           <input type="checkbox" id="select_all" /><font size='4'> Select All</font></li>
						
						<? $data=getCheckboxVerify($id,$_SESSION['SESS_NAME'])?>
						<form name="frmactive" method="post" action="">
					<table border="0">
					<tr>
					<td colspan="5"><input class="btn btn-success" name="activate" type="submit" id="activate" value="Verify" />
									<input class="btn btn-danger" name="deactivate" type="submit" id="deactivate" value="Disapprove" />
					</td>
					</table><br>
					   
                            <input name="id" type="hidden" class="input-short" value="<? echo $id;?>" />
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
									
										<th width="5%">No.</th>
                                        <th width="30%">Staff Info</th>   
                                        <th width="30%">In Out Info</th>
                                        <th width="20%">Verified</th>
										<th>Action</th>
										
                                    </tr>
                                </thead>
								<tbody>
								
								<?
								if($_SESSION['SESS_DEPARTMENT_SUB'] == 'MOORING-GANG'){
								        $password = getInOutSpecialMessage();
								    }
								else{
                                    if($verified == 'PENDING') {
                                        $password= getaims_verified_approvelisitbaharu($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
                                    }
                                    else if($verified == 'APPROVE') {
                                        $password= getaims_verified_approvelisitlulus($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
                                    }
                                    else {
                                        $password= getaims_verified_approvelisittidaklulus($_SESSION['SESS_DEPARTMENT_SUB'],$_SESSION['SESS_NAME']);
                                    }       
								} 
									$i= 1;
									while($row_data = $password->fetch_assoc())  {   
								?>
								
									<tr class="odd gradeX">
										<td><?php echo $i; ?>
										<align="center">
										<input name="checkbox[]" type="checkbox" class="checkbox" id="checkbox[]" value="<?php echo $row_data['id']; ?>" >
										</td>
										
										<td>
										    <label class="control-label">Nama :<?php echo $row_data['name']; ?></label><br>
											<label class="control-label">Ic :<?php echo $row_data['noic']; ?></label><br>
										    <label class="control-label">Department :<?php echo $row_data['department_sub']; ?></label><br>
											<label class="control-label">Company :<?php echo $row_data['department_id']; ?></label>
										</td>
										
										 <td>
								            <label class="control-label">Date :<?php echo $row_data['date_mohon']; ?></label><br>
											<label class="control-label">Description :<?php echo $row_data['description']; ?></label><br>
										    <label class="control-label">Time Out :<?php echo $row_data['time_out']; ?></label><br>
											<label class="control-label">Time In :<?php echo $row_data['time_in']; ?></label>
								            
								        </td>
										
										 <td>
								            <?if($row_data['verified'] == 'PENDING' ) {
                                                        echo '<b><font color="blue">'.'PENDING'.'</font></b>';}
                                                    else if($row_data['verified'] == 'APPROVE') {
                                                        echo '<b><font color="green">'.'APPROVE'.'</font></b>';}
                                                    else if($row_data['verified'] == 'DISAPPROVE') {
                                                        echo '<b><font color="red">'.'DISAPPROVE'.'</font></b>';}
													
								           ?><br><br>
											<? echo $row_data['verified_name'];?>
								        </td>
					
										 <td>
										 
										 <?
                                            if (in_array($row_data['verified'], ['PENDING', 'DISAPPROVE'])) { ?>
                                                   <a href="../controller/hantar_buttonverified_exec.php?aims_inout_id=<? echo $row_data['id'];?>&verified_name=<?echo $verified_name;?>" class="btn btn-success" onclick="return Confirm()">VERIFY</a>
												   
										<?  }
                                            if (in_array($row_data['verified'], ['PENDING', 'APPROVE'])) { ?>
												   <a style="margin-top: 8px" href="../controller/hantar_buttonverified1_exec.php?aims_inout_id=<? echo $row_data['id'];?>&verified_name=<?echo $verified_name;?>" class="btn btn-danger" onclick="return Confirm()">DISAPPROVE</a>
										<?  } 
										
										if ($row_data['images'] != '') { ?>
								            <!--<span title="10/08/2022: Currently in Maintenance">-->
								                <a href="#myModal3" data-toggle="modal" data-id="<? echo $row_data['id'];?>" style="margin-top: 8px" class="btn btn-info">SHOW ATTACHMENT</a>
								                <!--</span>-->
										<? } ?>
								        </td>
									</tr>
											<?php $i++; } ?>
								</tbody>

							</table>

                        </div>

                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
           

                <!-- /.row -->
            <!-- /.container-fluid -->
        </div>

        <!-- /#page-wrapper -->

    </div>

<!--Modal for Show Attachment    -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog">
        <!-- <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div> -->
        <div class="modal-body" id="demo3">
        <script type="text/javascript">
          $('#myModal3').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'POST',
              url:'aims_inout_lampiran.php',
              data:{id:rowid},
              success:function(html){
                $('#demo3').html(html);
              }
            });
          });
        </script>
        </div>   
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
  
	<? include ('../global/footer.php'); ?>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
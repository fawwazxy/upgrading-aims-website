<?php

	include ('../controller/auth.php');

	require "../model/aims_gl_function.php";

         
		$id = $_GET['id'];
        $data = getCLientCompanyById($id)->fetch_assoc(); 
 ?> 

                     
                      <form method="post" action="../controller/aims_gl_client_company_update_exec.php" >     
							<input id="id" name="id" type="hidden" value="<? echo $id?>"/>
                              
							  
                             
							<label><font color="red">** Maklumat Wajib Diisi.</font></label>
							<br>
							 
							 
								<div class="form-group"  align="left">
								  <label>CODE COMPANY<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="code_company" id="code_company" onkeyup="convertToUppercase(this)" value="<? echo $data['code_company'];?>" >
								</div>

								<div class="form-group"  align="left">
                                  <label>CLIENT COMPANY<font color="red">**</font>&nbsp;</label>
                                  <input class="form-control" placeholder=" " name="company_name" id="company_name" onkeyup="convertToUppercase(this)" value="<? echo $data['company_name'];?>" >
                                </div>

								<div class="form-group"  align="left">
  								<label>Status: <?php echo $data['status']; ?></label></br>
									<input type="radio" id="status" name="status" <?php if($data['status']=="1") {echo "checked";}?> value="1">Active	
									<input type="radio" id="status" name="status" <?php if($data['status']=="0") {echo "checked";}?> value="0">In Active
								</div> 



                             <div class="modal-footer">
                                   <button type="submit" class="btn btn-primary">Save</button>
                                  
                             </div>
         
					</form>
<script>

        function convertToUppercase(el){
            if(!el || !el.value) return;
            el.value = el.value.toUpperCase();
        }
    
    </script>
                      
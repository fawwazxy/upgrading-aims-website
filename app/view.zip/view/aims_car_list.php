<?php

include ('../controller/auth.php');

require "../model/aims_car_function.php";
require "../model/lookup.php";

?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body{
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: 'Poppins';
  
}

 body {
	 transition: background 0.3s;
	 gap: 20px;
}

:root {
  --secondary: linear-gradient(221deg, #8743ff, #4136f1 60%);
  --card: #eaf2ff;
  --text: #000;
}

h1{
  text-transform: uppercase;
  letter-spacing: 3px;
  color: rgba(0,0,0, 0.45);
}
 .cardx {	
	 height: 240px;
	 width: 190px;
	 background: var(--card);
	 border-radius: 20px;
	 padding: 10px;
	 font-family: sans-serif;
	 display: flex;
	 color: var(--text);
	 flex-direction: column;
	 align-items: flex-start;
	 transition: transform 0.3s, background 0.3s;
}
 .cardx:hover {
	 transform: scale(1.09);
}
 .cardx img {
	 width: 160px;
	 height: 90px;
	 border-radius: 14px;
	 object-fit: cover;
}
 .cardx__title {
	 color: var(--text);
	 margin-top: 10px;
	 font-size: 10px;
	 font-weight: 400;
	 transition: color 0.3s;
}
 .cardx__description {
	 margin-top: 5px;
	 display: block;
	 font-size: 15px;
	 opacity: 0.6;
	 transition: color 0.3s;
}
 .cardx__shop {
	 width: 100%;
	 margin-top: auto;
	 display: flex;
	 align-items: center;
	 justify-content: space-between;
}

.cardx .floating{
  width: auto;
  padding-left: 20%;
}

.floating-button0 {
  text-decoration-line: none;
  display: inline-block;
  width: 140px;
  height: 25px;
  line-height: 20px;
  border-radius: 50px;
  margin: 10px 20px;
  font-family: 'Montserrat', sans-serif;
  font-size: 10px;
  text-transform: uppercase;
  text-align: center;
  letter-spacing: 3px;
  color: #524f4e;
  background: white;
  box-shadow: 0 8px 15px rgba(0, 0, 0, .1);
  transition: .6s;
}
.floating-button0:hover {
  background: #e52ed6;
  box-shadow: 0 15px 20px rgba(229, 46, 189, 0.4);
  color: white;
  transform: translateY(-5px);
}

.responsive {
  padding: 15px;
  float: left;
  width: 20%;
}

@media only screen and (max-width: 750px) {
  .responsive {
    width: 49.99999%;
    margin: 15px;
  }
}

@media only screen and (max-width: 900px) {
  .responsive {
    width: 50%;
  }
}

@media only screen and (max-width: 1400px) {
  .responsive {
    width: 50%;
  }
}

.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
</style>

<style>
h6 {
  display: flex;
  flex-direction: row;
}
h6:before, h6:after{
  content: "";
  flex: 1 1;
  border-bottom: 1px solid;
  margin: auto;
}
h6:before {
  margin-right: 5px
}
h6:after {
  margin-left: 5px
}

.boxes {
  background-color: black;
  width: 100%;
  padding: 10px;
  color:white;
  text-align:center;
}
    </style>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
		
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Vehicle List</h1>
                </div>
            </div>
			
			<table width="100%" border="1">
							<thead>
								<tr>
									<th width="30%" style="color:white" bgcolor="black"><center>Total Vehicle</center></th>
									<th width="20%" style="color:white" bgcolor="black"><center>Vehicle In Use</center></th>
									<th width="20%" style="color:white" bgcolor="black"><center>Vehicle available</center></th>
									<th width="30%" style="color:white" bgcolor="black"><center>Approve need by admin</center></th>
								</tr>
							</thead>
							<tbody>
								<tr>
								   <td><font size='6'><center><? echo getTotalCar(); ?></center></font></td>
								   <td><font size='6'><center><? echo getTotalcarByStatus(0);?></center></td>
								   <td><font size='6'><center><? echo getTotalcarByStatus1(1);?></center></td>
								   <td><font size='6'><center><? echo getTotalcarSubmitted(0);?></center></td>
								</tr>
							</tbody>
			</table>
			
<? 
						$flagScreen="tab_1";
						include ('../global/menu_car_admin.php'); 
?>				
			
            <div class="form-group" align="right">
            </div>
            
            <div class="form-group" align="right">
               <button class="btn btn-primary" data-toggle="modal"  data-target="#myModal">Add New</button>
            </div>
             
            <div class="row">
                <div class="col-lg-12">
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <?
                            $car = getcarList();
                            $i=1;
                            while($list_car = $car->fetch_assoc()) {
                        ?>
					<div class="responsive">
                    <div class="cardx">
					    <?if($list_car['document_type'] == 'jpg' || $list_car['document_type'] == 'jpeg' || $list_car['document_type'] == 'png' || $list_car['document_type'] == 'gif') {
                            echo '<img src="data:image/jpeg;base64,'.base64_encode( $list_car['document'] ).'"/><br>';}
                        ?>
					  <h4 class="cardx__title"><b><? echo $list_car['car_model'] ?></b></h4>
					  <div class="cardx__shop">
					  <div class="float">
							<?php echo "<a href='#myModal1' data-toggle='modal' data-id=".$list_car['id']." class='floating-button0'>Edit</a>";?>
							<?php echo "<a href='#myModal2' data-toggle='modal' data-id=".$list_car['id']." class='floating-button0'>Info</a>";?>
					  </div>
					  </div>
					</div>
					</div>
                            <?}?>
                             
                    
					</div>
               
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>
<!-- 
        <!-- /#page-wrapper -->

    </div></div>
    <!-- /#wrapper -->
	
	<!-- Modal -->
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                
                <div class="modal-content">
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                
                <div class="modal-body">
                
                <form method="post" action="../controller/aims_car_add_exec.php" enctype="multipart/form-data">
                         <div class="form-group" align="left">
                              
                             
                            <label><font color="red">** Required.</font></label>
                            <br>
							
								<div class="form-group row" align="left">
								<div class="col-xs-8">
								<label>Attachment&nbsp;<font color="red"><i>(Only pdf/jpeg/jpg/png/gif format file are allowed)</i></font></label>
								<input type="hidden" name="MAX_FILE_SIZE" value="2000000">
								<input type="file" accept=".jpg,.jpeg,.png,.gif,.pdf" name="document" id="document">
								</div>
								</div>
							
                               <h6>VEHICLE PROFILE</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>MODEL<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_model" value="" >
								</div>							  
							  
							    <div class="col-xs-6">
								  <label>OWNER<font color="red">**</font>&nbsp;</label>
								  <select  required class="form-control" name="car_owner" id="car_owner">
									<option value="">-- Choose Owner --</option>
									<? echo getDropDownCompany2("");?>
								  </select>
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-4">
								  <label>TYPE OF CAR<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_type" value="" >
								</div>
								<div class="col-xs-4">
								  <label>PLATE NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_plate_no" value="" >
								</div>
								<div class="col-xs-4">
								 <label>COLOR<font color="red">**</font>&nbsp;</label>
								 <input class="form-control" placeholder=" " name="color" value="" > 
								</div>
								</div>
								
								<h6>PERSON IN CHARGE</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
                                  <label>PIC 1<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" list="pic1" id="car_pic" name="car_pic" value=""/>
								<datalist  id="pic1">
									<option value="">-- Choose Name --</option>
									<? echo getdropdownstaff("")?>
								</datalist>
                                </div>
								<div class="col-xs-6">
                                  <label>PIC 2<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" list="pic3" id="car_pic2" name="car_pic2" value=""/>
								<datalist  id="pic3">
									<option value="">-- Choose Name --</option>
									<? echo getdropdownstaff("")?>
								</datalist>
                                </div>
								</div>
								
								<h6>VEHICLE INFORMATION</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>ENGINE NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="engine_no" value="" >
								</div>
								
								<div class="col-xs-6">
								  <label>CHASSIS NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="chassis_no" value="" >
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-3">
								  <label>RECEIPT COST<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="cost_receipt" value="" >
								</div>
								<div class="col-xs-3">
								  <label>RECEIPT DATE<font color="red">**</font>&nbsp;</label>
								  <input type="date" class="form-control" placeholder=" " name="date_receipt" value="" >
								</div>
								<div class="col-xs-6">
								  <label>SUPPLIERS<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="suppliers" value="" >
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>HIRE ACCOUNT NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="hire_account_no" value="" >
								</div>
								
								<div class="col-xs-6">
								  <label>ACCOUNT NAME<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="name_account" value="" >
								</div>
								</div>
								
								<h6>SERVICE INFORMATION</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>LAST SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="last_service" value="">
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="next_service" value="">
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>CURRENT MILEAGE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="current_milage" value="">
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT MILEAGE SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="next_mileage_service" value="">
								</div>
								</div>
								
								<h6>ROADTAX</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED (ROADTAX)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_rtx" value="" >
								</div>
								
								<div class="col-xs-6">
								  <label>VALUE (ROADTAX)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_rtx" value="" >
								</div>
								</div>
								
								<h6>INSURANCE PASSENGER</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_ins" value="">
								</div>
								<div class="col-xs-6">
								  <label>TYPE OF INSURANCE<font color="red">**</font>&nbsp;</label>
								     <select id="type_ins" name="type_ins" class="form-control">
									  <option value="PLATINUM">PLATINUM</option>
									  <option value="PREMIUM">PREMIMUM</option>
									  <option value="GOLD">GOLD</option>
									</select> 
								</div>
								
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>VALUE (INSURANCE)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_ins" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="">
								</div>
								</div>
								
								<h6>INSURANCE PRIVATE</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_priv" value="">
								</div>
								<div class="col-xs-6">
								  <label>VALUE (INSURANCE)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_priv" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="">
								</div>
								
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>SUM COVERED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="sum_priv" value="<? echo $car_info['sum_priv'];?>">
								</div>
								</div>
                  
                             <div class="modal-footer">
                                   <button type="submit" class="btn btn-primary">Save</button>
                                   <button type="reset" class="btn btn-info">Reset</button>
                             </div>
							 </div>
							 </form>
							 </div>
							 </div>
							 </div>
							 </div>
							 

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
	  <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" >&times;</button>
        </div>
        <div class="modal-body" id="demo">
        <script type="text/javascript">
          $('#myModal1').on('show.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'GET',
              url:'aims_car_update.php',
              data:{id:id},
              success:function(html){
                $('#demo').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
</div>
</div>

    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
	  <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" >&times;</button>
        </div>
        <div class="modal-body" id="demo2">
        <script type="text/javascript">
          $('#myModal2').on('show.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'GET',
              url:'aims_car_info.php',
              data:{id:id},
              success:function(html){
                $('#demo2').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
</div>
</div>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });
        });

        
    
    </script>

</body>

</html>
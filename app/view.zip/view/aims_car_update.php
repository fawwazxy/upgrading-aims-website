<?php

	include ('../controller/auth.php');
	require "../model/aims_car_function.php";
	require "../model/lookup.php";
	
		 $id = $_GET['id'];
		 $car_info = getcarById($id)->fetch_assoc();
		 $car_milage = getmilagecarById($id)->fetch_assoc();
 ?> 

                     
                      <form method="post" action="../controller/aims_car_update_exec.php" enctype="multipart/form-data">     

							<label><font color="red">** Required Information.</font></label>
							<br>
							        
							  <input id="updated_by" name="updated_by" type="hidden" value="<?php echo $_SESSION['SESS_NAME'] ?>"/>
							  <input type="hidden" name="id" value="<?php echo $car_info['id']; ?>">
							  
							  <div class="form-group row" align="center">
								<br>
								<?if($car_info['document_type'] == 'jpg' || $car_info['document_type'] == 'jpeg' || $car_info['document_type'] == 'png' || $car_info['document_type'] == 'gif') {
                                                echo '<img width="200" height="100" src="data:image/jpeg;base64,'.base64_encode( $car_info['document'] ).'"/><br>';}
                                         else if($car_info['document_type'] == 'pdf') {
                                                echo '<object width="200" height="100" data="data:application/pdf;base64,'.base64_encode( $car_info['document'] ).'"/><br>'.'" type="application/pdf"></object>';}
                                ?>
								<br><input type="hidden" name="MAX_FILE_SIZE" value="2000000">
								<br><input type="file" accept=".jpg,.jpeg,.png,.gif,.pdf" name="document" id="document">
								<br>
								</div>
							  
							    <h6>VEHICLE PROFILE</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>MODEL<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_model" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['car_model'];?>" >
								</div>							  
							  
							    <div class="col-xs-6">
								  <label>OWNER<font color="red">**</font>&nbsp;</label>
								  <select  required class="form-control" name="car_owner" id="car_owner">
									<option value="">-- Choose Owner --</option>
									<? echo getDropDownCompany2($car_info['car_owner']);?>
								  </select>
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-4">
								  <label>TYPE OF CAR<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_type" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['car_type'];?>" >
								</div>
								<div class="col-xs-4">
								  <label>PLATE NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="car_plate_no" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['car_plate_no'];?>" >
								</div>
								<div class="col-xs-4">
								 <label>COLOR<font color="red">**</font>&nbsp;</label>
								 <input class="form-control" placeholder=" " name="color" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['color'];?>" > 
								</div>
								</div>
								
								<h6>PERSON IN CHARGE</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
                                  <label>PIC 1<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" list="pic1" id="car_pic" name="car_pic" value="<? echo $car_info['car_pic'];?>"/>
								<datalist  id="pic1">
									<option value="">-- Choose Name --</option>
									<? echo getdropdownstaff($car_info['car_pic'])?>
								</datalist>
                                </div>
								<div class="col-xs-6">
                                  <label>PIC 2<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" list="pic3" id="car_pic2" name="car_pic2" value="<? echo $car_info['car_pic2'];?>"/>
								<datalist  id="pic3">
									<option value="">-- Choose Name --</option>
									<? echo getdropdownstaff($car_info['car_pic2'])?>
								</datalist>
                                </div>
								</div>
								
								<h6>VEHICLE INFORMATION</h6>
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>ENGINE NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="engine_no" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['engine_no'];?>" >
								</div>
								
								<div class="col-xs-6">
								  <label>CHASSIS NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="chassis_no" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['chassis_no'];?>" >
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-3">
								  <label>VALUE OF VEHICLE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="cost_receipt" value="<? echo $car_info['cost_receipt'];?>" >
								</div>
								<div class="col-xs-3">
								  <label>PURCHASING DATE<font color="red">**</font>&nbsp;</label>
								  <input type="date" class="form-control" placeholder=" " name="date_receipt" value="<? echo $car_info['date_receipt'];?>" >
								</div>
								<div class="col-xs-6">
								  <label>SUPPLIERS<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="suppliers" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['suppliers'];?>" >
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>HIRE PURCHASE NO</label>
								  <input class="form-control" placeholder=" " name="hire_account_no" value="<? echo $car_info['hire_account_no'];?>" >
								</div>
								
								<div class="col-xs-6">
								  <label>ACCOUNT NAME</label>
								  <input class="form-control" placeholder=" " name="name_account" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['name_account'];?>" >
								</div>
								</div>
								
								<h6>SERVICE INFORMATION</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>LAST SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="last_service" value="<? echo $car_info['last_service'];?>" >
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="next_service" value="<? echo $car_info['next_service'];?>" >
								</div>
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>CURRENT MILEAGE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="current_milage" value="<? echo $car_milage['return_milage'];?>" >
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT MILEAGE SERVICE<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="next_mileage" value="<? echo $car_info['next_mileage'];?>" >
								</div>
								</div>
								
								<h6>ROADTAX</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED (ROADTAX)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_rtx" value="<? echo $car_info['date_ex_rtx'];?>" >
								</div>
								
								<div class="col-xs-6">
								  <label>VALUE (ROADTAX)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_rtx" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['value_rtx'];?>" >
								</div>
								</div>
								
								<h6>INSURANCE PASSENGER</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_ins" value="<? echo $car_info['date_ex_ins'];?>">
								</div>
								<div class="col-xs-6">
								  <label>TYPE OF INSURANCE<font color="red">**</font>&nbsp;</label>
								    <select id="type_ins" name="type_ins" class="form-control" value="">
									  <option value="PLATINUM" <? if ($car_info['type_ins'] == 'PLATINUM') echo 'selected'; ?>>PLATINUM</option> 
									  <option value="PREMIUM" <? if ($car_info['type_ins'] == 'PREMIUM') echo 'selected'; ?>>PREMIUM</option> 
									  <option value="GOLD" <? if ($car_info['type_ins'] == 'GOLD') echo 'selected'; ?>>GOLD</option> 
									</select>
								</div>
								
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>VALUE (INSURANCE)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_ins" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['value_ins'];?>">
								</div>
								</div>
								
								<h6>INSURANCE PRIVATE</h6>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>DATE EXPIRED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="date" name="date_ex_priv" value="<? echo $car_info['date_ex_priv'];?>">
								</div>
								<div class="col-xs-6">
								  <label>VALUE (INSURANCE)<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="value_priv" style="text-transform:uppercase" onkeyup="convertToUppercase(this)" value="<? echo $car_info['value_priv'];?>">
								</div>
								
								</div>
								
								<div class="form-group row" align="left">
								<div class="col-xs-6">
								  <label>SUM COVERED<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" type="text" name="sum_priv" value="<? echo $car_info['sum_priv'];?>">
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-12">
								   <button type="submit" class="btn btn-primary">Save</button>
								</div>
								</div>
                                
         
         </form>
        
		<script>
				function convertToUppercase(el) {
					if(!el || !el.value) return;
					el.value = el.value.toUpperCase();
				}
			</script>
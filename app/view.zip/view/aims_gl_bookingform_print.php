<?php

include ('../controller/auth.php');

require "../model/aims_gl_function.php";
require "../model/lookup.php";


$ref_no=$_GET['ref_no'];
$id = $_GET['id'];
$staffinfo = getBookingFormPrintById($id)->fetch_assoc();

$sys = getSys(1)->fetch_assoc();
?>

<!DOCTYPE html>
<title>iOffice::Sistem Pengurusan Pejabat Bersepadu</title>
<html lang="en">

<head>

  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

  <? require "../global/header.php"; ?>
  <style>

    body {      
            font-family: Times New Roman;
            font-size: 15px;
            color: black;
            background-color: white;
            margin-left: 20px;
            margin-right: 20px;
        }

        table.one{
            width:100%;
    
        }
        table td{
          padding: 2px;
        }
         table.sign{
            width:60%;
        }
    
        }

        input {
          width: 60%;
          border-top-style: hidden;
        border-right-style: hidden;
        border-left-style: hidden;
        border-bottom-style: hidden;
        background-color: none;
        }

        .sign input {
        border-top-style: hidden;
        border-right-style: hidden;
        border-left-style: hidden;
        border-bottom-style: groove;
        background-color: none;
      }

    .box{
          width: 100%;
        }
    
    .container{
      line-height: 0.1;
      font-size: 18px;
    }

    .container td{
      color: black;
      font-size: 14px;
    }

    h3{
      color: black;
      font-size: 28px;
    }

    .reservation{
      font-size: 16px;
    }

    @media print {
  #btn-Preview-Image {
    display: none;
  }
}
  </style>

    

</head>

<body>
  <br>

  <div class="box">

  <div class="container">
    &nbsp;     
  <table align="center" >
    <tr>
      <td rowspan="5" ><img style="margin-right: 20px;" src="../../resources/images/aims_logo.png" alt="Aims-Global" width="90px;" ></td>
      <td><b>&nbsp;Aims-Global Maritime Sdn Bhd (1041517-X)</b></td>
    </tr>
    <tr>
      <td>&nbsp;No 20 & 21, Blok B, Bestari Centre, Jalan Hiliran,</td>
    </tr>
    <tr>
      <td>&nbsp;20300 Kuala Terengganu, Terengganu Darul Iman</td>
    </tr>
    <tr>
      <td>&nbsp;PHONE NUMBER: 09-6228848 &nbsp;&nbsp;&nbsp; FAKS NUMBER: 09-6238848</td>
    </tr>
    <tr>
      <td>&nbsp;Email: aims@aimsglobal.com.my</td>
    </tr>
  </table>    
</div>

  <div class="row" align="center">
    <h3><center><b>GLOBAL LOUNGE BOOKING FORM</b></center></h3>
  </div>

    <table class="one" border="1">
        <tr>
        <td colspan="2" width="50%">FULL NAME: <?echo $staffinfo['client_name'] ;?></td>
        <td colspan="2" rowspan="2" width="50%">ROOM NO: <?echo $staffinfo['room_id'] ;?>
          <br>
        BED NO: <?echo $staffinfo['bed_id'] ;?>
        <br>
      LOCKER NO: <?echo $staffinfo['locker_id'] ;?>
    </td>
      </tr>

      <tr>
        <td colspan="2" width="50%">COMPANY: <?echo $staffinfo['company_name'] ;?></td>
      </tr>

      <tr>
        <td colspan="2" width="50%">ADDRESS: <?echo $staffinfo['client_address'] ;?> <?echo $staffinfo['client_city'] ;?> <?echo $staffinfo['client_postcode'] ;?> <?echo $staffinfo['client_state'] ;?></td>
        <td width="25%">ARRIVAL DATE: <?echo '<font>'.date('d/m/Y',strtotime($staffinfo['arrival_date'])).'</font>' ;?>
          <br>
        TIME: <?echo $staffinfo['arrival_time'] ;?></td>
        <td rowspan="2" width="25%">RETURN KEY STATUS:
          <?echo $staffinfo['key_status'] ;?><br>
          VERIFIED BY: <?echo $staffinfo['key_by'] ;?>
        </td>
      </tr>

      <tr>
        <td width="25%">IC/PASSPORT NO: <?echo $staffinfo['client_ic'] ;?></td>
        <td width="25%">CONTACT NO: <?echo $staffinfo['client_phone_no'] ;?></td>
        <td width="25%">DEPARTURE DATE: <? echo '<font>'.date('d/m/Y',strtotime($staffinfo['departure_date'])).'</font>';?>
          <br>
        TIME: <?echo $staffinfo['departure_time'] ;?></td>
      </tr>

      <tr>
        <td width="25%">CITY: <?echo $staffinfo['client_city'] ;?>
          <br>
        STATE: <?echo $staffinfo['client_state'] ;?>
        <td width="25%">CAR REGISTRATION: <?echo $staffinfo['client_car'] ;?></td>
        <th colspan="2" width="50%"><u>OFFICE USE:</u></th>
      </tr>

      <tr>
        <td style="font-size: 13px;" rowspan="2" colspan="2"><u>REMARK:</u>
          <p>* Please leave your driving license or passport for our record
            <br>* Please return this keycard to the receptionist upon check out
              <br>* Aims-Global not held responsibe for any valuables left by guest
              <br><br>
              <b><u>Lost / Unreturned Key</b></u>
                <p><b>The AIMS GLOBAL reserves the right to charge room occupants RM50.00 for any lost/unreturned key.</b></p></td>

                <td colspan="2"><u>Person Incharge Check In:</u>
                  <br>
                Confirmed By: <?echo $staffinfo['pic_cin'] ;?>
                <br>
              Date: <?echo '<font>'.date('d/m/Y',strtotime($staffinfo['arrival_date'])).'</font>' ;?></td>
      </tr>
      <tr>
        <td colspan="2"><u>Person Incharge Check Out:</u>
                  <br>
                Confirmed By: <?echo $staffinfo['pic_cout'] ;?>
                <br>
              Date: <?echo '<font>'.date('d/m/Y',strtotime($staffinfo['departure_date'])).'</font>' ;?>
      </tr>
              
        </table>

        <table class="sign" border="0">
        <tr><br>
        <th colspan="2"><u><i>AUTHORIZATION</i></u></th>
      </tr>
        <td>Approved By&nbsp;:</td>
        <td><input style="width:230px;" type="text" id="" name="" value=""></td>
      </tr>
      <tr>
        <td>Signature&emsp;&nbsp;&nbsp;&nbsp;:</td>
        <td><input style="width:230px;" type="text" id="" name="" value=""></td>
      </tr>
      <tr>
        <td>Date&emsp;&emsp;&emsp;:</td>
        <td><input style="width:230px;" type="text" id="" name="" value=""></td>
      </tr>
              
        </table>

        <br>
        <br>
        <br>

        <div style="text-align:center;">
    <br><input id="btn-Preview-Image" type="button" onclick="window.print()" value="Cetak"/>
    <br><br>
</div>
          </div> <!-- End sign -->



</body>

</html>
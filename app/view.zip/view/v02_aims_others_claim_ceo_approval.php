<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
require "../model/lookup.php";

$nostaff = $_SESSION['SESS_NO_STAFF'];
$id = $_SESSION['SESS_ID'];
$department = $_SESSION['SESS_DEPARTMENT'];
$department_sub = $_SESSION['SESS_DEPARTMENT_SUB'];
$sys = getSys(1)-> fetch_assoc();
$verified_name = $_SESSION['SESS_NAME'];

$verification = ($_GET['verification'])?: 'PENDING';
$department_code=$_GET['department_code'];
if(!isset($department_code)){
    $department_code = 'SB';
}

$no_staff = $_GET['nostaff'];
$month_claim = $_GET['month_claim'];

$user_status = v02getIC($id)->fetch_assoc();
if ($user_status['noic'] == '751206035485'){
    $user = 'CEO';
} elseif ($user_status['noic'] == '660512115105'){
    $user = 'CHAIRMAN';
} else {
    /*blank*/
}

$staff = v02getStaffDetails($no_staff)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <? require "../global/header.php"; ?>
    <style>
        .rm-badge{
            padding:3px;
            border-radius: 5px;
            font-weight:bold;
            color: #ffffff;
            background-color: green;
        }

        .claim-status{
            color:WHITE;
            padding:5px;
            border-radius: 5px;
            font-weight:bold;
        }
    </style>
</head>
<body>

<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <? include ('../global/menu_top.php'); ?>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <? include ('../global/menu_left.php'); ?>
                </ul>
            </div>
        </div>
    </nav>

    <div id="page-wrapper">
        <!--<?include '../global/menu_keselamatan.php'?>-->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> <? echo $user?> VERIFICATION
                    <a href="aims_others_claim_ceo_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>Switch to Version 01
                    </a>
                    <!--<a href="v02_aims_others_claim_ceo_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                        Back to list
                    </a>-->
                    <a href="v02_aims_others_claim_ceo_list.php?department_code=<? echo $department_code?>&verification=<? echo $verification?>" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                        Back to list
                    </a>
                </h1>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel-heading">
                    <table style="width: 100%">
                        <tr>
                            <th style="width: 15%">STAFF NAME</th>
                            <td style="width: 35%">: <? echo $staff['name']?></td>
                            <th style="width: 20%">CLAIM FOR THE MONTH ENDED</th>
                            <td style="width: 30%">: <? echo $month_claim?></td>
                        </tr>
                        <tr>
                            <th>IC</th>
                            <td>: <? echo $staff['noic'] ?></td>
                            <th>ROLE</th>
                            <td>: <? echo $staff['role_id']?></td>
                        </tr>
                        <tr>
                            <th>DEPARTMENT</th>
                            <td>: <? echo $staff['department_sub']?></td>
                            <th>COMPANY CLAIM</th>
                            <td>: <? echo $staff['department_id']?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">

                <!-- /.panel-heading -->
                <div class="panel-body">
                    <form name="" method="post" action="../controller/v02_aims_others_claim_approve.php">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th style="width: 2%">No.</th>
                                <th class="text-center">Date</th>
                                <th style="width: 16%">Detail Description</th>
                                <th class="text-center">Total Claim</th>
                                <th class="text-center" style="">HOD Status</th>
                                <th class="text-center" style="">HR Status</th>
                                <th class="text-center" style="">Finance Status</th>
                                <th class="text-center" style="">CEO/CHAIRMAN Status</th>
                                <th class="text-center" style="width: 12%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?
                            $i=1;
                            $total_cost=0.00;
                            $claim_list = v02getDetailStaffCEO($no_staff,$month_claim,$verification);
                            while($claim = $claim_list->fetch_assoc()) {

                                //HOD status -> PENDING / VERIFIED / UNVERIFIED
                                //HOD status -> PENDING / VERIFIED / UNVERIFIED
                                if (empty($claim['verify_by']) && empty($claim['verify_at'])){
                                    $hod_text_color = 'GREY';
                                    $hod_text_status = 'PENDING';
                                }else{
                                    if ($claim['verify_status'] == '1' && $claim['verify_by'] == 'AUTO VERIFIED'){
                                        $hod_text_color = 'GREEN';
                                        $hod_text_status = 'NO SUPPORT NEEDS';
                                    } elseif ($claim['verify_status'] == '1'){
                                        $hod_text_color = 'GREEN';
                                        $hod_text_status = 'VERIFIED';
                                    }else{
                                        $hod_text_color = 'RED';
                                        $hod_text_status = 'UNVERIFIED';
                                    }
                                }

                                //CEO status
                                if (empty($claim['approve_by']) && empty($claim['approve_at'])){
                                    $ceo_text_color = 'GREY';
                                    $ceo_text_status = 'PENDING';
                                }else{
                                    if ($claim['approve_status'] == '1'){
                                        $ceo_text_color = 'GREEN';
                                        $ceo_text_status = 'APPROVED';
                                    }else{
                                        $ceo_text_color = 'RED';
                                        $ceo_text_status = 'DISAPPROVED';
                                    }
                                }
                                ?>
                                <tr>
                                    <td>
                                        <input name="checkbox[]" type="checkbox" class="checkbox" id="checkbox[]" value="<?php echo $claim['id']; ?>" style="margin: 0;" />&nbsp;
                                        <label for="checkbox[]" style="margin: 0;"><?php echo $i++.'.'; ?></label>
                                    </td>
                                    <td class="text-center">
                                        <?/* echo date('Y-m-d l',strtotime($claim['date_purchase'])); */?>
                                        <span style="color: transparent;"><? echo $claim['date_purchase'] ?></span>
                                        <?
                                        echo '<p class="claim-status" style="background-color: black">'.date('d/m/Y',strtotime($claim['date_purchase'])).'<br>'.date('l',strtotime($claim['date_purchase'])).'</p>';
                                        ?>
                                    </td>
                                    <td>
                                        <? echo (empty($claim['description'])) ? '<i class="text-muted" style="font-size: 12px">No Description</i>' : $claim['description']?>
                                        <? echo (empty($claim['remarks'])) ? '' :
                                            '<p class="claim-status" style="font-weight: bold;margin-top: 10px; color: black;background-color: lightgrey">REMARKS : <br>- '.$claim['remarks'].'</p>'
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <? echo 'RM '.$claim['total_claim']?>
                                    </td>
                                    <td class="text-center">
                                        <!--<p class="claim-status" style="background-color: green">VERIFIED</p>-->
                                        <p class="claim-status" style="background-color: <?php echo $hod_text_color?>;"><?php echo $hod_text_status; ?></p>
                                        <?
                                        echo ($claim['verify_by'] == 'AUTO VERIFIED')? '' :
                                            v02getStaffName($claim['verify_by']).'<br>'.$claim['verify_at'];
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: green">REVIEWED</p>
                                        <?
                                        echo ($claim['review_status'] == '1' || $claim['review_status'] == '0')?
                                            v02getStaffName($claim['review_by']).'<br>'.$claim['review_at'] : '';
                                        ?>
                                        <br><br>
                                        <p><b>CLAIM STATUS :</b></p>
                                        <? echo ($claim['review_status'] == '1' && $claim['claim_status'] == 'CLOSED') ?
                                            '<p class="claim-status" style="background-color: green">CLOSED</p>'.$claim['claim_at'] :
                                            '<p class="claim-status" style="background-color: grey;">OPEN</p>';
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <?
                                        echo ($claim['finance_status']== '1' || $claim['finance_status'] == '0') ?
                                            '<p class="claim-status" style="background-color: green">CHECKED</p>'.v02getStaffName($claim['finance_by']).'<br>'.$claim['finance_at']
                                            :'<p class="claim-status" style="background-color: grey;">UNCHECKED</p>';
                                        ?>
                                        <br><br>
                                        <p><b>PAYMENT STATUS :</b></p>

                                        <?
                                        echo ($claim['finance_status'] == '1' && $claim['payment_status'] == 'CLOSED') ?
                                            '<p class="claim-status" style="background-color: green"> PAID </p>'.$claim['payment_at'] :
                                            '<p class="claim-status" style="background-color: green"> UNPAID </p>'
                                        ?>
                                    </td>
                                    <td class="text-center">
                                        <p class="claim-status" style="background-color: <?php echo $ceo_text_color?>"><?php echo $ceo_text_status;?></p>
                                        <?
                                        echo ($claim['approve_status'] == '1' || $claim['approve_status'] == '0')?
                                            v02getStaffName($claim['approve_by']).'<br>'.$claim['approve_at'] : '';
                                        ?>
                                    </td>

                                    <td class="text-center">
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <a href="#viewDetail" id="clicktoViewDetail" class="btn btn-success" data-toggle="modal" data-id="<? echo $claim['id'];?>"
                                               title="View Claim" style="border: 1px solid black; margin-left: 2px"><i class="fa fa-info-circle" style="font-size: 24px"></i></a>

                                            <? if ($claim['document_name'] != '') {?>
                                                <a href="#myModal2" data-toggle="modal" data-id="<? echo $claim['id'];?>" class="btn btn-warning"
                                                   title="View Attachment" style="border: 1px solid black"><i class="fa fa-file-picture-o" style="font-size: 24px;"></i></a>
                                            <? } ?>
                                        </div>
                                    </td>
                                </tr>
                                <? $total_cost+=$claim['total_claim'];
                            } ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td style="background-color:white;" colspan="3">
                                    <b>VERIFIED BY : <? echo $verified_name ?></b>
                                </td>

                                <td class="text-center" style="background-color:white;">
                                    <b>Total : <? echo '<br> RM '.number_format($total_cost, 2) ?></b>
                                </td>
                                <td style="background-color:white;" class="text-right" colspan="5">
                                    <input type="checkbox" id="select_all"/>&nbsp;
                                    <label for="select_all" style="font-size: medium;margin-right: 8px"> Select All</label>
                                    <input type="submit" name="verification_status" class="btn btn-success" id="activate" value="APPROVED" <? if ($verification=='APPROVED') echo 'disabled' ?>/>
                                    <input type="submit" name="verification_status" class="btn btn-danger" id="activate" value="DISAPPROVED" <? if ($verification=='DISAPPROVED') echo 'disabled' ?>/>
                                    <input type="hidden" name="nostaff" value="<? echo $nostaff?>">
                                </td>
                            </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <!-- /.panel-body -->
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->

<!-- Modal View Detail -->
<div class="modal fade" id="viewDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width: 90%;margin-top: 50px;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="exampleModalLongTitle" style="font-size: 120%">View Details</span>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body" id="modal-view">
                <!--Modal Script-->
                <script>
                    /*Modal View Details*/
                    $('#viewDetail').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');
                        $.ajax({
                            type:'POST',
                            url:'v02_aims_other_claim_list_modal.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#modal-view').html(html);
                            }
                        });
                    });
                </script>
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Remarks -->
<div class="modal fade" id="viewAddRemarks" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle2" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width: 90%;margin-top: 50px;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="exampleModalLongTitle2" style="font-size: 120%">ADD REMARKS</span>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body" id="modal-addRemarks">
                <!--Modal Script-->
                <script>
                    /*Modal View Details*/
                    $('#viewAddRemarks').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');
                        $.ajax({
                            type:'POST',
                            url:'v02_aims_other_claim_remarks_modal.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#modal-addRemarks').html(html);
                            }
                        });
                    });
                </script>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" id="demo2" style="text-align: center">
                <script type="text/javascript">
                    $('#myModal2').on('show.bs.modal', function (e) {
                        var rowid = $(e.relatedTarget).data('id');

                        $.ajax({
                            type:'POST',
                            url:'v02_aims_others_claim_attachment.php',
                            data:{id:rowid},
                            success:function(html){
                                $('#demo2').html(html);
                            }
                        });
                    });
                </script>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" style="background-color: #7d7d7d; color: #FFFFFF" class="btn btn-block btn-default btn-rounded btn-md ml-4"
                        data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<? include ('../global/footer.php'); ?>
<script>
    // Delete row on delete button click

    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            columnDefs: [
                { targets: -1, orderable: false }
            ]
        });
    });

    function un_check(){
        for (var i = 0; i < document.frmactive.elements.length; i++) {
            var e = document.frmactive.elements[i];
            if ((e.name != 'allbox') && (e.type == 'checkbox')) {
                e.checked = document.frmactive.allbox.checked;
            }
        }
    }

    $(document).ready(function(){
        $('#select_all').on('click',function(){
            if(this.checked){
                $('.checkbox').each(function(){
                    this.checked = true;
                });
            }else{
                $('.checkbox').each(function(){
                    this.checked = false;
                });
            }
        });

        $('.checkbox').on('click',function(){
            if($('.checkbox:checked').length == $('.checkbox').length){
                $('#select_all').prop('checked',true);
            }else{
                $('#select_all').prop('checked',false);
            }
        });
    });

</script>
</body>
</html>




<?php
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";
$no_staff = $_GET['no_staff'];

$suggested_month_claim = strtoupper(date('Y-m'));
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <? require "../global/header.php"; ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!--li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li-->
                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
		  <? $staff = getStaffForm($no_staff) -> fetch_assoc(); ?>
		<form method="post" action="../controller/v02_aims_others_claim_list_exec.php" enctype="multipart/form-data">
            <!--Hidden Input-->
            <input type="hidden" required="" id="no_staff" name="no_staff" value="<?php echo $no_staff?>" />
            <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    OTHER CLAIM <sub class="version">v02</sub> <i class="fa fa-caret-right"></i> NEW
                    <a href="aims_others_claim_form.php" class="btn btn-default btn-sm" style="float: right;background-color: #606060;color: #ffffff; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-rotate-left" style="margin-right: 4px"></i>
                        Switch to Version 01
                    </a>
                    <a href="v02_aims_others_claim_list.php" class="btn btn-default btn-sm" style="float: right;background-color: #FFA500; font-weight: bold;margin: 0 4px 0 4px">
                        <i class="fa fa-arrow-left" style="margin-right: 8px"></i>
                        Back to list
                    </a>
            </div>
		</div>
            <div class="panel-heading" align="right">
               <!--a href="stok_barang_new_add.php"><button class="btn btn-primary" data-toggle="modal"  data-target="#myModal">Tambah Stok Baharu</button></a-->
            </div>
            <div class="row" >
                <div class="col-lg-12">
                    <div class="panel panel-default"><!-- /.panel-heading --><br>
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <div class="form-group row" align="left">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Company: <font color="red">**</font>&nbsp;</label><br>
                                            <select class="form-control companySelect" id="company_name1" name="company_name" required>
                                                <option value="0">-- Select Company --</option>
                                                <? echo company_id(''); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <!--Finance Use-->
                                            <label>Job No : <span class="small">(optional)</span></label><br>
                                            <input class="form-control" type="text" name="jobno" id="jobno">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label style="margin-top: 8px">Date: <font color="red">**</font>&nbsp;</label><br>
                                            <input type="date" class="form-control" placeholder="" id="date_claim" name="date_claim" value="<? echo date('Y-m-d')?>" required />
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div id="head2">
                                                <label style="margin-top: 8px">Claim For The Month Ended: <font color="red">**</font>&nbsp</label><br>
                                                <select class="form-control" id='month_claim' name="month_claim" value="" required>
                                                    <? echo v02getDropDownMonthClaim($suggested_month_claim);?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Details Description&nbsp;: <font color="red">**</font></label>
                                            <textarea name="description" id="description" class="form-control" rows="5" required></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row" align="left" >
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Type Claim: <font color="red">**</font>&nbsp;</label><br>
                                            <select class="form-control desc" id="desc1" name="desc[]" required>
                                                <option value="0">-- Select Company First --</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 price_row">
                                        <label>RM: <font color="red">**</font></label><br>
                                        <div class="row">
                                            <div class="col-sm-4" style="padding-right: 0;">
                                                <input type="text" class="form-control rm_input" style="" id="rm_input" name="rm_input[]" value=""
                                                       oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                            </div>
                                            <div class="col-sm-4" style="padding-left: 0">

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <!--Repeat dropdown detail + RM -->
                                <div class="form-group row" align="left">
                                    <div class="col-md-12" id="repeater">
                                        <!--Empty col-->
                                    </div>
                                </div>

                                <div class="form-group row" align="left">
                                    <div class="col-md-6">
                                        <!--Empty col-->
                                    </div>
                                    <div class="col-md-2">
                                        <a href="#" style="width: 155px" id="addDropdown" name="addDropdown"
                                           class="btn btn-success"><i class="fa fa-plus-circle"> Add More Details</i></a>
                                    </div>
                                </div>


                                <div class="form-group row" align="left">
                                    <div class="col-md-6">
                                        <!--Empty col-->
                                    </div>
                                    <div class="col-md-2">
                                        <label>Total Claim (RM): <font color="red">**</font>&nbsp;</label><br>
                                        <input type="text" class="form-control total_input" style="" id="total_input" name="total_input" value="" readonly>
                                    </div>
                                </div>

                                <div class="form-group row" align="left">
                                    <div class="col-md-8">
                                        <label>Attachment&nbsp;<font color="red"><i>(Only pdf/jpeg/jpg/png/gif format file are allowed)</i></font></label>
<!--                                        <input type="hidden" name="MAX_FILE_SIZE" value="">-->
                                        <input type="file" accept=".jpg,.jpeg,.png,.gif,.pdf" name="document" id="document">
                                        <br><label>REMINDER: PLEASE ATTACH TOGETHER THE RELATED SUPPORTING DOCUMENT</label>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <div align="right">
                                        <button href="" type="submit" class="btn btn-primary" id="btnSubmit" onclick="return confirm('Confirm submit claim?')">Submit</button>
                                    </div>
                                </div>
        </form>
                        </div>
                        <!-- /.panel-body -->
                             </div>
                        </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
                    </div>
                <!-- /.row -->
            <!-- /.container-fluid -->
                </div>

                </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

    <script type="text/javascript">
        /*Validation company dropdown*/
        $(document).ready(function () {
            $('#btnSubmit').click(function () {
                var company_dropdown = $("#company_name1");
                if (company_dropdown.val() === "0"){
                    alert('Please select the company')
                    return false;
                } else {
                    return true;
                }
            });
        });

        $(document).on('change', '.companySelect', function (){
            let company_id = $(this).val();
            let no_staff = $('#no_staff').val();
            console.log(company_id);
            console.log(no_staff);
            $.ajax({
                type: 'POST',
                url: '../controller/v02_aims_others_claim_retrieve_desc.php',
                data: {id:company_id,nostaff:no_staff},
                success:function(html){
                    $("select.desc").each(function (index, element) {
                        $(element).html(html);
                    });
                }
            });
        });

        let descCount = 1;

        $('#addDropdown').on('click', function () {
            descCount++;

            let company_id = $('.companySelect').val();
            let no_staff = $('#no_staff').val();
            let optionList = "";
            $.ajax({
                type: 'POST',
                url: '../controller/v02_aims_others_claim_retrieve_desc.php',
                data: {id:company_id,nostaff:no_staff},
                success:function(html){
                    //return null 01/08/2022
                    optionList += '<div class="form-group row" align="left" id="parent'+descCount+'">' +
                        '<div class="col-md-6"><div class="form-group">' +
                        '<label>Type Claim: <font color="red">**</font>&nbsp;' +
                        '<span title="Delete" class="btn btn-xs btn-danger" id="deleteRow" data-typeclaim="parent'+descCount+'" data-rm="rm_input'+descCount+'">' +
                        '<i class="">Remove</i></span></label><br>' +
                        '<select class="form-control desc" id="desc'+descCount+'" name="desc[]" required>' +
                        html +
                        '</select></div></div>' +
                        '<div class="col-md-2 price_row">' +
                        '<div class="form-group"><label>RM: <font color="red">**</font>&nbsp;</label><br>' +
                        '<input type="text" class="form-control rm_input" style="" id="rm_input'+descCount+'" name="rm_input[]" value="" required' +
                        ' oninput="this.value = this.value.replace(/[^0-9.]/g, \'\').replace(/(\\..*)\\./g, \'$1\');"> '  +
                        '</div></div>' +
                        '</div>';
                    $('#repeater').append(optionList);
                }
            });
        });

        // Delete Type Claim row + New total calculation
        $(document).on('click', '#deleteRow', function () {

            /*NOTE:
            * let cannot be redeclared
            * var can be redeclared
            * */

            /*data-typeclaim = typeclaim */
            let targetElement = "#"+$(this).data('typeclaim');
            /*data-rm = rm*/
            let price = "#"+$(this).data('rm');
            let price_deduction = $(price).val();
            /*Declaration id = total_input*/
            let total_input = $('#total_input');

            /*Formula new total -> Minus remove price*/
            let new_total = total_input.val() - price_deduction;
            /*New total calculation*/
            total_input.val(new_total.toFixed(2));
            /*Remove dropdown*/
            $(targetElement).remove();
        });

        /*Total sum of array RM*/
        $(document).on('input', '.rm_input', function () {
            var subtotal = 0;
            $('.price_row').each(function() {
                var price = $(this).find(".rm_input").val();
                var int_price = parseFloat(price);
                if($.isNumeric(int_price)){
                    subtotal += int_price;
                }
            });
            $("#total_input").val(subtotal.toFixed(2));
        });

        function convertToUppercase(el) {
					if(!el || !el.value) return;
					el.value = el.value.toUpperCase();
				}
    </script>
</body>
</html>
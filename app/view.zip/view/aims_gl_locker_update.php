<?php

	include ('../controller/auth.php');

	require "../model/aims_gl_function.php";

         
		$id = $_GET['id'];
        $data = getLockerById($id)->fetch_assoc(); 
 ?> 

                     
                      <form method="post" action="../controller/aims_gl_locker_update_exec.php" >     
							<input id="id" name="id" type="hidden" value="<? echo $id?>"/>
                              
							  
                             
							<label><font color="red">** Maklumat Wajib Diisi.</font></label>
							<br>
							 
							 <div class="form-group"  align="left">
                                  <label>ROOM NO<font color="red">**</font>&nbsp;</label>
                                  <select  required class="form-control" name="room_id" id="room_id">
                                    		<option value="">-- Choose Room --</option>
                                    		<? echo getDropDownRoom($data['room_no']); ?>
                                    		</select>
                                </div>
							 
								<div class="form-group"  align="left">
								  <label>LOCKER NO<font color="red">**</font>&nbsp;</label>
								  <input class="form-control" placeholder=" " name="locker_no" id="locker_no" value="<? echo $data['locker_no'];?>" >
								</div>

								<div class="form-group"  align="left">
  								<label>Status: <?php echo $data['status']; ?></label></br>
									<input type="radio" id="status" name="status" <?php if($data['status']=="1") {echo "checked";}?> value="1">Active	
									<input type="radio" id="status" name="status" <?php if($data['status']=="0") {echo "checked";}?> value="0">In Active
								</div>



                             <div class="modal-footer">
                                   <button type="submit" class="btn btn-primary">Save</button>
                                  
                             </div>
         
					</form>
                      
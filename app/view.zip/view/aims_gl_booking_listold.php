<?php

include ('../controller/auth.php');

require "../model/aims_gl_function.php";
require "../model/lookup.php";

?>
<?
$booking= getBookingList($_SESSION['SESS_NAME'],$_SESSION['SESS_DEPARTMENT_SUB']);
$pic_cout = $_SESSION['SESS_NAME'];
$reviewed_status = $_GET['reviewed_status'];
    if (!isset($status) && $status == '') {
        $status = '1';
    }
?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <? require "../global/header.php"; ?>

</head>

<style>
   body{
        font-size: 12.5px;
    }
    th, td{
        text-align: center;
    }
</style>
  
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

            <!-- /.navbar-header -->
            <? include ('../global/menu_top.php'); ?>

            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <!-- <li>
                            <center><img src="images/pic.jpg" class="user-image img-responsive"/></center>
                        </li> -->

                        <? include ('../global/menu_left.php'); ?>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Booking List</h1>
                </div>
            </div>

            <? 
            $flagScreen="tab_2";
            include ('../global/aims_gl_menu1.php'); 
          ?>

            <div class="row">
                <div class="panel-heading" align="right">
                
                </div>
                <div class="col-lg-12">
                  <br>
                  <br>
        </div>

             <div class="row">
                <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <label class="control-label" for="date">Booking List</label>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th rowspan="2" width="5%">No.</th>
                                    <th rowspan="2" width="25%">Client Name</th>
                                    <th rowspan="2" width="15%">Phone No</th>
                                    <th rowspan="2" width="15%">Company</th>
                                    <th colspan="2" width="20%">Check In</th>
                                    <th colspan="2" width="20%">Check out</th>
                                    <th rowspan="2" width="10%">Action</th>
                                </tr>

                                <tr style="font-weight: bold;">
                                    <td>Date</td>
                                    <td>Time</td>
                                    <td>Date</td>
                                    <td style="border-right: inset; ">Time</td>
                                </tr>
                            </thead>

                                <?
                                    $booking = getBookingList($_SESSION['SESS_NAME']);
                                    $i=1;
                                    while($list_booking = $booking->fetch_assoc()) {
                                ?>

                                <tbody>
                                <tr>
                                    <td><? echo $i++;?></td>
                                    <td><? echo $list_booking['client_name']; ?></td>
                                    <td><? echo $list_booking['client_phone_no']; ?></td>
                                    <td><? echo $list_booking['company_name']; ?></td>
                                    <td><? echo $list_booking['arrival_date']; ?></td>
                                    <td><? echo $list_booking['arrival_time']; ?></td>
                                    <td><? echo $list_booking['departure_date']; ?></td>
                                    <td><? echo $list_booking['departure_time']; ?></td>

                                    <td>
                                    <a href="#myModal2" data-toggle="modal" data-id="<? echo $list_booking['id'];?>"><button type="button" class="btn btn-info">Show Info</button></a>

                                    <a href="aims_gl_booking_update.php?id=<? echo $list_booking['id']; ?>" class="btn btn-primary">Update</a>

                                    <!-- <a href="aims_gl_bookingform_print.php?id=<? echo $list_booking['id']; ?>" class="btn btn-primary">Print</a> -->

                                    <a href="aims_gl_exchange.php?id=<? echo $list_booking['id']; ?>" class="btn btn-warning">Change Room</a>
                                    
                                    <a href="#myModal1" data-toggle="modal" data-id="<? echo $list_booking['id'];?>"><button type="button" class="btn btn-success">Add Ref No</button></a>

                                    <!-- <a href="../controller/aims_ReviewedButton_exec.php?travel_claim_id=<? echo $row_data['id'];?>&reviewed_name=<?echo $reviewed_name?>"><button class="btn btn-primary" type="button" onclick="return Confirm()" >REVIEW</button></a> -->

                                    <a href="../controller/aims_gl_checkout_exec.php?id=<? echo $list_booking['id']; ?>&pic_cout=<?echo $pic_cout?>"><button class="btn btn-danger" type="button" onclick="return confirm('Are you sure you want to check out?');">Check Out</button></a>
                                </td>
                                
                                </tr>
                            <?}?>
                             </tbody>
                        </table>
                    </div>
                </div>
              </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <!-- /.container-fluid -->
        </div>

        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <? include ('../global/footer.php'); ?>

    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Room Reservation</h4>
        </div>
        <div class="modal-body" id="demo">
        <script type="text/javascript">
          $('#myModal1').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'GET',
              url:'aims_gl_room_reserv_add.php',
              data:'id='+rowid,
              success:function(html){
                $('#demo').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
  </div>
</div>

<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="myModalLabel">Booking Info</h4>
        </div>
        <div class="modal-body" id="demo2">
        <script type="text/javascript">
          $('#myModal2').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            // $('#demo').html(rowid);
            $.ajax({
              type:'POST',
              url:'aims_gl_booking_info.php',
              data:'id='+rowid,
              success:function(html){
                $('#demo2').html(html);
              }
            });
          });
        </script>
        </div>                                                                       
      </div>
  </div>
</div>

    <script>
                    $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });
        });

                </script>

</body>
</html>
<?php
date_default_timezone_set("Asia/Kuala_Lumpur");
include ('../controller/auth.php');
require "../model/v02_aims_others_claim_function.php";

$id = $_POST['id'];
$attachment = v02getAttachment($id);
$extension = explode('.', $attachment);
$extension = end($extension);
echo $attachment.'<br>';
if ($extension == 'pdf'){ ?>
    <iframe width="100%" height="500" src="<?php echo '../../othersclaimphoto/'.$attachment; ?>" class="embed-responsive-item"></iframe>
<? }else{ ?>
    <span style="text-align: center"><?echo '<img src="../../othersclaimphoto/'.$attachment.'" border="0" width="500" height="610"/>';?></span>
<? } ?>
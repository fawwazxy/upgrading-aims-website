<?php

	include ('../controller/auth.php');
	require "../model/aims_car_function.php";
	require "../model/lookup.php";
	
		 $id = $_GET['id'];
		 $car_info = getcarById($id)->fetch_assoc();
		 $car_milage = getmilagecarById($id)->fetch_assoc();
 ?> 

                     
                      <form method="post" action="../controller/aims_car_update_exec.php" enctype="multipart/form-data">     

							<label><font color="red">** Required Information.</font></label>
							<br>
							        
							  <input id="updated_by" name="updated_by" type="hidden" value="<?php echo $_SESSION['SESS_NAME'] ?>"/>
							  <input type="hidden" name="id" value="<?php echo $car_info['id']; ?>">
							  
							  <div class="form-group row" align="center">
								<br>
								<?if($car_info['document_type'] == 'jpg' || $car_info['document_type'] == 'jpeg' || $car_info['document_type'] == 'png' || $car_info['document_type'] == 'gif') {
                                                echo '<img width="200" height="100" src="data:image/jpeg;base64,'.base64_encode( $car_info['document'] ).'"/><br>';}
                                         else if($car_info['document_type'] == 'pdf') {
                                                echo '<object width="200" height="100" data="data:application/pdf;base64,'.base64_encode( $car_info['document'] ).'"/><br>'.'" type="application/pdf"></object>';}
                                ?>
								</div>
							  
							    <div class="boxes">VEHICLE PROFILE</div>
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>MODEL</label><br>
								  <? echo $car_info['car_model'];?>
								</div>							  
							  
							    <div class="col-xs-6">
								  <label>OWNER</label><br>
								  <? echo $car_info['car_owner'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-4">
								  <label>TYPE OF CAR</label><br>
								  <? echo $car_info['car_type'];?>
								</div>
								<div class="col-xs-4">
								  <label>PLATE NO</label><br>
								  <? echo $car_info['car_plate_no'];?>
								</div>
								<div class="col-xs-4">
								 <label>COLOR</label><br>
								<? echo $car_info['color'];?>
								</div>
								</div>
								
								<div class="boxes">PERSON IN CHARGE</div>
								<div class="form-group row" align="center">
								<div class="col-xs-6">
                                  <label>PIC 1</label><br>
								  <? echo $car_info['car_pic'];?>
                                </div>
								<div class="col-xs-6">
                                  <label>PIC 2</label><br>
									<? echo $car_info['car_pic2'];?>
                                </div>
								</div>
								
								<div class="boxes">VEHICLE INFORMATION</div>
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>ENGINE NO</label><br>
								  <? echo $car_info['engine_no'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>CHASSIS NO</label><br>
								  <? echo $car_info['chassis_no'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-3">
								  <label>PURCHASE VALUE</label><br>
								  <? echo $car_info['cost_receipt'];?>
								</div>
								<div class="col-xs-3">
								  <label>PURCHASE DATE</label><br>
								  <? echo $car_info['date_receipt'];?>
								</div>
								<div class="col-xs-6">
								  <label>SUPPLIERS</label><br>
								  <? echo $car_info['suppliers'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>HIRE PURCHASE NO</label><br>
								  <? echo $car_info['hire_account_no'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>ACCOUNT NAME</label><br>
								  <? echo $car_info['name_account'];?>
								</div>
								</div>
								
								<div class="boxes">SERVICE INFORMATION</div>
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>LAST SERVICE</label><br>
								  <? echo $car_info['last_service'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT SERVICE</label><br>
								  <? echo $car_info['next_service'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>CURRENT MILEAGE</label><br>
								  <? echo $car_milage['return_milage'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>NEXT MILEAGE SERVICE</label><br>
								  <? echo $car_info['next_mileage'];?>
								</div>
								</div>
								
								<div class="boxes">ROADTAX AND INSURANCE</div>
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>DATE EXPIRED (ROADTAX)</label><br>
								  <? echo $car_info['date_ex_rtx'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>VALUE (ROADTAX)</label><br>
								  <? echo $car_info['value_rtx'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>DATE EXPIRED (INSURANCE)</label><br>
								  <? echo $car_milage['date_ex_ins'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>INSURANCE CATEGORY</label><br>
								  <? echo $car_info['ins_category'];?>
								</div>
								</div>
								
								<div class="form-group row" align="center">
								<div class="col-xs-6">
								  <label>TYPE OF INSURANCE</label><br>
								  <? echo $car_milage['type_ins'];?>
								</div>
								
								<div class="col-xs-6">
								  <label>VALUE (INSURANCE)</label><br>
								  <? echo $car_info['value_ins'];?>
								</div>
								</div>
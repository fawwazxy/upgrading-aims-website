<?php
include "../model/v02_aims_ot_function.php";
//Sanitize the POST values

$no_staff_applicant = clean($_POST['no_staff_applicant']);
$no_staff_approval = clean($_POST['no_staff_approval']);
$description = clean($_POST['description']);
$rate_mode = clean($_POST['rate_mode']);
$result = v02addOtPermission($rate_mode,$no_staff_applicant,$description,$no_staff_approval);

//Check whether the query was successful or not
if($result!="" && $result > 0) {
    echo ("<script>
        alert('Successfully add new OT Permission');
        window.location.href='../view/v02_aims_otpermission_list.php';
        </script>");
    exit();
} else {
    echo ("<script>
        alert('Failed to add new OT Permission !!! ');
        window.location.href='../view/v02_aims_otpermission_form.php';
        </script>");
    exit();
}
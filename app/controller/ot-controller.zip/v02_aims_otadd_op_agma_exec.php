<?php
include "../model/v02_aims_ot_function.php";

$no_staff = clean($_POST['no_staff']);
$no_staff_approval = "auto";
$description = clean($_POST['description']);
$rate_mode = clean($_POST['rate_mode']);
$result = v02addOtPermission($rate_mode,$no_staff,$description,$no_staff_approval);

//Check whether the query was successful or not
if($result!="" && $result > 0) {

    $ot_permission_id = $result;

    $result_approval = v02autoApprovePermission($ot_permission_id);

    $month_claim = clean($_POST['month_claim']);
    $date_ot = clean($_POST['date_ot']);
    $start_ot = clean($_POST['start_ot']);
    $end_ot = clean($_POST['end_ot']);
    $total_hours = clean($_POST['total_hours']);

    $current_date = date('Y-m-d');

    $mm = date('m',strtotime($month_claim));
    $Y_m = date("Y-m");
    $limit_date = date("Y-m-d", strtotime($Y_m."-15 +1 month")); //2022-05-15

//Declare variable
    $document_name = "";
    $document_size = "";

    if (strtotime($current_date) > strtotime($limit_date)) {
        echo ("<script>
		alert('Claim for this month already closed. Please choose next month (".date("F", strtotime($limit_date)).") as Month Claim!');
		window.history.back();
		</script>");
        exit();
    }else {
        $targetDir = "../../overtimephoto/";
        if($_FILES['document']['size'] > 0) {

            $document_size = $_FILES['document']['size'];
            $tmp_name = $_FILES['document']['tmp_name'];
            $documentName = $_FILES['document']['name'];

            $array2 = explode(".", $documentName);
            $document_type = end($array2); //get "jpg" string

            $document_name= date('Ymd_His').'_'.$documentName;
            $targetPath = $targetDir . $document_name;
            $extensions= array('JPG','JPEG','PNG','GIF','PDF','jpg','jpeg','png','gif','pdf');

            if(in_array($document_type,$extensions)=== false){
                $errors[]="extension not allowed, please choose a JPEG or PNG file.";
            }
            if($document_size > 4194304){
                $errors[]='File size must be below 4 MB';
            }

            if(empty($errors)==true){
                move_uploaded_file($tmp_name,$targetPath);
            }else{
                $err_text = '';
                foreach ($errors as $error){
                    $err_text .= "- ".$error."<br>";
                }
            }
        }
    }

    $result = v02addOt($no_staff,$ot_permission_id,$month_claim,$date_ot,$start_ot,$end_ot,$total_hours,$document_name,$document_size);

    if($result == true) {

        echo ("<script>
            alert('Successfully add new overtime claim');
			window.location.href='../view/v02_aims_ot_list.php';
			</script>");
        exit();

    } else {
        die("Query failed");
    }
} else {
    echo ("<script>
        alert('Failed to add new OT Claim !!! ');
        window.location.href='../view/v02_aims_ot_form_op_agmsb.php';
        </script>");
    exit();
}
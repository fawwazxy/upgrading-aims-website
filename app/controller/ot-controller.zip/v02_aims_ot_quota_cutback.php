<?php
include "../model/v02_aims_ot_function.php";

$today = date("Y-m-d");
$yesterday = date("Y-m-d", strtotime(" -1 day"));

$yesterday_ot = v02getYesterdayOt($yesterday);

$query_count = 0;
$success_count = 0;

while ($row = $yesterday_ot->fetch_assoc()){
    echo 'id: '.$row['id'].'<br>';
    echo 'month_session:'.$row['month_session_id'].'<br>';
    echo 'date:'.$row['date'].'<br>';
    echo 'overused: '.$row['today_overused'].'<br>';

    $result = v02createDateQuotaCutback($row['month_session_id'], $today, $row['today_overused']);

    //check whether the query was successful or not
    if($result!="" && $result > 0){
        $success_count++;
    }
    $query_count++;
}
print_r($yesterday_ot);
<?php
include "../model/v02_aims_ot_function.php";

$id = clean($_POST['id']);
$approval_status = clean($_POST['approval_status']);
//$remark = clean($_POST['remark']);

$result = v02approveOtPermission($id, $approval_status);

//Check whether the query was successful or not
if($result!="" && $result > 0){
    echo ("<script>
            alert('Successfully Approve/Decline OT Permission');
            window.location.href='../view/v02_aims_otpermission_approve.php';
            </script>");
    exit();
}else{
    echo ("<script>
            alert('Failed to Approve/Decline OT Permission !');
            window.history.back();
            </script>");
    exit();
}
